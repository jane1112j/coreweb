import type { IMetaProto } from './types'

export * from './types'

let loaded = false

/**
 * Nạp thư viện Meta Proto bằng cách chèn thẻ <script> vào document.head.
 * File .min.js sẽ tự gắn vào self["proto"] và các namespace liên quan.
 *
 * @param url Đường dẫn tùy chỉnh tới file meta.proto.js (tuỳ chọn)
 */
export const loadMetaProto = async (url?: string): Promise<void> => {
  if (loaded) return

  // Nếu thư viện đã có sẵn trong global scope
  if (typeof self !== 'undefined' && (self as unknown as Record<string, unknown>).MetaProto) {
    loaded = true
    return
  }

  // Resolve đường dẫn tới file .min.js từ vị trí của package
  const scriptUrl = url ?? new URL('./meta.proto_20250616_1150.min.js', import.meta.url).href

  await new Promise<void>((resolve, reject) => {
    const script = document.createElement('script')
    script.src = scriptUrl

    script.onload = () => {
      loaded = true
      resolve()
    }

    script.onerror = (e) => {
      console.error('[meta-proto] Failed to load script:', scriptUrl, e)
      reject(new Error(`Failed to load script: ${scriptUrl}`))
    }

    document.head.appendChild(script)
  })
}

/**
 * Lấy object thư viện Meta Proto từ global scope.
 * Phải gọi `await loadMetaProto()` trước khi sử dụng.
 *
 * @returns Object thư viện Meta Proto (chứa các hàm encode/decode)
 * @throws Error nếu thư viện chưa được nạp
 */
export const getMetaProto = (): IMetaProto => {
  const globalScope = self as unknown as Record<string, IMetaProto>
  if (typeof self !== 'undefined' && globalScope.MetaProto) {
    return globalScope.MetaProto
  }
  throw new Error('[meta-proto] Thư viện chưa được nạp. Vui lòng gọi await loadMetaProto() trước.')
}

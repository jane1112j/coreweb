/* eslint-disable @typescript-eslint/no-namespace, @typescript-eslint/no-explicit-any */
/**
 * Định nghĩa các kiểu dữ liệu cho thư viện Meta Proto (Google Protobuf)
 * Được cập nhật từ kết quả inspection thực tế và yêu cầu của người dùng.
 */

export namespace common {
  export type Bytes = Uint8Array | string
}

export interface ProtobufMessage {
  toObject(includeInstance?: boolean): any
  serializeBinary(): Uint8Array
}

export interface AccountState extends ProtobufMessage {
  getAddress(): common.Bytes
  getAddress_asU8(): Uint8Array
  getAddress_asB64(): string
  setAddress(value: common.Bytes): void
  getLasthash(): common.Bytes
  setLasthash(value: common.Bytes): void
  getBalance(): common.Bytes
  setBalance(value: common.Bytes): void
  getPendingbalance(): common.Bytes
  setPendingbalance(value: common.Bytes): void
  getSmartcontractstate(): any
  setSmartcontractstate(value?: any): void
  getDevicekey(): common.Bytes
  setDevicekey(value: common.Bytes): void
  getNonce(): common.Bytes
  setNonce(value: common.Bytes): void
  getPublickeybls(): common.Bytes
  setPublickeybls(value: common.Bytes): void
  getAccounttype(): number
  setAccounttype(value: number): void
}

export interface Header extends ProtobufMessage {
  getCommand(): string
  setCommand(value: string): void
  getPubkey(): common.Bytes
  setPubkey(value: common.Bytes): void
  getToaddress(): common.Bytes
  setToaddress(value: common.Bytes): void
  getSign(): common.Bytes
  setSign(value: common.Bytes): void
  getVersion(): string
  setVersion(value: string): void
  getId(): string
  setId(value: string): void
}

export interface Message extends ProtobufMessage {
  getHeader(): Header | undefined
  setHeader(value?: Header): void
  getBody(): common.Bytes
  setBody(value: common.Bytes): void
}

export interface Receipt extends ProtobufMessage {
  getTransactionhash(): common.Bytes
  getFromaddress(): common.Bytes
  getToaddress(): common.Bytes
  getAmount(): common.Bytes
  getStatus(): number
  getGasused(): number
  getEventlogsList(): any[]
}

/**
 * Interface chính cho đối tượng MetaProto (chứa các hàm encode/decode)
 */
export interface IMetaProto {
  // Utility methods
  rlpEncode(data: any): string
  byteToHex(bytes: Uint8Array): string
  toBytes(data: string | Uint8Array): Uint8Array
  getHeaderForCommand(params: {
    command: string
    toAddress?: string
    sign?: string
    publicKey?: string
  }): Header

  // Decode methods
  decodeMessage(data: common.Bytes): Message
  decodeInitConnection(data: common.Bytes): any
  decodeAccountState(data: common.Bytes): AccountState
  decodeRecipt(data: common.Bytes): Receipt // Lưu ý: typo 'Recipt' từ thư viện
  decodeEventLog(data: common.Bytes): any
  decodeTransaction(data: common.Bytes): any
  decodeTransactionError(data: common.Bytes): any
  decodeTransactionHashData(data: common.Bytes): any

  // Encode methods
  encodeCallData(params: { input: any }): {
    code: string
    data: string
    message: string
    success: boolean
  }
  encodeInitConnection(params: {
    address: string
    type?: string
    isReplace?: boolean
  }): common.Bytes
  encodeMessage(params: { header: any; body: any }): {
    code: string
    data: string
    message: string
    success: boolean
  }
  encodeTransaction(params: any): {
    code: string
    data: string
    message: string
    success: boolean
  }
  encodeTransactionHashData(params: any): {
    code: string
    data: string
    message: string
    success: boolean
  }
  encodeTransactionWithDeviceKey(params: { transaction: string; deviceKey: string }): {
    code: string
    data: string
    message: string
    success: boolean
  }

  // Prototype methods (available on MetaProto instance)
  concatBytes(...args: Uint8Array[]): Uint8Array
  hexToByte(hex: string): Uint8Array
  isHexString(str: string): boolean
  toCanonicalRLPHex(data: any): string
  validateRequireInput(params: {
    key: string
    data: Record<string, unknown>
    type: string
    controller: string
    functionCode: string
    number?: number
  }): {
    success: boolean
    message: string
    data: Record<string, unknown>
    code: string
  }
}

import { defineConfig } from 'tsup'
import { copyFileSync } from 'fs'

export default defineConfig({
  entry: ['src/index.ts'],
  format: ['esm', 'cjs'],
  dts: true,
  minify: true,
  bundle: true,
  platform: 'browser',
  splitting: false,
  sourcemap: true,
  clean: true,
  outDir: 'dist',
  outExtension({ format }) {
    return format === 'esm' ? { js: '.mjs' } : { js: '.cjs' }
  },
  onSuccess: async () => {
    // Copy file thư viện gốc vào dist/ để có thể serve qua import.meta.url
    copyFileSync('src/meta.proto_20250616_1150.min.js', 'dist/meta.proto_20250616_1150.min.js')
    console.log('[meta-proto] Copied meta.proto_20250616_1150.min.js to dist/')
  },
})

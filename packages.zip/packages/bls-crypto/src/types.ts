/**
 * Interface cho thư viện BLS Crypto mới (bls_20250911_1625.min.js)
 */

export interface IBLS {
  initBLS(): Promise<void> | void
  init_context(): void
  getKeyPair(privateKey?: string): { address: string; public_key: string; private_key: string }
  sign(message: string, privateKey: string, isHex: boolean): { sign: string }
  verifySign(message: string, signature: string, publicKey: string): boolean
  verifyAggregateSign(messages: string[], signatures: string[], publicKeys: string[]): boolean
}

export interface IECDSA {
  ecdsa_sign(message: string, privateKey: string, isHash?: boolean | 0 | 1): { sign: string }
  ecdsa_verify(message: string, signature: string, publicKey: string): boolean
  ecdh(
    privateKey: string,
    publicKey: string,
  ): {
    key: string
  }
  ec_pubkey_create(privateKey: string, isCompressed?: boolean): { public_key: string }
}

export interface IABI {
  /**
   * Encodes arguments for a contract call.
   * @param values Array of arguments to encode
   * @param abi The contract ABI (array of fragments)
   * @param name The function name to encode
   */
  abi_encode(values: unknown[], abi: unknown[], name: string): string

  /**
   * Decodes hexadecimal result data from a contract call.
   * @param data Hexadecimal string to decode
   * @param outputs Array of output fragments/types
   */
  abi_decode(data: string, outputs: unknown[]): { decode: string }

  abiEncodeFunction(name: string, types: string[], values: unknown[]): string
}

export interface IUtils {
  // Tham số thứ 2 là boolean hoặc 0, 1
  keccak256(data: string, isHash?: boolean | number): { hash: string }
  keccak256File: (input: Blob, chunkSize?: number) => Promise<{ hash: string }>
  byteToHex(bytes: Uint8Array): string
  hexToByte(hex: string): Uint8Array
  convertStringNumberToHexString(numStr: string): string
  Keccak256Context: new () => IKeccak256Context
}

export interface IKeccak256Context {
  update(data: Uint8Array): void
  final(): { hash: string }
}

export interface IBLSCrypto extends IBLS, IECDSA, IABI, IUtils {
  nativeModule: boolean
}

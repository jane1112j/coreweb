import type { IBLSCrypto } from './types'

let loaded = false

/**
 * Nạp thư viện BLS bằng cách chèn thẻ <script> vào document.head.
 * File .min.js sẽ tự gắn vào self.bls (UMD pattern).
 *
 * Nếu không truyền url, hàm sẽ tự resolve đường dẫn tới file .min.js
 * dựa trên vị trí của package (import.meta.url).
 *
 * @param url Đường dẫn tùy chỉnh tới file bls.min.js (tuỳ chọn)
 */
export const loadBLS = async (url?: string): Promise<void> => {
  if (loaded) return

  // Nếu thư viện đã có sẵn trong global scope
  if (typeof self !== 'undefined' && (self as unknown as Record<string, unknown>).bls) {
    loaded = true
    return
  }

  // Resolve đường dẫn tới file .min.js từ vị trí của package
  // const scriptUrl = url ?? new URL('./bls_20250911_1625.min.js', import.meta.url).href
  const scriptUrl = url ?? new URL('./bls.js', import.meta.url).href

  await new Promise<void>((resolve, reject) => {
    const wasmUrl = new URL('./bls_c.wasm', import.meta.url).href
    ;(window as unknown as { BLS_VERSION: string }).BLS_VERSION = '20260528'
    ;(window as unknown as { __BLS_WASM_URL: string }).__BLS_WASM_URL = wasmUrl

    const script = document.createElement('script')
    script.src = scriptUrl

    script.onload = () => {
      loaded = true
      resolve()
    }

    script.onerror = (e) => {
      console.error('[bls-crypto] Failed to load script:', scriptUrl, e)
      reject(new Error(`Failed to load script: ${scriptUrl}`))
    }

    document.head.appendChild(script)
  })
}

/**
 * Lấy object thư viện BLS từ global scope.
 * Phải gọi `await loadBLS()` trước khi sử dụng.
 *
 * @returns Object thư viện BLS đã được cast sang IBLSCrypto
 * @throws Error nếu thư viện chưa được nạp
 */
export const getBLS = (): IBLSCrypto => {
  const globalScope = self as unknown as Record<string, IBLSCrypto>
  if (typeof self !== 'undefined' && globalScope.bls) {
    return globalScope.bls
  }
  throw new Error('[bls-crypto] Thư viện chưa được nạp. Vui lòng gọi await loadBLS() trước.')
}

// Re-export types
export type { IBLSCrypto, IBLS, IECDSA, IABI, IUtils } from './types'

import { defineConfig } from 'tsup'
import * as dotenv from 'dotenv'
import { copyFileSync } from 'fs'

dotenv.config()

export default defineConfig({
  env: {
    FIAI_BLOCKCHAIN_BRIDGE_URL: process.env.FIAI_BLOCKCHAIN_BRIDGE_URL || '',
    FIAI_CRYPTO_VAULT_URL: process.env.FIAI_CRYPTO_VAULT_URL || '',
    FIAI_FILE_PROCESSOR_URL: process.env.FIAI_FILE_PROCESSOR_URL || '',
  },
  entry: ['src/index.ts'],
  format: ['esm', 'cjs'],
  dts: true,
  minify: true,
  bundle: true,
  platform: 'browser',
  splitting: false,
  sourcemap: true,
  clean: true,
  outDir: 'dist',
  outExtension({ format }) {
    return format === 'esm' ? { js: '.mjs' } : { js: '.cjs' }
  },
  onSuccess: async () => {
    // Copy file thư viện gốc vào dist/ để có thể serve qua import.meta.url
    copyFileSync('src/bls.js', 'dist/bls.js')
    copyFileSync('src/bls_c.wasm', 'dist/bls_c.wasm')

    console.log('[bls-crypto] Copied bls_20250911_1625.min.js to dist/')
  },
})

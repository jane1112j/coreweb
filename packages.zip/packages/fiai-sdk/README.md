# @metanodejs/fiai-sdk 🚀

`@metanodejs/fiai-sdk` là Kernel SDK chịu trách nhiệm thiết lập cầu nối giao tiếp bảo mật, bất đồng bộ (Request/Response & Events) giữa ứng dụng chính (Host) và các ứng dụng con trong iframe (Frames) theo giao thức bảo mật mã hóa và quản lý Service Worker Runtime.

---

## Tính năng nổi bật

- 🔐 **Giao tiếp Bảo mật (Encrypted PostMessage)**: Mã hóa kênh truyền thông điệp giữa Host và Frame sử dụng RSA + AES.
- 📦 **Service Worker Runtime (Micro-Frontend Cache)**: Quản lý tải xuống, lưu cache và phục vụ các ứng dụng con (Frames) ngoại tuyến qua Service Worker.
- 🌉 **Hỗ trợ Auto-Bridging (Iframe lồng nhau)**: Tự động phát hiện môi trường iframe lồng nhau và chuyển tiếp (tunnel) các yêu cầu/sự kiện lên Frame cha.
- 🖼️ **Quản lý UI Modal**: Tích hợp sẵn `WalletModal` để tải nhanh Drawer giao diện chọn ví từ xa.
- 🌐 **Hỗ trợ Môi trường Đa dạng**: Cấu hình tách biệt giữa Local Development và Production.

---

## Kiến trúc Giao tiếp

```
       [ Ứng dụng chính (Host) ]
                  ↕  (FiaiSDK)
 ┌────────────────┼────────────────┐
 ↓                ↓                ↓
[blockchain-bridge] [crypto-vault] [file-processor]  (Frames - FrameClient)
```

---

## Hướng dẫn sử dụng

### 1. Phía Host (Ứng dụng chính)

Khởi tạo SDK với các cấu hình mong muốn:

```ts
import { FiaiSDK } from '@metanodejs/fiai-sdk'

const fiaiSDK = await FiaiSDK.init({
  container: document.getElementById('fiai-container') || undefined, // Phần tử chứa các iframe ẩn
  timeout: 60000, // Timeout chờ các frame sẵn sàng (ms)
  frameUrls: {
    blockchainBridge: 'https://json.iqnb.com/fiai-sdk/blockchain-bridge/',
    cryptoVault: 'https://json.iqnb.com/fiai-sdk/crypto-vault/',
    fileProcessor: 'https://json.iqnb.com/fiai-sdk/file-processor/',
  },
})

// Gửi request tới một Frame cụ thể (ví dụ: lấy ví đang active)
const activeWallet = await fiaiSDK.request('getActiveWallet', {})
console.log('Active Wallet:', activeWallet)

// Lắng nghe sự kiện phát ra từ các Frame
const unsubscribe = fiaiSDK.on('wallet-connected', (wallet) => {
  console.log('Wallet connected:', wallet)
})

// Hủy lắng nghe
unsubscribe()
```

### 2. Phía Client (Ứng dụng bên trong Iframe)

Sử dụng `FrameClient` để giao tiếp ngược lại với Host:

```ts
import { FrameClient } from '@metanodejs/fiai-sdk'

// Khởi tạo FrameClient cho frame tương ứng
const client = new FrameClient('crypto-vault')

// Báo hiệu với Host rằng Frame đã sẵn sàng và đăng ký các action có thể xử lý
await client.ready(['getActiveWallet', 'setActiveWallet'])

// Lắng nghe yêu cầu từ Host truyền xuống và xử lý
client.handle('getActiveWallet', async (params) => {
  return { address: '0x1234...5678' }
})

// Gửi request lên Host (ví dụ: sao chép clipboard)
const result = await client.call('copy-clipboard', { text: 'Hello World' })

// Phát sự kiện lên Host và các Frame khác
await client.emit('wallet-changed', { address: '0x9999...9999' })
```

---

## Cấu hình Môi trường (Env)

SDK hỗ trợ load cấu hình tự động khi build thông qua các file env ở thư mục gốc của project:

- `.env.development`: Chứa các URL chạy local (localhost).
- `.env.production`: Chứa các URL Production chính thức của các Frame.

Các biến môi trường được hỗ trợ:

```env
FIAI_BLOCKCHAIN_BRIDGE_URL=https://json.iqnb.com/fiai-sdk/blockchain-bridge/
FIAI_CRYPTO_VAULT_URL=https://json.iqnb.com/fiai-sdk/crypto-vault/
FIAI_FILE_PROCESSOR_URL=https://json.iqnb.com/fiai-sdk/file-processor/
VITE_URL_CONNECT_WALLET=connect-wallet-web.iqnb.com
```

---

## Quy trình Phát triển và Build

Chạy các lệnh sau bên trong thư mục `packages/fiai-sdk`:

### 1. Chạy ở chế độ Development (Watch mode)

```bash
pnpm dev
```

### 2. Build cho Development

Sử dụng cấu hình từ `.env.development`:

```bash
pnpm build
```

### 3. Build cho Production

Sử dụng cấu hình tĩnh được mã hóa trực tiếp từ `.env.production`:

```bash
pnpm build:prod
```

---

## Giải quyết sự cố thường gặp (Troubleshooting)

### Lỗi: `No frame found for action: getSettingDapp`

- **Nguyên nhân**: Frame tương ứng chưa báo hiệu `ready()` hoặc chưa đăng ký handler cho action này trong danh sách `client.ready([...])`.
- **Cách sửa**: Kiểm tra xem trong Frame con đã gọi `client.ready()` và truyền đúng tên action chưa, đồng thời đảm bảo không khởi tạo lại nhiều instance `FiaiSDK` khác nhau làm mất cầu nối postMessage.

---

## License

MIT

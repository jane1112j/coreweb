import { defineConfig } from 'tsup'
import * as dotenv from 'dotenv'

import * as path from 'path'

const envMode = process.env.NODE_ENV === 'production' ? 'production' : 'development'
const envPath = path.resolve(__dirname, `../../.env.${envMode}`)

dotenv.config({ path: envPath })
dotenv.config({ path: path.resolve(__dirname, '../../.env') })

export default defineConfig({
  env: {
    FIAI_BLOCKCHAIN_BRIDGE_URL: process.env.FIAI_BLOCKCHAIN_BRIDGE_URL || '',
    FIAI_CRYPTO_VAULT_URL: process.env.FIAI_CRYPTO_VAULT_URL || '',
    FIAI_FILE_PROCESSOR_URL: process.env.FIAI_FILE_PROCESSOR_URL || '',
    VITE_URL_CONNECT_WALLET: process.env.VITE_URL_CONNECT_WALLET || '',
  },
  entry: ['src/index.ts'],
  format: ['esm', 'cjs'],
  dts: true,
  minify: true,
  bundle: true, // ✅ bundle all deps
  platform: 'browser', // ✅ browser friendly
  splitting: false,
  sourcemap: true,
  clean: true,
  outDir: 'dist',
  outExtension({ format }) {
    return format === 'esm' ? { js: '.mjs' } : { js: '.cjs' }
  },
})

import type { Packet } from '~/bridge/protocol/Packet'
import { EncryptionProvider } from '~/bridge/security/EncryptionProvider'
import { HandshakeProvider } from '~/bridge/security/HandshakeProvider'
import { ChunkManager } from '~/bridge/transport/ChunkManager'
import type { ITransport } from '~/bridge/transport/ITransport'
import { PostMessageTransport } from '~/bridge/transport/PostMessageTransport'
import { CHUNK_SIZE, MAX_PARALLEL_CHUNKS, RAW_CHUNK_SIZE } from '~/core/constants'
import type { FrameName, RequestData, RequestInterceptor, ResponseInterceptor } from '~/core/types'
import * as cryptoUtils from '~/utils/crypto'
import { generateUUID } from '~/utils/ids'
import { ActionDispatcher } from './ActionDispatcher'

export class FrameClient {
  private transport: ITransport
  private encryption: EncryptionProvider | undefined
  private dispatcher = new ActionDispatcher()
  private hostOrigin: string = '*'
  private rsaKeyPair: CryptoKeyPair | undefined
  private initialized: Promise<void>
  private resolveInit!: () => void
  private messageQueue: Packet[] = []
  private chunkManager = new ChunkManager()
  private pendingRequests = new Map<
    string,
    {
      resolve: (val: unknown) => void
      reject: (err: Error) => void
      timer: ReturnType<typeof setTimeout>
    }
  >()

  public readonly interceptors = {
    request: [] as RequestInterceptor[],
    response: [] as ResponseInterceptor[],
  }

  constructor(private frameName: FrameName) {
    this.transport = new PostMessageTransport(window.parent)

    this.initialized = new Promise((resolve) => {
      this.resolveInit = resolve
    })

    this.transport.onMessage((event) => void this.handleMessage(event))
    void this.startHandshake()
  }

  private async startHandshake() {
    try {
      const params = new URLSearchParams(window.location.hash.substring(1))
      this.hostOrigin = decodeURIComponent(params.get('origin') ?? '*')

      this.rsaKeyPair = await HandshakeProvider.generateKeyPair()
      const publicKeyBuffer = await HandshakeProvider.exportPublicKey(this.rsaKeyPair.publicKey)

      const messageId = generateUUID()
      void this.sendPacket(
        {
          type: 'handshake-init',
          messageId,
          frameName: this.frameName,
          data: { publicKey: publicKeyBuffer },
        },
        this.hostOrigin,
        [publicKeyBuffer],
      )
    } catch (err) {
      console.error(`[FrameClient] Handshake initiation failed:`, err)
    }
  }

  private async handleMessage(event: MessageEvent) {
    if (this.hostOrigin !== '*' && event.origin !== this.hostOrigin) return
    const packet = event.data as Packet<{
      encryptedSessionKey: ArrayBuffer
    }>
    if (!packet || typeof packet !== 'object') return
    if (packet.type === 'handshake-confirm' && packet.data?.encryptedSessionKey) {
      await this.handleHandshakeConfirm(packet.data.encryptedSessionKey)
      return
    }

    if (packet.type === 'chunk') {
      let processedPacket = packet
      if (packet.isChunkEncrypted && packet.encryptedPayload && packet.iv && this.encryption) {
        try {
          const decrypted = await this.encryption.decryptRaw(packet.encryptedPayload, packet.iv)
          processedPacket = {
            ...packet,
            encryptedPayload: decrypted,
            iv: undefined,
            isChunkEncrypted: false,
          }
        } catch (err) {
          console.error(`[FrameClient] Failed to decrypt chunk:`, err)
          return
        }
      }

      const assembled = this.chunkManager.assemble(processedPacket)
      if (assembled) {
        const isDecrypted = packet.isChunkEncrypted ?? processedPacket.isChunkEncrypted

        const assembledPacket: Packet = {
          ...packet,
          type: assembled.originalType ?? 'request',
          messageId: packet.messageId,
          encryptedPayload: assembled.payload,
          iv: isDecrypted ? undefined : assembled.iv,
          isAssembled: true,
        }
        await this.processPacket(assembledPacket)
      }
      return
    }

    if (!this.encryption) {
      this.messageQueue.push(packet)
      return
    }

    await this.processPacket(packet)
  }

  private async handleHandshakeConfirm(encryptedKey: ArrayBuffer) {
    if (!this.rsaKeyPair) return
    try {
      const rawKey = await HandshakeProvider.decryptSessionKey(
        this.rsaKeyPair.privateKey,
        encryptedKey,
      )
      const sessionKey = await EncryptionProvider.importRawKey(rawKey)
      this.encryption = new EncryptionProvider(sessionKey)

      cryptoUtils.clearBuffer(rawKey)
      this.rsaKeyPair = undefined
      const queue = [...this.messageQueue]
      this.messageQueue = []
      this.resolveInit()
      for (const p of queue) await this.processPacket(p)
    } catch (err) {
      console.error(`[FrameClient] Handshake finalization failed:`, err)
    }
  }

  private async processPacket(packet: Packet) {
    switch (packet.type) {
      case 'request':
        if (packet.messageId && packet.encryptedPayload && (packet.iv || packet.isAssembled)) {
          await this.handleRequest(packet)
        }
        break
      case 'response':
      case 'error':
        if (packet.messageId) {
          await this.handleResponse(packet)
        }
        break
    }
  }

  private async handleResponse(packet: Packet) {
    const pending = this.pendingRequests.get(packet.messageId)
    if (!pending) return

    clearTimeout(pending.timer)
    this.pendingRequests.delete(packet.messageId)

    if (packet.type === 'error') {
      pending.reject(new Error(packet.data?.message ?? 'Unknown host error'))
      return
    }

    try {
      if (packet.encryptedPayload && (packet.iv || packet.isAssembled)) {
        if (!this.encryption) throw new Error('Missing encryption provider')

        let decrypted
        if (packet.isAssembled && !packet.iv) {
          decrypted = cryptoUtils.deserializePayload(packet.encryptedPayload)
        } else {
          decrypted = await this.encryption.decrypt(packet.encryptedPayload, packet.iv!)
        }

        // Run Response Interceptors
        for (const interceptor of this.interceptors.response) {
          decrypted = await interceptor(decrypted)
        }

        pending.resolve(decrypted)
      } else {
        pending.resolve(packet.data)
      }
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err)
      pending.reject(new Error(`Failed to decrypt response from Host: ${errorMessage}`))
    }
  }

  public async call<T = unknown>(action: string, params: unknown = {}): Promise<T> {
    await this.initialized

    if (!this.encryption) {
      throw new Error('FrameClient: Session Key not established')
    }

    const messageId = `${action}_${generateUUID()}`

    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingRequests.delete(messageId)
        reject(new Error(`Request "${action}" to Host timed out`))
      }, 30000)

      this.pendingRequests.set(messageId, {
        resolve: resolve as (val: unknown) => void,
        reject,
        timer,
      })

      const runRequest = async () => {
        try {
          // Run Request Interceptors
          let requestData: RequestData = { action, params }
          for (const interceptor of this.interceptors.request) {
            requestData = await interceptor(requestData)
          }

          await this.sendEncryptedData('request', messageId, requestData)
        } catch (err: unknown) {
          clearTimeout(timer)
          this.pendingRequests.delete(messageId)
          const errorMessage = err instanceof Error ? err.message : String(err)
          reject(new Error(`Failed to send request: ${errorMessage}`))
        }
      }

      void runRequest()
    })
  }

  private async handleRequest(packet: Packet) {
    try {
      let decrypted: { action: string; params: unknown }

      if (packet.isAssembled && !packet.iv) {
        decrypted = cryptoUtils.deserializePayload<{ action: string; params: unknown }>(
          packet.encryptedPayload!,
        )
      } else {
        decrypted = await this.encryption!.decrypt<{ action: string; params: unknown }>(
          packet.encryptedPayload!,
          packet.iv!,
        )
      }

      let requestData: RequestData = { action: decrypted.action, params: decrypted.params }
      // Run Request Interceptors
      for (const interceptor of this.interceptors.request) {
        requestData = await interceptor(requestData)
      }

      const result = await this.dispatcher.dispatch(requestData.action, requestData.params)
      await this.sendResponse(packet.messageId, result)
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err)
      this.sendError(packet.messageId, errorMessage)
    }
  }

  private async sendResponse(messageId: string, data: unknown) {
    let responseData = data

    // Run Response Interceptors
    for (const interceptor of this.interceptors.response) {
      responseData = await interceptor(responseData)
    }

    await this.sendEncryptedData('response', messageId, responseData)
  }

  private sendError(messageId: string, message: string) {
    void this.sendPacket(
      {
        type: 'error',
        messageId,
        data: { message },
      },
      this.hostOrigin,
    )
  }

  public handle<P = unknown, R = unknown>(action: string, handler: (params: P) => R | Promise<R>) {
    this.dispatcher.register(action, handler)
  }

  /**
   * Trả về danh sách các action đã đăng ký
   */
  public getRegisteredActions(): string[] {
    return this.dispatcher.getRegisteredActions()
  }

  public async ready(manualActions?: string[]) {
    await this.initialized
    const actions = manualActions ?? this.dispatcher.getRegisteredActions()
    void this.sendPacket(
      {
        type: 'ready',
        messageId: generateUUID(),
        frameName: this.frameName,
        data: { actions },
      },
      this.hostOrigin,
    )
  }

  public async emit(eventName: string, payload: unknown) {
    await this.initialized
    const messageId = generateUUID()
    const requestData = { event: eventName, payload }
    await this.sendEncryptedData('event', messageId, requestData)
  }

  public showUI() {
    void this.sendPacket(
      { type: 'ui-show', messageId: generateUUID(), frameName: this.frameName },
      this.hostOrigin,
    )
  }

  public hideUI() {
    void this.sendPacket(
      { type: 'ui-hide', messageId: generateUUID(), frameName: this.frameName },
      this.hostOrigin,
    )
  }

  /**
   * Helper gửi Packet, tự động xử lý Chunking nếu cần
   */
  private async sendPacket(packet: Packet, targetOrigin: string, transfer?: Transferable[]) {
    if (packet.encryptedPayload && packet.encryptedPayload.byteLength > CHUNK_SIZE) {
      const messageId = packet.messageId
      const chunks = ChunkManager.split(packet.encryptedPayload, CHUNK_SIZE, messageId, packet.type)

      if (packet.iv && chunks[0]) chunks[0].iv = packet.iv
      for (const chunk of chunks) chunk.frameName = packet.frameName ?? this.frameName

      for (let i = 0; i < chunks.length; i += MAX_PARALLEL_CHUNKS) {
        const batch = chunks.slice(i, i + MAX_PARALLEL_CHUNKS)
        batch.forEach((chunk) => {
          this.transport.send(chunk, targetOrigin)
        })
        await new Promise((resolve) => setTimeout(resolve, 10))
      }
    } else {
      this.transport.send(packet, targetOrigin, transfer)
    }
  }

  private async sendEncryptedData(type: Packet['type'], messageId: string, data: unknown) {
    const serialized = cryptoUtils.serializePayload(data)

    if (serialized.byteLength > RAW_CHUNK_SIZE) {
      const chunks = ChunkManager.splitRaw(
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        serialized.buffer as ArrayBuffer,
        RAW_CHUNK_SIZE,
        messageId,
        type,
      )

      for (let i = 0; i < chunks.length; i += MAX_PARALLEL_CHUNKS) {
        const batch = chunks.slice(i, i + MAX_PARALLEL_CHUNKS)

        // Mã hóa song song cả batch để tăng tốc
        await Promise.all(
          batch.map(async (packet) => {
            const { ciphertext, iv } = await this.encryption!.encryptRaw(packet.encryptedPayload!)
            packet.encryptedPayload = ciphertext
            packet.iv = iv
            packet.isChunkEncrypted = true
            packet.frameName = this.frameName

            void this.sendPacket(packet, this.hostOrigin, [ciphertext, iv.buffer])
          }),
        )

        // Yield event loop
        await new Promise((resolve) => setTimeout(resolve, 0))
      }
    } else {
      const { ciphertext, iv } = await this.encryption!.encrypt(data)
      void this.sendPacket(
        {
          type,
          messageId,
          encryptedPayload: ciphertext,
          iv,
          frameName: this.frameName,
        },
        this.hostOrigin,
        [ciphertext, iv.buffer],
      )
    }
  }
}

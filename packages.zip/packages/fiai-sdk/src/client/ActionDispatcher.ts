export class ActionDispatcher {
  private handlers = new Map<string, (params: unknown) => unknown>()

  public register<P = unknown, R = unknown>(
    action: string,
    handler: (params: P) => R | Promise<R>,
  ): void {
    this.handlers.set(action, handler as (params: unknown) => unknown)
  }

  public async dispatch(action: string, params: unknown): Promise<unknown> {
    const handler = this.handlers.get(action)
    if (!handler) {
      throw new Error(`No handler registered for action: ${action}`)
    }
    return await handler(params)
  }

  public getRegisteredActions(): string[] {
    return Array.from(this.handlers.keys())
  }
}

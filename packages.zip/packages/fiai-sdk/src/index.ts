export { FiaiSDK } from './host/FiaiSDK'
export { FrameClient } from './client/FrameClient'
export type { ApplicationActionHandler } from './core/interfaces/IActionHandler'
export type { IUseCase } from './core/interfaces/IUseCase'
export { GenericActionHandler } from './core/handlers/GenericActionHandler'
export { EventEmitter } from './utils/EventEmitter'
export * as cryptoUtils from './utils/crypto'
export {
  encryptPayload,
  decryptPayload,
  encryptPayloadSmart,
  decryptPayloadSmart,
  deriveKeyFromPassword,
  clearBuffer,
  terminateCryptoWorker,
} from './utils/crypto'

export type { FrameName } from './core/types'
export { SystemActions } from './core/actions'

export * as utils from './utils/utils'
export * as runtime from './host/runtime'
// export * as fiaiSDKVitePlugin from './vite-plugin'

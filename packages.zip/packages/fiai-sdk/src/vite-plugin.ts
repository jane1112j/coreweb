/**
 * Vite Plugin for FIAI SDK
 *
 * Automatically copies the Service Worker file (`wallet-runtime-sw.js`)
 * from the SDK's dist folder into the host application's public directory.
 * Vite serves that file next to index.html, so a deploy at /admin publishes
 * /admin/wallet-runtime-sw.js.
 *
 * Usage in host's vite.config.ts:
 *   import { fiaiSdkPlugin } from '@metanodejs/fiai-sdk/vite-plugin'
 *   export default defineConfig({
 *     plugins: [fiaiSdkPlugin()]
 *   })
 */

import { existsSync, copyFileSync, mkdirSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { createRequire } from 'node:module'
import type { Plugin } from 'vite'

const SW_FILENAME = 'wallet-runtime-sw.js'

export interface FiaiSdkPluginOptions {
  /**
   * Directory to copy the SW file into.
   * Defaults to 'public' (Vite's default publicDir).
   */
  publicDir?: string
}

/**
 * Resolve the path to the compiled Service Worker file
 * from `@metanodejs/fiai-sdk/dist/wallet-runtime-sw.js`.
 */
function resolveSwPath(root: string): string | null {
  try {
    // Try createRequire-based resolution (works in ESM and CJS)
    const require = createRequire(resolve(root, 'package.json'))
    const sdkEntryPath = require.resolve('@metanodejs/fiai-sdk')
    const sdkDistDir = dirname(sdkEntryPath)
    const swPath = resolve(sdkDistDir, SW_FILENAME)
    if (existsSync(swPath)) return swPath
  } catch {
    // Fallback: check common node_modules paths
  }

  // Fallback: manual resolution in node_modules
  const candidates = [
    resolve(root, 'node_modules', '@metanodejs', 'fiai-sdk', 'dist', SW_FILENAME),
    resolve(root, '..', 'node_modules', '@metanodejs', 'fiai-sdk', 'dist', SW_FILENAME),
    resolve(root, '..', '..', 'node_modules', '@metanodejs', 'fiai-sdk', 'dist', SW_FILENAME),
  ]

  for (const candidate of candidates) {
    if (existsSync(candidate)) return candidate
  }

  return null
}

export function fiaiSdkPlugin(options: FiaiSdkPluginOptions = {}): Plugin {
  let root = process.cwd()
  const publicDirName = options.publicDir ?? 'public'

  return {
    name: 'fiai-sdk-sw-copy',
    enforce: 'pre',

    configResolved(config) {
      root = config.root
    },

    buildStart() {
      const swSourcePath = resolveSwPath(root)
      if (!swSourcePath) {
        this.warn(
          `[fiai-sdk] Could not find ${SW_FILENAME} in @metanodejs/fiai-sdk/dist. ` +
            `Make sure the package is installed and built.`,
        )
        return
      }

      const publicDir = resolve(root, publicDirName)
      const destPath = resolve(publicDir, SW_FILENAME)

      // Ensure public dir exists
      if (!existsSync(publicDir)) {
        mkdirSync(publicDir, { recursive: true })
      }

      // Copy SW file
      copyFileSync(swSourcePath, destPath)
    },
  }
}

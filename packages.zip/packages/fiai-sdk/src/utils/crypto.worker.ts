/**
 * CryptoWorker — Inline Web Worker for heavy crypto operations.
 */

export const CRYPTO_WORKER_SOURCE = /* js */ `
'use strict';

const ALGORITHM = 'AES-GCM';
const IV_LENGTH = 12;

// ─── Key Cache ────────────────────────────────────────────────
const keyCache = new Map();

async function importAndCacheKey(keyId, rawKeyBuffer) {
  if (keyCache.has(keyId)) return keyCache.get(keyId);
  const key = await self.crypto.subtle.importKey(
    'raw', rawKeyBuffer, { name: ALGORITHM }, false, ['encrypt', 'decrypt']
  );
  keyCache.set(keyId, key);
  return key;
}

// ─── Message Handler ──────────────────────────────────────────

self.onmessage = async function(e) {
  const msg = e.data;

  try {
    switch (msg.type) {

      case 'setKey': {
        await importAndCacheKey(msg.keyId, msg.rawKey);
        self.postMessage({ id: msg.id, type: 'setKey-result' });
        break;
      }

      case 'encrypt': {
        const key = keyCache.get(msg.keyId);
        if (!key) {
          self.postMessage({ id: msg.id, type: 'error', message: 'Key not cached: ' + msg.keyId });
          return;
        }

        const iv = self.crypto.getRandomValues(new Uint8Array(IV_LENGTH));

        let encoded;
        if (msg.data instanceof ArrayBuffer) {
          // Flag 1: Binary
          encoded = new Uint8Array(msg.data.byteLength + 1);
          encoded[0] = 1;
          encoded.set(new Uint8Array(msg.data), 1);
        } else if (typeof msg.data === 'string') {
          // Flag 2: String
          const strEncoded = new TextEncoder().encode(msg.data);
          encoded = new Uint8Array(strEncoded.byteLength + 1);
          encoded[0] = 2;
          encoded.set(strEncoded, 1);
        } else {
          // Flag 0: JSON
          const jsonStr = JSON.stringify(msg.data, function(key, value) {
            if (value instanceof ArrayBuffer) {
              const bytes = new Uint8Array(value);
              let binary = '';
              const len = bytes.byteLength;
              for (let i = 0; i < len; i += 8192) {
                binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
              }
              return {
                type: 'Buffer',
                data: btoa(binary)
              };
            }
            if (ArrayBuffer.isView(value)) {
              const bytes = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
              let binary = '';
              const len = bytes.byteLength;
              for (let i = 0; i < len; i += 8192) {
                binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
              }
              return {
                type: 'Buffer',
                data: btoa(binary)
              };
            }
            return value;
          });
          const jsonEncoded = new TextEncoder().encode(jsonStr);
          encoded = new Uint8Array(jsonEncoded.byteLength + 1);
          encoded[0] = 0;
          encoded.set(jsonEncoded, 1);
        }

        const ciphertext = await self.crypto.subtle.encrypt(
          { name: ALGORITHM, iv }, key, encoded
        );

        self.postMessage(
          { id: msg.id, type: 'encrypt-result', ciphertext, iv },
          [ciphertext, iv.buffer]
        );
        break;
      }

      case 'decrypt': {
        const key = keyCache.get(msg.keyId);
        if (!key) {
          self.postMessage({ id: msg.id, type: 'error', message: 'Key not cached: ' + msg.keyId });
          return;
        }

        const decryptedBuffer = await self.crypto.subtle.decrypt(
          { name: ALGORITHM, iv: msg.iv }, key, msg.ciphertext
        );

        const view = new Uint8Array(decryptedBuffer);
        const flag = view[0];
        const actualData = decryptedBuffer.slice(1);

        if (flag === 1) {
          self.postMessage({ id: msg.id, type: 'decrypt-result', data: actualData }, [actualData]);
        } else if (flag === 2) {
          const decoded = new TextDecoder().decode(actualData);
          self.postMessage({ id: msg.id, type: 'decrypt-result', data: decoded });
        } else {
          const decoded = new TextDecoder().decode(actualData);
          const parsed = JSON.parse(decoded, function(key, value) {
            if (value && value.type === 'Buffer' && typeof value.data === 'string') {
              const binary = atob(value.data);
              const len = binary.length;
              const bytes = new Uint8Array(len);
              for (let i = 0; i < len; i++) {
                bytes[i] = binary.charCodeAt(i);
              }
              return bytes.buffer;
            }
            if (value && value.type === 'Buffer' && Array.isArray(value.data)) {
              return new Uint8Array(value.data).buffer;
            }
            return value;
          });
          self.postMessage({ id: msg.id, type: 'decrypt-result', data: parsed });
        }
        break;
      }

      default:
        self.postMessage({ id: msg.id, type: 'error', message: 'Unknown op: ' + msg.type });
    }
  } catch (err) {
    self.postMessage({ id: msg.id, type: 'error', message: err.message || 'Worker crypto error' });
  }
};
`

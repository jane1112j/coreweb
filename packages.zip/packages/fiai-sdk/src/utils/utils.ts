export function formatAddress(address: string): string {
  const normalized = address.toLowerCase()
  return normalized.startsWith('0x') ? normalized : `0x${normalized}`
}
export function remove0x(address: string): string {
  const normalized = address.toLowerCase()
  return normalized.startsWith('0x') ? normalized.slice(2) : normalized
}

export function formatHex(hex: string): string {
  const normalized = hex.toLowerCase()
  return normalized.startsWith('0x') ? normalized : `0x${normalized}`
}

export function isZeroHex(value: string): boolean {
  const normalized = value.toLowerCase()
  return /^0x0+$/.test(normalized)
}

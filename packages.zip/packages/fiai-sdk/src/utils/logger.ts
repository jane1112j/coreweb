/**
 * Debug logger cho MetanodeSDK
 * Chỉ log khi debug mode bật
 */

const PREFIX = '[MetanodeSDK]'

let debugEnabled = false

export function setDebug(enabled: boolean): void {
  debugEnabled = enabled
}

export function isDebug(): boolean {
  return debugEnabled
}

export const logger = {
  info(...args: unknown[]): void {
    if (debugEnabled) {
      // eslint-disable-next-line no-console
      console.log(PREFIX, ...args)
    }
  },

  warn(...args: unknown[]): void {
    if (debugEnabled) {
      console.warn(PREFIX, ...args)
    }
  },

  error(...args: unknown[]): void {
    // Errors luôn được log bất kể debug mode
    console.error(PREFIX, ...args)
  },

  debug(...args: unknown[]): void {
    if (debugEnabled) {
      // eslint-disable-next-line no-console
      console.debug(PREFIX, ...args)
    }
  },
}

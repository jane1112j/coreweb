/**
 * CryptoWorkerPool — Manages a Web Worker for offloading heavy crypto operations.
 *
 * Zero-Copy Architecture:
 * ┌─────────────┐                           ┌──────────────┐
 * │ Main Thread  │  ── Transfer(buffer) ──▶  │   Worker     │
 * │              │  ◀── Transfer(result) ──  │              │
 * └─────────────┘                           └──────────────┘
 *
 * Key Caching: Raw key is sent once via `setKey`, then referenced by `keyId`.
 * Data Encoding: Main Thread does JSON.stringify + TextEncoder.encode → ArrayBuffer,
 *                then TRANSFERS (zero-copy) the ArrayBuffer to Worker.
 *
 * ⚠ IMPORTANT: After Transfer, the original ArrayBuffer is detached (byteLength=0).
 *   This is by design. The caller should NOT reuse the buffer after calling workerEncrypt.
 */

import { CRYPTO_WORKER_SOURCE } from './crypto.worker'

// ─── Types ───────────────────────────────────────────────────

/** Encrypt result from Worker */
export interface WorkerEncryptResult {
  ciphertext: ArrayBuffer
  iv: Uint8Array
}

/** Messages sent TO the Worker */
type WorkerInMessage =
  | { id: string; type: 'setKey'; keyId: string; rawKey: ArrayBuffer }
  | { id: string; type: 'encrypt'; keyId: string; data: unknown }
  | { id: string; type: 'decrypt'; keyId: string; ciphertext: ArrayBuffer; iv: Uint8Array }

/** Messages received FROM the Worker */
type WorkerOutMessage =
  | { id: string; type: 'setKey-result' }
  | { id: string; type: 'encrypt-result'; ciphertext: ArrayBuffer; iv: Uint8Array }
  | { id: string; type: 'decrypt-result'; data: unknown }
  | { id: string; type: 'error'; message: string }

interface PendingWorkerRequest<T = unknown> {
  resolve: (value: T) => void
  reject: (reason: Error) => void
  timer: ReturnType<typeof setTimeout>
}

// ─── State ───────────────────────────────────────────────────

/** Default timeout for worker operations (60s — generous for 100MB+) */
const WORKER_TIMEOUT = 60_000

let workerInstance: Worker | null = null
let workerBlobUrl: string | null = null
const pendingRequests = new Map<string, PendingWorkerRequest>()
let requestCounter = 0
let workerAvailable: boolean | null = null // null = not yet tested

/** Keys that have been sent to the current Worker instance */
const sentKeyIds = new Set<string>()

/** Raw key bytes backup for re-sending after Worker crash/recreate */
const keyBackup = new Map<string, ArrayBuffer>()

// ─── Key Utilities ───────────────────────────────────────────

/**
 * Generate a deterministic keyId from raw key bytes (hex of first 8 bytes).
 */
function computeKeyId(rawKey: ArrayBuffer): string {
  const view = new Uint8Array(rawKey, 0, Math.min(8, rawKey.byteLength))
  let hex = ''
  for (let i = 0; i < view.length; i++) {
    hex += (view[i] as number).toString(16).padStart(2, '0')
  }
  return hex
}

// ─── Worker Lifecycle ────────────────────────────────────────

function getWorker(): Worker | null {
  if (workerAvailable === false) return null
  if (workerInstance) return workerInstance

  try {
    if (
      typeof Worker === 'undefined' ||
      typeof Blob === 'undefined' ||
      typeof URL === 'undefined'
    ) {
      workerAvailable = false
      return null
    }

    const blob = new Blob([CRYPTO_WORKER_SOURCE], { type: 'application/javascript' })
    workerBlobUrl = URL.createObjectURL(blob)
    workerInstance = new Worker(workerBlobUrl)

    workerInstance.onmessage = (event: MessageEvent<WorkerOutMessage>) => {
      const msg = event.data
      const pending = pendingRequests.get(msg.id)
      if (!pending) return

      clearTimeout(pending.timer)
      pendingRequests.delete(msg.id)

      if (msg.type === 'error') {
        pending.reject(new Error(msg.message))
      } else if (msg.type === 'setKey-result') {
        pending.resolve(undefined)
      } else if (msg.type === 'encrypt-result') {
        pending.resolve({ ciphertext: msg.ciphertext, iv: msg.iv })
      } else if (msg.type === 'decrypt-result') {
        pending.resolve(msg.data)
      } else {
        pending.reject(new Error('Unexpected worker result'))
      }
    }

    workerInstance.onerror = (error: ErrorEvent) => {
      console.error('[CryptoWorkerPool] Worker error:', error)
      for (const [, pending] of pendingRequests) {
        clearTimeout(pending.timer)
        pending.reject(new Error('Worker crashed'))
      }
      pendingRequests.clear()
      terminateWorker()
      workerAvailable = false
    }

    // Clear sent keys — new Worker instance doesn't have any cached keys
    sentKeyIds.clear()

    workerAvailable = true
    return workerInstance
  } catch (err) {
    console.warn('[CryptoWorkerPool] Failed to create Worker:', err)
    workerAvailable = false
    return null
  }
}

function nextRequestId(): string {
  return `cw_${++requestCounter}_${Date.now()}`
}

/**
 * Send raw key to Worker for caching (only if not already sent).
 * Raw key is COPIED (32 bytes — negligible overhead).
 */
async function ensureKey(worker: Worker, rawKey: ArrayBuffer): Promise<string> {
  const keyId = computeKeyId(rawKey)

  if (sentKeyIds.has(keyId)) return keyId

  // Backup key bytes for recovery after Worker crash
  keyBackup.set(keyId, rawKey.slice(0))

  const id = nextRequestId()

  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingRequests.delete(id)
      reject(new Error('setKey timeout'))
    }, 5_000)

    pendingRequests.set(id, { resolve: resolve as (v: unknown) => void, reject, timer })

    const msg: WorkerInMessage = { id, type: 'setKey', keyId, rawKey }
    // rawKey is 32 bytes — Structured Clone is fine, no need to Transfer
    worker.postMessage(msg)
  })

  sentKeyIds.add(keyId)
  return keyId
}

// ─── Public API ──────────────────────────────────────────────

/**
 * Encrypt data using the Worker.
 *
 * Strategy: Send raw JS data to Worker via Structured Clone. The Worker handles
 * JSON.stringify + TextEncoder.encode + crypto.subtle.encrypt internally.
 *
 * Why NOT stringify on Main Thread?
 * - JSON.stringify(100MB) takes ~200ms (sync, blocks Main Thread)
 * - Structured Clone of the same object takes ~50ms (browser-optimized memcpy)
 * - Net savings: ~150ms less Main Thread blocking
 *
 * Results (ciphertext + iv) come back via Transferable (zero-copy).
 *
 * @param rawKey Raw AES key bytes (32 bytes). Will be cached in Worker.
 * @param data Data to encrypt. Sent to Worker via Structured Clone.
 */
export async function workerEncrypt(
  rawKey: ArrayBuffer,
  data: unknown,
): Promise<WorkerEncryptResult> {
  const worker = getWorker()
  if (!worker) throw new Error('Worker not available')

  // 1. Ensure key is cached in Worker
  const keyId = await ensureKey(worker, rawKey)

  // 2. Send raw data to Worker — Worker handles stringify + encode + encrypt
  const id = nextRequestId()

  return new Promise<WorkerEncryptResult>((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingRequests.delete(id)
      reject(new Error(`Worker encrypt timeout after ${WORKER_TIMEOUT}ms`))
    }, WORKER_TIMEOUT)

    pendingRequests.set(id, {
      resolve: resolve as (v: unknown) => void,
      reject,
      timer,
    })

    // Send data via Structured Clone (browser-optimized, ~50ms for 100MB string)
    // Worker will do JSON.stringify + encode internally (off Main Thread)
    worker.postMessage({ id, type: 'encrypt', keyId, data })
  })
}

/**
 * Decrypt data using the Worker with Transferable Objects.
 *
 * Flow:
 * 1. Main Thread: Transfer(ciphertext, iv) to Worker → O(1)
 * 2. Worker: crypto.subtle.decrypt → TextDecoder.decode → JSON.parse
 * 3. Worker: sends parsed result back via Structured Clone (responses are typically small)
 *
 * ⚠ After calling this, the original `ciphertext` ArrayBuffer is DETACHED.
 *   Do NOT reuse it. If you need it, clone with `ciphertext.slice(0)` before calling.
 *
 * @param rawKey Raw AES key bytes (32 bytes). Will be cached in Worker.
 * @param ciphertext Encrypted data. Will be TRANSFERRED (detached after call).
 * @param iv Initialization vector. Will be TRANSFERRED (detached after call).
 */
export async function workerDecrypt<T = unknown>(
  rawKey: ArrayBuffer,
  ciphertext: ArrayBuffer,
  iv: Uint8Array,
): Promise<T> {
  const worker = getWorker()
  if (!worker) throw new Error('Worker not available')

  const keyId = await ensureKey(worker, rawKey)

  const id = nextRequestId()

  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingRequests.delete(id)
      reject(new Error(`Worker decrypt timeout after ${WORKER_TIMEOUT}ms`))
    }, WORKER_TIMEOUT)

    pendingRequests.set(id, {
      resolve: resolve as (v: unknown) => void,
      reject,
      timer,
    })

    const msg: WorkerInMessage = { id, type: 'decrypt', keyId, ciphertext, iv }
    // Transfer ciphertext + iv.buffer (zero-copy)
    worker.postMessage(msg, [ciphertext, iv.buffer])
    // ⚠ ciphertext and iv are now detached
  })
}

/**
 * Check if the Worker is available and ready.
 */
export function isWorkerAvailable(): boolean {
  if (workerAvailable === null) {
    getWorker()
  }
  return workerAvailable === true
}

/**
 * Terminate the Worker and clean up all resources.
 */
export function terminateWorker(): void {
  if (workerInstance) {
    workerInstance.terminate()
    workerInstance = null
  }

  if (workerBlobUrl) {
    URL.revokeObjectURL(workerBlobUrl)
    workerBlobUrl = null
  }

  for (const [, pending] of pendingRequests) {
    clearTimeout(pending.timer)
    pending.reject(new Error('Worker terminated'))
  }
  pendingRequests.clear()
  sentKeyIds.clear()
  keyBackup.clear()

  if (workerAvailable === true) {
    workerAvailable = null // Allow re-creation
  }
}

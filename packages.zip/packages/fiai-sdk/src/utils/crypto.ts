/**
 * Tiện ích mã hoá/giải mã sử dụng Native Web Crypto API
 * Cung cấp mã hoá AES-256-GCM.
 */

const ALGORITHM = 'AES-GCM'
const KEY_LENGTH = 256
const IV_LENGTH = 12 // Khuyến cáo 12 bytes cho AES-GCM

const isBrowser = typeof window !== 'undefined'

/**
 * LỚP BẢO VỆ CHỐNG MONKEY PATCHING (Defense in Depth)
 * Trích xuất các hàm gốc ngay khi module được load để tránh bị hacker ghi đè sau này.
 */
const _subtle = isBrowser ? window?.crypto?.subtle : (null as any)
const _decrypt = isBrowser ? _subtle?.decrypt?.bind(_subtle) : (null as any)
const _encrypt = isBrowser ? _subtle?.encrypt?.bind(_subtle) : (null as any)
const _importKey = isBrowser ? _subtle?.importKey?.bind(_subtle) : (null as any)
const _exportKey = isBrowser ? _subtle?.exportKey?.bind(_subtle) : (null as any)
const _generateKey = isBrowser ? _subtle?.generateKey?.bind(_subtle) : (null as any)
const _deriveKey = isBrowser ? _subtle?.deriveKey?.bind(_subtle) : (null as any)

/**
 * LỚP PHÒNG THỦ DỮ LIỆU PLAINTEXT (Anti-Hooking)
 * Đóng băng các hàm xử lý chuỗi và JSON để tránh hacker đánh chặn dữ liệu sau khi giải mã.
 */
const _JSON = isBrowser ? window.JSON : (null as any)
const _parse = isBrowser ? _JSON?.parse?.bind(_JSON) : (null as any)
const _stringify = isBrowser ? _JSON?.stringify?.bind(_JSON) : (null as any)

const _TextDecoder = isBrowser ? window.TextDecoder : (null as any)
const _decode = isBrowser ? _TextDecoder?.prototype?.decode : (null as any)

const _TextEncoder = isBrowser ? window.TextEncoder : (null as any)
const _encode = isBrowser ? _TextEncoder?.prototype?.encode : (null as any)

const _getRandomValues = isBrowser
  ? window?.crypto?.getRandomValues?.bind(window.crypto)
  : (null as any)

/**
 * Kiểm tra tính toàn vẹn của Crypto API
 * Nếu hacker ghi đè, hàm .toString() sẽ không còn chứa "[native code]"
 */
export function checkCryptoIntegrity(): boolean {
  try {
    const isNative = (fn: (...args: any[]) => any) => fn.toString().includes('[native code]')
    return (
      isNative(_subtle?.decrypt) &&
      isNative(_subtle?.encrypt) &&
      isNative(_subtle?.importKey) &&
      isNative(_subtle?.generateKey)
    )
  } catch {
    return false
  }
}

/**
 * Sinh một CryptoKey ngẫu nhiên dùng cho AES-256-GCM
 */
export async function generateKey(): Promise<CryptoKey> {
  return await _generateKey(
    {
      name: ALGORITHM,
      length: KEY_LENGTH,
    },
    true, // extractable
    ['encrypt', 'decrypt'],
  )
}

/**
 * Trích xuất CryptoKey thành chuỗi Base64url an toàn cho URL
 */
export async function exportKey(key: CryptoKey): Promise<string> {
  const exported = await _exportKey('raw', key)
  const uint8Array = new Uint8Array(exported)
  let binary = ''
  for (let i = 0; i < uint8Array.byteLength; i++) {
    binary += String.fromCharCode(uint8Array[i] as number)
  }
  const base64 = btoa(binary)
  // Convert base64 to base64url
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

/**
 * Khôi phục CryptoKey từ chuỗi Base64url
 */
export async function importKey(keyStr: string): Promise<CryptoKey> {
  // Convert base64url to base64
  let base64 = keyStr.replace(/-/g, '+').replace(/_/g, '/')
  while (base64.length % 4) {
    base64 += '='
  }
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i)
  }

  return await _importKey('raw', bytes.buffer, { name: ALGORITHM }, false, ['encrypt', 'decrypt'])
}

/**
 * Nhập CryptoKey từ định dạng raw (ArrayBuffer)
 */
export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer)
  let binary = ''
  const len = bytes.byteLength
  for (let i = 0; i < len; i += 8192) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192) as any)
  }
  return btoa(binary)
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64)
  const len = binary.length
  const bytes = new Uint8Array(len)
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i)
  }
  return bytes.buffer
}

export async function importRawKey(buffer: ArrayBuffer): Promise<CryptoKey> {
  return await _importKey('raw', buffer, { name: ALGORITHM }, false, ['encrypt', 'decrypt'])
}

/**
 * Mã hoá dữ liệu
 * @param key Khoá AES-GCM
 * @param data Dữ liệu cần mã hoá
 * @returns Đối tượng chứa ciphertext (ArrayBuffer) và iv (Uint8Array)
 */
export function serializePayload(data: unknown): Uint8Array {
  if (data === undefined) {
    // Flag 3: Undefined
    const encoded = new Uint8Array(1)
    encoded[0] = 3
    return encoded
  }
  if (data instanceof ArrayBuffer) {
    // Flag 1: Binary
    const encoded = new Uint8Array(data.byteLength + 1)
    encoded[0] = 1
    encoded.set(new Uint8Array(data), 1)
    return encoded
  } else if (ArrayBuffer.isView(data)) {
    // Flag 1: Binary
    const encoded = new Uint8Array(data.byteLength + 1)
    encoded[0] = 1
    encoded.set(new Uint8Array(data.buffer, data.byteOffset, data.byteLength), 1)
    return encoded
  } else if (typeof data === 'string') {
    // Flag 2: String
    const encoder = new _TextEncoder()
    const strBuffer = _encode.call(encoder, data)
    const encoded = new Uint8Array(strBuffer.byteLength + 1)
    encoded[0] = 2
    encoded.set(strBuffer, 1)
    return encoded
  } else {
    // Flag 0: JSON
    const jsonStr = _stringify(data, (_key: string, value: any) => {
      if (value instanceof ArrayBuffer) {
        return {
          type: 'Buffer',
          data: arrayBufferToBase64(value),
        }
      }
      if (ArrayBuffer.isView(value)) {
        return {
          type: 'Buffer',
          // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
          data: arrayBufferToBase64(value.buffer as unknown as ArrayBuffer),
        }
      }
      return value
    })
    const encoder = new _TextEncoder()
    const jsonEncoded = _encode.call(encoder, jsonStr)
    const encoded = new Uint8Array(jsonEncoded.byteLength + 1)
    encoded[0] = 0
    encoded.set(jsonEncoded, 1)
    return encoded
  }
}

/**
 * Mã hoá dữ liệu
 * @param key Khoá AES-GCM
 * @param data Dữ liệu cần mã hoá
 * @returns Đối tượng chứa ciphertext (ArrayBuffer) và iv (Uint8Array)
 */
export async function encryptPayload(
  key: CryptoKey,
  data: unknown,
): Promise<{ ciphertext: ArrayBuffer; iv: Uint8Array }> {
  const iv = _getRandomValues(new Uint8Array(IV_LENGTH))
  const encoded = serializePayload(data)

  const ciphertext = await _encrypt(
    {
      name: ALGORITHM,
      iv: iv as BufferSource,
    },
    key,
    encoded,
  )

  return { ciphertext, iv }
}

/**
 * Giải mã dữ liệu
 * @param key Khoá AES-GCM
 * @param ciphertext Dữ liệu mã hoá dạng ArrayBuffer
 * @param iv Vector khởi tạo dạng Uint8Array
 * @returns Dữ liệu gốc sau khi giải mã và parse
 */
export function deserializePayload<T = unknown>(decryptedBuffer: any): T {
  if (!decryptedBuffer || decryptedBuffer.byteLength === 0) {
    return undefined as unknown as T
  }
  const view = new Uint8Array(decryptedBuffer)
  if (view.length === 0) {
    return undefined as unknown as T
  }
  const flag = view[0]
  if (flag === 3) {
    return undefined as unknown as T
  }
  const actualData = new Uint8Array(view.length - 1)
  actualData.set(view.subarray(1))

  if (flag === 1) {
    return actualData.buffer as any as T
  } else if (flag === 2) {
    const decoder = new _TextDecoder()
    return _decode.call(decoder, actualData)
  } else {
    const decoder = new _TextDecoder()
    const decodedStr = _decode.call(decoder, actualData)
    return _parse(decodedStr, (_key: string, value: any) => {
      if (value && value.type === 'Buffer' && typeof value.data === 'string') {
        return base64ToArrayBuffer(value.data)
      }
      if (value && value.type === 'Buffer' && Array.isArray(value.data)) {
        return new Uint8Array(value.data).buffer
      }
      return value
    }) as T
  }
}

/**
 * Giải mã dữ liệu
 * @param key Khoá AES-GCM
 * @param ciphertext Dữ liệu mã hoá dạng ArrayBuffer
 * @param iv Vector khởi tạo dạng Uint8Array
 * @returns Dữ liệu gốc sau khi giải mã và parse
 */
export async function decryptPayload<T = unknown>(
  key: CryptoKey,
  ciphertext: ArrayBuffer,
  iv: Uint8Array,
): Promise<T> {
  try {
    const decryptedBuffer = await _decrypt(
      {
        name: ALGORITHM,
        iv: iv as BufferSource,
      },
      key,
      ciphertext,
    )

    return deserializePayload<T>(decryptedBuffer)
  } catch (error) {
    throw new Error('Failed to decrypt payload', { cause: error })
  }
}

/**
 * Mã hoá dữ liệu thô (không thêm flag)
 */
export async function encryptRaw(
  key: CryptoKey,
  data: ArrayBuffer | ArrayBufferView,
): Promise<{ ciphertext: ArrayBuffer; iv: Uint8Array }> {
  const iv = _getRandomValues(new Uint8Array(IV_LENGTH))
  const ciphertext = await _encrypt(
    {
      name: ALGORITHM,
      iv: iv as BufferSource,
    },
    key,
    data,
  )
  return { ciphertext, iv }
}

/**
 * Giải mã dữ liệu thô (không xử lý flag)
 */
export async function decryptRaw(
  key: CryptoKey,
  ciphertext: ArrayBuffer,
  iv: Uint8Array,
): Promise<ArrayBuffer> {
  return await _decrypt(
    {
      name: ALGORITHM,
      iv: iv as BufferSource,
    },
    key,
    ciphertext,
  )
}

// ─── Smart Crypto (Auto Worker Offload) ──────────────────────

import {
  workerEncrypt,
  workerDecrypt,
  isWorkerAvailable,
  terminateWorker,
} from './CryptoWorkerPool'

/** Threshold: payloads larger than this (in bytes) are offloaded to Worker */
const WORKER_THRESHOLD_BYTES = 1 * 1024 * 1024 // 1MB

/**
 * Fast heuristic to estimate serialized size of data in bytes.
 */
function estimateSize(data: unknown, depth = 0): number {
  if (data === null || data === undefined) return 4
  if (typeof data === 'string') return data.length
  if (typeof data === 'number' || typeof data === 'boolean') return 8
  if (data instanceof ArrayBuffer) return data.byteLength
  if (ArrayBuffer.isView(data)) return data.byteLength

  if (depth > 5) return 64

  if (typeof data === 'object') {
    let size = 2
    const obj = data as Record<string, unknown>
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        size += key.length + estimateSize(obj[key], depth + 1)
        if (size > WORKER_THRESHOLD_BYTES) return size
      }
    }
    return size
  }

  return 0
}

/**
 * Smart encrypt: automatically offloads to Worker for large payloads.
 */
export async function encryptPayloadSmart(
  key: CryptoKey,
  data: unknown,
): Promise<{ ciphertext: ArrayBuffer; iv: Uint8Array }> {
  const size = estimateSize(data)

  if (size > WORKER_THRESHOLD_BYTES && isWorkerAvailable() && key.extractable) {
    try {
      const rawKey = await _exportKey('raw', key)
      const result = await workerEncrypt(rawKey, data)
      return result
    } catch (err) {
      console.warn('[Crypto] Worker encrypt failed, falling back to main thread:', err)
      return encryptPayload(key, data)
    }
  }

  return encryptPayload(key, data)
}

/**
 * Smart decrypt: automatically offloads to Worker for large payloads.
 */
export async function decryptPayloadSmart<T = unknown>(
  key: CryptoKey,
  ciphertext: ArrayBuffer,
  iv: Uint8Array,
): Promise<T> {
  const size = ciphertext.byteLength

  if (size > WORKER_THRESHOLD_BYTES && isWorkerAvailable() && key.extractable) {
    try {
      const rawKey = await _exportKey('raw', key)
      return await workerDecrypt<T>(rawKey, ciphertext, iv)
    } catch (err) {
      console.warn('[Crypto] Worker decrypt failed, falling back to main thread:', err)
      return decryptPayload<T>(key, ciphertext, iv)
    }
  }

  return decryptPayload<T>(key, ciphertext, iv)
}

export { terminateWorker as terminateCryptoWorker }

/**
 * Sinh salt ngẫu nhiên cho PBKDF2
 */
export function generateSalt(): Uint8Array {
  return _getRandomValues(new Uint8Array(16))
}

/**
 * Derive một CryptoKey từ password sử dụng PBKDF2
 */
export async function deriveKeyFromPassword(
  password: string,
  salt: BufferSource,
  iterations: number = 600000,
): Promise<CryptoKey> {
  const encoder = new _TextEncoder()
  const passwordKey = await _importKey('raw', _encode.call(encoder, password), 'PBKDF2', false, [
    'deriveBits',
    'deriveKey',
  ])

  return _deriveKey(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations,
      hash: 'SHA-256',
    },
    passwordKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  )
}

/**
 * Sinh cặp khóa RSA-OAEP 2048-bit
 */
export async function generateRSAKeyPair(): Promise<CryptoKeyPair> {
  return await _generateKey(
    {
      name: 'RSA-OAEP',
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    false,
    ['encrypt', 'decrypt'],
  )
}

/**
 * Xuất Public Key thành SPKI
 */
export async function exportPublicKey(key: CryptoKey): Promise<ArrayBuffer> {
  return await _exportKey('spki', key)
}

/**
 * Nhập Public Key từ SPKI
 */
export async function importPublicKey(buffer: ArrayBuffer): Promise<CryptoKey> {
  return await _importKey(
    'spki',
    buffer,
    {
      name: 'RSA-OAEP',
      hash: 'SHA-256',
    },
    true,
    ['encrypt'],
  )
}

/**
 * Xuất khóa đối xứng thành raw
 */
export async function exportRawKey(key: CryptoKey): Promise<ArrayBuffer> {
  return _exportKey('raw', key) as Promise<ArrayBuffer>
}

/**
 * Mã hóa bằng RSA Public Key
 */
export async function encryptWithRSA(
  publicKey: CryptoKey,
  data: ArrayBuffer,
): Promise<ArrayBuffer> {
  return await _encrypt(
    {
      name: 'RSA-OAEP',
    },
    publicKey,
    data,
  )
}

/**
 * Giải mã bằng RSA Private Key
 */
export async function decryptWithRSA(
  privateKey: CryptoKey,
  encryptedData: ArrayBuffer,
): Promise<ArrayBuffer> {
  return await _decrypt(
    {
      name: 'RSA-OAEP',
    },
    privateKey,
    encryptedData,
  )
}

/**
 * Xóa sạch dữ liệu trong Buffer
 */
export function clearBuffer(buffer: ArrayBufferView | ArrayBuffer): void {
  if (buffer instanceof ArrayBuffer) {
    const view = new Uint8Array(buffer)
    view.fill(0)
  } else {
    const view = new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength)
    view.fill(0)
  }
}

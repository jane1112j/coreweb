import { customAlphabet } from 'nanoid'

/**
 * ID Generation Utilities
 *
 * We use nanoid for high-performance, collision-resistant random IDs.
 * Increasing length improves collision resistance exponentially.
 *
 * Comparison of entropy (Total States):
 * - UUID (Hex, 32 chars):  16^32 = 3.4e+38
 * - Nanoid (Base62, 21):   62^21 = 4.4e+37 (Standard)
 * - Nanoid (Base62, 24):   62^24 = 1.0e+43
 *
 * See @https://unkey.dev/blog/uuid-ux for rationale on better ID design.
 */

/**
 * Standard alphabet for generating random IDs.
 * Includes digits, uppercase, and lowercase letters (Base62).
 * This provides higher entropy per character compared to hex.
 */
export const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

const generateId = customAlphabet(alphabet)

/**
 * Generates a random ID.
 * Default length of 21 characters provides collision resistance similar to UUID v4.
 *
 * See @https://unkey.dev/blog/uuid-ux for rationale on better ID design.
 */
export function generateUUID(size = 21) {
  return generateId(size)
}

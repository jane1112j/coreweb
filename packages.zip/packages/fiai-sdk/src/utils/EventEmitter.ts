/**
 * Lightweight typed event emitter
 * Không có dependency ngoài, dùng cho cả SDK side và Frame side
 */

type Listener<T = unknown> = (data: T) => void

export class EventEmitter {
  private listeners = new Map<string, Set<Listener>>()

  /**
   * Đăng ký listener cho event
   * @returns Hàm unsubscribe
   */
  on<T = unknown>(event: string, listener: Listener<T>): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set())
    }
    const set = this.listeners.get(event)!
    set.add(listener as Listener)

    return () => {
      set.delete(listener as Listener)
      if (set.size === 0) {
        this.listeners.delete(event)
      }
    }
  }

  /**
   * Đăng ký listener chỉ chạy 1 lần
   * @returns Hàm unsubscribe
   */
  once<T = unknown>(event: string, listener: Listener<T>): () => void {
    const wrappedListener: Listener<T> = (data) => {
      unsubscribe()
      listener(data)
    }
    const unsubscribe = this.on(event, wrappedListener)
    return unsubscribe
  }

  /**
   * Emit event đến tất cả listeners đã đăng ký
   */
  emit<T = unknown>(event: string, data: T): void {
    const set = this.listeners.get(event)
    if (!set) return
    // Tạo copy để tránh issue khi listener tự remove trong callback
    for (const listener of [...set]) {
      listener(data)
    }
  }

  /**
   * Xoá tất cả listeners (cleanup)
   */
  removeAllListeners(event?: string): void {
    if (event) {
      this.listeners.delete(event)
    } else {
      this.listeners.clear()
    }
  }

  /**
   * Đếm số listeners cho event
   */
  listenerCount(event: string): number {
    return this.listeners.get(event)?.size ?? 0
  }
}

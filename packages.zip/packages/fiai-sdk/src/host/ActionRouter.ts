import type { FrameName } from '~/core/types'

export class ActionRouter {
  private actionToFrame = new Map<string, FrameName>()

  registerActions(frameName: FrameName, actions: string[]): void {
    for (const action of actions) {
      const isSharedAction = action.endsWith(':ping') || action === 'ping'
      const existingOwner = this.actionToFrame.get(action)

      if (!existingOwner) {
        this.actionToFrame.set(action, frameName)
      } else if (existingOwner !== frameName && !isSharedAction) {
        console.warn(
          `[ActionRouter] Action "${action}" already registered by ${existingOwner}. Ignored for ${frameName}`,
        )
      }
    }
  }

  getFrameForAction(action: string): FrameName | undefined {
    return this.actionToFrame.get(action)
  }

  clear(): void {
    this.actionToFrame.clear()
  }
}

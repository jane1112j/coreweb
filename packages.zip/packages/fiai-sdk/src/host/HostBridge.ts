import type { Packet } from '~/bridge/protocol/Packet'
import { EncryptionProvider } from '~/bridge/security/EncryptionProvider'
import { HandshakeProvider } from '~/bridge/security/HandshakeProvider'
import { ChunkManager } from '~/bridge/transport/ChunkManager'
import type { ITransport } from '~/bridge/transport/ITransport'
import { PostMessageTransport } from '~/bridge/transport/PostMessageTransport'
import { CHUNK_SIZE, DEFAULT_TIMEOUT, MAX_PARALLEL_CHUNKS, RAW_CHUNK_SIZE } from '~/core/constants'
import type {
  FrameName,
  RequestData,
  RequestInterceptor,
  RequestOptions,
  ResponseInterceptor,
} from '~/core/types'
import { deserializePayload, serializePayload } from '~/utils/crypto'
import { EventEmitter } from '~/utils/EventEmitter'
import { generateUUID } from '~/utils/ids'
import { ActionRouter } from './ActionRouter'
import type { FrameManager } from './FrameManager'

interface PendingRequest {
  resolve: (value: unknown) => void
  reject: (reason: Error) => void
  timer: ReturnType<typeof setTimeout>
  frameName: FrameName
}

export class HostBridge {
  public readonly emitter = new EventEmitter()
  private frameEncryptions = new Map<FrameName, EncryptionProvider>()
  private sourceToFrame = new WeakMap<Window, FrameName>()
  private pendingRequests = new Map<string, PendingRequest>()
  private transport: ITransport
  private actionRouter = new ActionRouter()
  private timeout: number
  private chunkManager = new ChunkManager()

  public readonly interceptors = {
    request: [] as RequestInterceptor[],
    response: [] as ResponseInterceptor[],
  }

  constructor(
    private frameManager: FrameManager,
    timeout?: number,
  ) {
    this.timeout = timeout ?? DEFAULT_TIMEOUT
    this.transport = new PostMessageTransport(window) // Lắng nghe trên window hiện tại
    this.transport.onMessage((event) => void this.handleMessage(event))
  }

  public on<T = unknown>(event: string, listener: (data: T) => void): () => void {
    return this.emitter.on(event, listener)
  }

  public once<T = unknown>(event: string, listener: (data: T) => void): () => void {
    return this.emitter.once(event, listener)
  }

  public emit<T = unknown>(event: string, data: T): void {
    this.emitter.emit(event, data)
  }

  private async handleMessage(event: MessageEvent) {
    const packet = event.data as Packet
    const origin = event.origin
    if (!packet || typeof packet !== 'object') return

    if (!this.isOriginAllowed(origin)) {
      return
    }

    switch (packet.type) {
      case 'handshake-init':
        if (packet.frameName && packet.data?.publicKey) {
          console.warn(
            `[HostBridge] Handshake init for ${packet.frameName}:`,
            packet.data.publicKey,
          )
          await this.handleHandshake(
            packet.frameName,
            packet.data.publicKey,
            origin,
            event.source as Window,
          )
        }
        break

      case 'ready':
        if (packet.frameName) {
          if (packet.data?.actions) {
            this.actionRouter.registerActions(packet.frameName, packet.data.actions)
          }
          this.frameManager.updateStatus(packet.frameName, 'ready')
          this.emitter.emit(`ready:${packet.frameName}`, null)
        }
        break

      case 'response':
        if (packet.messageId) {
          await this.handleResponse(packet)
        }
        break

      case 'error':
        if (packet.messageId) {
          this.handleError(packet)
        }
        break

      case 'request':
        if (packet.messageId && packet.encryptedPayload && (packet.iv || packet.isAssembled)) {
          await this.handleIframeRequest(packet, this.resolveFrame(event.source, packet), origin)
        }
        break

      case 'event':
        if (packet.encryptedPayload && (packet.iv || packet.isAssembled)) {
          await this.handleIframeEvent(packet, this.resolveFrame(event.source, packet))
        }
        break

      case 'ui-show':
        if (packet.frameName) this.frameManager.showIframe(packet.frameName)
        break

      case 'ui-hide':
        if (packet.frameName) this.frameManager.hideIframe(packet.frameName)
        break

      case 'chunk': {
        let processedPacket = packet
        if (packet.isChunkEncrypted && packet.encryptedPayload && packet.iv) {
          const frameName = this.resolveFrame(event.source, packet)
          const encryption = frameName ? this.frameEncryptions.get(frameName) : undefined
          if (!frameName || !encryption) return

          try {
            const decrypted = await encryption.decryptRaw(packet.encryptedPayload, packet.iv)
            processedPacket = {
              ...packet,
              encryptedPayload: decrypted,
              iv: undefined,
              isChunkEncrypted: false,
            }
          } catch (err) {
            console.error(`[HostBridge] Failed to decrypt chunk from ${frameName}:`, err)
            return
          }
        }

        const assembled = this.chunkManager.assemble(processedPacket)
        if (assembled) {
          const isDecrypted = packet.isChunkEncrypted ?? processedPacket.isChunkEncrypted
          const originalType = assembled.originalType ?? 'response'

          const assembledPacket: Packet = {
            ...packet,
            type: originalType,
            encryptedPayload: assembled.payload,
            iv: isDecrypted ? undefined : assembled.iv,
            isAssembled: true,
          }

          // Xử lý trực tiếp tùy theo type ban đầu
          if (originalType === 'response') {
            await this.handleResponse(assembledPacket)
          } else if (originalType === 'request') {
            await this.handleIframeRequest(
              assembledPacket,
              this.resolveFrame(event.source, assembledPacket),
              origin,
            )
          } else if (originalType === 'event') {
            await this.handleIframeEvent(
              assembledPacket,
              this.resolveFrame(event.source, assembledPacket),
            )
          }
        }
        break
      }
    }
  }

  private async handleHandshake(
    frameName: FrameName,
    publicKeyBuffer: ArrayBuffer,
    origin: string,
    sourceWindow?: Window,
  ) {
    try {
      const publicKey = await HandshakeProvider.importPublicKey(publicKeyBuffer)
      const sessionKey = await EncryptionProvider.generateKey()
      const rawSessionKey = await EncryptionProvider.exportRawKey(sessionKey)
      const encryptedSessionKey = await HandshakeProvider.encryptSessionKey(
        publicKey,
        rawSessionKey,
      )

      this.frameEncryptions.set(frameName, new EncryptionProvider(sessionKey))
      const contentWindow = this.frameManager.getContentWindow(frameName)
      const source = this.asWindow(sourceWindow ?? null)
      if (source) this.sourceToFrame.set(source, frameName)
      if (contentWindow) this.sourceToFrame.set(contentWindow, frameName)

      const targetWindow = contentWindow || sourceWindow
      if (targetWindow) {
        void this.sendPacket(
          {
            type: 'handshake-confirm',
            messageId: generateUUID(),
            data: { encryptedSessionKey },
          },
          origin,
          [encryptedSessionKey],
          targetWindow,
        )
      }
    } catch (err) {
      console.error(`[HostBridge] Handshake failed for ${frameName}:`, err)
    }
  }

  private async handleResponse(packet: Packet) {
    const pending = this.pendingRequests.get(packet.messageId)
    if (!pending) {
      return
    }

    clearTimeout(pending.timer)
    this.pendingRequests.delete(packet.messageId)

    try {
      if (packet.encryptedPayload && (packet.iv || packet.isAssembled)) {
        const encryption = this.frameEncryptions.get(pending.frameName)
        if (!encryption) throw new Error('Missing encryption provider')

        let decrypted
        if (packet.isAssembled && !packet.iv) {
          // Đã được giải mã từng chunk trong quá trình assemble
          decrypted = deserializePayload(packet.encryptedPayload)
        } else {
          // Giải mã toàn bộ (cơ chế cũ)
          decrypted = await encryption.decrypt(packet.encryptedPayload, packet.iv!)
        }

        // Run Response Interceptors
        for (const interceptor of this.interceptors.response) {
          decrypted = await interceptor(decrypted)
        }

        pending.resolve(decrypted)
      } else {
        pending.resolve(packet.data)
      }
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err)
      pending.reject(new Error(`Failed to decrypt response: ${errorMessage}`))
    }
  }

  private handleError(packet: Packet) {
    const pending = this.pendingRequests.get(packet.messageId)
    if (!pending) return

    clearTimeout(pending.timer)
    this.pendingRequests.delete(packet.messageId)
    pending.reject(new Error(packet.data?.message ?? 'Unknown frame error'))
  }

  private async handleIframeRequest(packet: Packet, frameName: FrameName | null, origin: string) {
    if (!frameName) return

    const encryption = this.frameEncryptions.get(frameName)
    if (!encryption) return

    try {
      let decrypted: { action: string; params: unknown }
      if (packet.isAssembled && !packet.iv) {
        decrypted = deserializePayload<{ action: string; params: unknown }>(
          packet.encryptedPayload!,
        )
      } else {
        decrypted = await encryption.decrypt<{ action: string; params: unknown }>(
          packet.encryptedPayload!,
          packet.iv!,
        )
      }
      if (decrypted.action === 'blockchain-bridge' && frameName !== 'blockchain-bridge')
        throw new Error('')

      this.emitter.emit('iframe-request', {
        sourceFrame: frameName,
        messageId: packet.messageId,
        action: decrypted.action,
        params: decrypted.params,
        origin,
      })
    } catch (err) {
      console.error(`[HostBridge] Failed to decrypt request from ${frameName}:`, err)
    }
  }

  private async handleIframeEvent(packet: Packet, frameName: FrameName | null) {
    if (!frameName) return

    const encryption = this.frameEncryptions.get(frameName)
    if (!encryption) return

    try {
      let decrypted: { event: string; payload: unknown }
      if (packet.isAssembled && !packet.iv) {
        decrypted = deserializePayload<{ event: string; payload: unknown }>(
          packet.encryptedPayload!,
        )
      } else {
        decrypted = await encryption.decrypt<{ event: string; payload: unknown }>(
          packet.encryptedPayload!,
          packet.iv!,
        )
      }
      this.emitter.emit(decrypted.event, decrypted.payload)
    } catch (err) {
      console.error(`[HostBridge] Failed to decrypt event from ${frameName}:`, err)
    }
  }

  public async request<T = unknown>(
    action: string,
    params: unknown = {},
    options: RequestOptions = {},
  ): Promise<T> {
    const frameName = this.actionRouter.getFrameForAction(action)
    if (!frameName) throw new Error(`No frame found for action: ${action}`)

    const targetWindow = this.frameManager.getContentWindow(frameName)
    if (!targetWindow) throw new Error(`Iframe "${frameName}" not available`)

    const encryption = this.frameEncryptions.get(frameName)
    if (!encryption) throw new Error(`Session not established for frame: ${frameName}`)

    const messageId = `${action}_${generateUUID()}`
    const requestTimeout = options.timeout ?? this.timeout
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingRequests.delete(messageId)
        reject(new Error(`Request "${action}" timed out after ${requestTimeout}ms`))
      }, requestTimeout)

      this.pendingRequests.set(messageId, {
        resolve: resolve as (value: unknown) => void,
        reject,
        timer,
        frameName,
      })

      const run = async () => {
        try {
          // Run Request Interceptors
          let requestData: RequestData = { action, params }
          for (const interceptor of this.interceptors.request) {
            requestData = await interceptor(requestData)
          }

          const state = this.frameManager.getState(frameName)
          const targetOrigin = new URL(state!.url).origin
          const serialized = serializePayload(requestData)

          if (serialized.byteLength > RAW_CHUNK_SIZE) {
            const chunks = ChunkManager.splitRaw(
              // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
              serialized.buffer as ArrayBuffer,
              RAW_CHUNK_SIZE,
              messageId,
              'request',
            )

            for (let i = 0; i < chunks.length; i += MAX_PARALLEL_CHUNKS) {
              const batch = chunks.slice(i, i + MAX_PARALLEL_CHUNKS)

              // Mã hóa song song cả batch để tăng tốc
              await Promise.all(
                batch.map(async (packet) => {
                  const { ciphertext, iv } = await encryption.encryptRaw(packet.encryptedPayload!)
                  packet.encryptedPayload = ciphertext
                  packet.iv = iv
                  packet.isChunkEncrypted = true

                  this.sendPacket(packet, targetOrigin, [ciphertext, iv.buffer], targetWindow)
                }),
              )

              // Yield event loop
              await new Promise((resolve) => setTimeout(resolve, 0))
            }
          } else {
            // Cơ chế cũ: Mã hóa toàn bộ
            const { ciphertext, iv } = await encryption.encrypt(requestData)
            this.sendPacket(
              { type: 'request', messageId, encryptedPayload: ciphertext, iv },
              targetOrigin,
              [ciphertext, iv.buffer],
              targetWindow,
            )
          }
        } catch (err: unknown) {
          clearTimeout(timer)
          this.pendingRequests.delete(messageId)
          const errorMessage = err instanceof Error ? err.message : String(err)
          reject(new Error(`Encryption failed: ${errorMessage}`))
        }
      }
      void run()
    })
  }

  public async sendResponse(
    frameName: FrameName,
    messageId: string,
    data: unknown,
    origin: string,
  ) {
    const encryption = this.frameEncryptions.get(frameName)
    const targetWindow = this.frameManager.getContentWindow(frameName)
    if (!encryption || !targetWindow) return

    try {
      const serialized = serializePayload(data)

      if (serialized.byteLength > RAW_CHUNK_SIZE) {
        const chunks = ChunkManager.splitRaw(
          // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
          serialized.buffer as ArrayBuffer,
          RAW_CHUNK_SIZE,
          messageId,
          'response',
        )
        for (const packet of chunks) {
          const { ciphertext, iv } = await encryption.encryptRaw(packet.encryptedPayload!)
          packet.encryptedPayload = ciphertext
          packet.iv = iv
          packet.frameName = frameName
          this.sendPacket(packet, origin, [ciphertext, iv.buffer], targetWindow)
        }
      } else {
        const { ciphertext, iv } = await encryption.encrypt(data)
        this.sendPacket(
          { type: 'response', messageId, encryptedPayload: ciphertext, iv },
          origin,
          [ciphertext, iv.buffer],
          targetWindow,
        )
      }
    } catch (err) {
      console.error(`[HostBridge] Failed to send response to ${frameName}:`, err)
    }
  }

  public sendError(frameName: FrameName, messageId: string, message: string, origin: string) {
    const targetWindow = this.frameManager.getContentWindow(frameName)
    if (targetWindow) {
      this.sendPacket(
        { type: 'error', messageId, data: { message } },
        origin,
        undefined,
        targetWindow,
      )
    }
  }

  /**
   * Helper gửi Packet, tự động xử lý Chunking nếu cần
   */
  private sendPacket(
    packet: Packet,
    targetOrigin: string,
    transfer?: Transferable[],
    targetWindow?: Window,
  ) {
    // Nếu có payload lớn, thực hiện chunking
    if (packet.encryptedPayload && packet.encryptedPayload.byteLength > CHUNK_SIZE) {
      const messageId = packet.messageId
      const chunks = ChunkManager.split(packet.encryptedPayload, CHUNK_SIZE, messageId, packet.type)
      if (packet.iv && chunks[0]) chunks[0].iv = packet.iv
      for (const chunk of chunks) chunk.frameName = packet.frameName

      for (let i = 0; i < chunks.length; i += MAX_PARALLEL_CHUNKS) {
        const batch = chunks.slice(i, i + MAX_PARALLEL_CHUNKS)
        batch.forEach((chunk) => {
          // Zero-Copy: Transfer ArrayBuffer thay vì copy
          const transfer = chunk.encryptedPayload ? [chunk.encryptedPayload] : []
          this.transport.send(chunk, targetOrigin, transfer, targetWindow)
        })
        // Tăng delay nhẹ để trình duyệt xử lý kịp (10ms)
        // await new Promise((resolve) => setTimeout(resolve, 0))
      }
    } else {
      this.transport.send(packet, targetOrigin, transfer, targetWindow)
    }
  }

  private isOriginAllowed(origin: string): boolean {
    if (!origin) return false
    // Allow same-origin
    if (typeof window !== 'undefined' && window.location.origin === origin) return true

    // Basic origin validation
    const states = this.frameManager.getAllStates()
    for (const state of Array.from(states.values())) {
      if (state.url && new URL(state.url).origin === origin) return true
    }

    return origin.includes('localhost') // Allow localhost for development
  }

  private asWindow(source: MessageEventSource | null): Window | null {
    if (!source) return null
    if (typeof MessagePort !== 'undefined' && source instanceof MessagePort) return null
    if (typeof ServiceWorker !== 'undefined' && source instanceof ServiceWorker) return null
    return source as Window
  }

  /**
   * Frames on json.iqnb.com share one origin. The session key belongs to the
   * iframe window that sent the message, or to packet.frameName.
   */
  private resolveFrame(source: MessageEventSource | null, packet: Packet): FrameName | null {
    const windowSource = this.asWindow(source)
    if (windowSource) {
      const bySource = this.sourceToFrame.get(windowSource)
      if (bySource && this.frameEncryptions.has(bySource)) return bySource
    }

    if (packet.frameName && this.frameEncryptions.has(packet.frameName)) return packet.frameName
    return null
  }

  public waitForReady(frame: FrameName, timeout?: number): Promise<void> {
    const state = this.frameManager.getState(frame)
    if (state?.status === 'ready') return Promise.resolve()

    const readyTimeout = timeout ?? this.timeout
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        unsubscribe()
        reject(new Error(`Frame "${frame}" not ready after ${readyTimeout}ms`))
      }, readyTimeout)
      const unsubscribe = this.emitter.once(`ready:${frame}`, () => {
        clearTimeout(timer)
        resolve()
      })
    })
  }

  public destroy() {
    this.transport.destroy()
    this.emitter.removeAllListeners()
    for (const pending of Array.from(this.pendingRequests.values())) {
      clearTimeout(pending.timer)
      pending.reject(new Error('HostBridge destroyed'))
    }
    this.pendingRequests.clear()
  }
}

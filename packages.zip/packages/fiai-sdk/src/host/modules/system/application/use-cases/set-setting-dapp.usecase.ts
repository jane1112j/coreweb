import type { IUseCase } from '~/core/interfaces/IUseCase'
import type { FiaiSDK } from '~/host/FiaiSDK'

type SupportedLocale = 'vi' | 'en'

export interface SetSettingDAppUseCaseRequest {
  language?: SupportedLocale
  address?: string | null
}

export interface SetSettingDAppUseCaseResponse {
  success: boolean
  settings?: {
    language?: SupportedLocale
    address?: string | null
  }
}

export class SetSettingDAppUseCase
  implements IUseCase<SetSettingDAppUseCaseRequest, SetSettingDAppUseCaseResponse>
{
  constructor(private readonly sdk: FiaiSDK) {}

  execute(params: SetSettingDAppUseCaseRequest): Promise<SetSettingDAppUseCaseResponse> {
    const domain = window.location.hostname
    return this.sdk.request<SetSettingDAppUseCaseResponse>('setSettingDapp', {
      ...params,
      domain,
    })
  }
}

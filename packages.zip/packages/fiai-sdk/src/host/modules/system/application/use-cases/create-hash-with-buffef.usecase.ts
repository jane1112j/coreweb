import type { FiaiSDK } from '~/host/FiaiSDK'

export interface CreateFileWithBufferParams {
  buffer: number[]
}

export interface CreateFileWithBufferResponse {
  hash: string
}

export class CreateHashWithBufferUseCase {
  constructor(private readonly sdk: FiaiSDK) {}

  dataToHex(bytes: Uint8Array<ArrayBuffer>) {
    if (!bytes || bytes.length === 0) return ''

    let hex = ''
    for (let i = 0; i < bytes.length; i++) {
      hex += bytes[i]?.toString(16).padStart(2, '0')
    }
    return hex
  }

  public async execute(params: CreateFileWithBufferParams): Promise<CreateFileWithBufferResponse> {
    const { buffer } = params
    const bytes = new Uint8Array(buffer)
    const hex = this.dataToHex(bytes)
    const { hash }: any = await this.sdk.request('createHash', { message: hex, isHex: true })

    return { hash }
  }
}

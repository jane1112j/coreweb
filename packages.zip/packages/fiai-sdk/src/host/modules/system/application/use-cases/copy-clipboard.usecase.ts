import type { IUseCase } from '~/core/interfaces/IUseCase'

export interface CopyClipboardParams {
  value: string
}

export class CopyClipboardUseCase implements IUseCase<CopyClipboardParams, { success: boolean }> {
  async execute(params: CopyClipboardParams): Promise<{ success: boolean }> {
    if (typeof window === 'undefined') {
      throw new Error('Clipboard API is only available in the browser')
    }
    if (!params || typeof params.value !== 'string') {
      throw new Error('Invalid parameter: "value" is required and must be a string')
    }
    if (!navigator.clipboard) {
      const textArea = document.createElement('textarea')
      textArea.value = params.value
      textArea.style.position = 'fixed'
      textArea.style.left = '-999999px'
      textArea.style.top = '-999999px'
      document.body.appendChild(textArea)
      textArea.focus()
      textArea.select()
      try {
        document.execCommand('copy')
        textArea.remove()
        return { success: true }
      } catch (err) {
        textArea.remove()
        throw new Error('Fallback clipboard copy failed', { cause: err })
      }
    }
    await navigator.clipboard.writeText(params.value)
    return { success: true }
  }
}

import type { IUseCase } from '~/core/interfaces/IUseCase'

interface GetActiveWalletUseCaseResponse {
  success: boolean
}

export class GetActiveWalletUseCase implements IUseCase<unknown, GetActiveWalletUseCaseResponse> {
  constructor(private readonly sdk: FiaiSDK) {}
  execute(): Promise<GetActiveWalletUseCaseResponse> {
    const domain = window.location.hostname
    return this.sdk.request<GetActiveWalletUseCaseResponse>('getActiveWalletDapp', {
      domain,
    })
  }
}

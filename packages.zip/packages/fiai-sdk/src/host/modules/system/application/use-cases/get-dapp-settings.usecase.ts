import type { FiaiSDK } from '~/host/FiaiSDK'
import type { IUseCase } from '~/core/interfaces/IUseCase'

type SupportedLocale = 'vi' | 'en'

export interface GetDappSettingsUseCaseResponse {
  language: SupportedLocale
  address?: string | null
}

export class GetDappSettingsUseCase
  implements IUseCase<unknown, GetDappSettingsUseCaseResponse>
{
  constructor(private readonly sdk: FiaiSDK) {}

  async execute(): Promise<GetDappSettingsUseCaseResponse> {
    const domain = window.location.hostname
    return await this.sdk.request<GetDappSettingsUseCaseResponse>('getDappSettingsData', { domain })
  }
}

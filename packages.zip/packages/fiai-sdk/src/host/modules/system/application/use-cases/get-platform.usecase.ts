import type { IUseCase } from '~/core/interfaces/IUseCase'

export class GetPlatformUseCase implements IUseCase<unknown, { platform: string }> {
  execute(): Promise<{ platform: string }> {
    return Promise.resolve({
      platform: 'WEB',
    })
  }
}

import type { IUseCase } from '~/core/interfaces/IUseCase'
import type { IWalletModal } from '~/core/interfaces/IWalletModal'

import type { FiaiSDK } from '~/host/FiaiSDK'

export interface ConnectWalletRequest {
  isChooseWallet?: boolean
}

interface ConnectWalletLanguageResponse {
  language: 'vi' | 'en'
}

export class ConnectWalletUseCase implements IUseCase<ConnectWalletRequest, { success: boolean }> {
  constructor(
    private readonly walletModal: IWalletModal,
    private readonly sdk: FiaiSDK,
  ) {}

  execute(request: ConnectWalletRequest): Promise<{ success: boolean }> {
    return new Promise((resolve) => {
      void (async () => {
        const { isChooseWallet = true } = request
        const locale =
          (
            await this.sdk
              .request<ConnectWalletLanguageResponse>('getDappSettings')
              .catch(() => ({ language: 'vi' as const }))
          ).language ?? 'vi'

        let isSettled = false
        let cleanup = () => undefined
        const finish = (result: { success: boolean }) => {
          if (isSettled) return
          isSettled = true
          cleanup()
          resolve(result)
        }

        const { contentWindow } = this.walletModal.show({
          isChooseWallet,
          locale,
          onClose: () => {
            finish({ success: false })
          },
        })
        if (contentWindow) {
          window.miniWalletWindow = contentWindow
        }

        const cleanupActive = this.sdk.on('onSetActiveWallet', () => {
          finish({ success: true })
          this.walletModal.hide()
        })

        cleanup = () => {
          cleanupActive()
        }
      })()
    })
  }
}

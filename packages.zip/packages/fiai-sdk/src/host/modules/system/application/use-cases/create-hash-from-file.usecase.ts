import type { FiaiSDK } from '~/host/FiaiSDK'

export interface CreateFileWithBufferParams {
  file: File
}

export interface CreateFileWithBufferResponse {
  hash: string
}

export class CreateHashFromFileUseCase {
  constructor(private readonly sdk: FiaiSDK) {}

  public async execute(params: CreateFileWithBufferParams): Promise<CreateFileWithBufferResponse> {
    const { file } = params
    if (!file) {
      throw new Error('file parameter is required and must be an instance of File')
    }

    // 1. Khởi tạo session băm trong Frame
    const initResult = await this.sdk.request<{ sessionId: string }>('initHashSession', {})
    const sessionId = initResult.sessionId

    const chunkSize = 1 * 1024 * 1024 // 20MB chunk size
    const totalChunks = Math.ceil(file.size / chunkSize)
    let completedChunks = 0

    // Hàm phụ trợ đọc và gửi chunk song song dựa trên chỉ số index
    const sendChunk = (index: number): Promise<void> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader()
        const chunkOffset = index * chunkSize
        const blob = file.slice(chunkOffset, chunkOffset + chunkSize)

        reader.onload = async (event: any) => {
          try {
            const arrayBuffer = event.target.result
            const uint8Array = new Uint8Array(arrayBuffer)

            await this.sdk.request('updateHashChunk', {
              sessionId,
              chunk: uint8Array,
              chunkIndex: index,
            })

            completedChunks++
            const progress = Number(((completedChunks / totalChunks) * 100).toFixed(1))

            // Bắn event tiến trình cho ứng dụng lắng nghe
            this.sdk.emit('on-process-create-hash-file', {
              progress,
              chunkIndex: completedChunks,
              totalChunks,
              fileName: file.name,
            })

            resolve()
          } catch (err) {
            // eslint-disable-next-line @typescript-eslint/prefer-promise-reject-errors
            reject(err)
          }
        }

        // eslint-disable-next-line @typescript-eslint/prefer-promise-reject-errors
        reader.onerror = (err) => reject(err)
        reader.readAsArrayBuffer(blob)
      })
    }

    // 2. Gửi song song các chunk với giới hạn (concurrency limit) là 4
    const CONCURRENCY_LIMIT = 5
    const indices = Array.from({ length: totalChunks }, (_, i) => i)

    const runWorker = async (): Promise<void> => {
      while (indices.length > 0) {
        const index = indices.shift()
        if (index === undefined) break
        await sendChunk(index)
      }
    }

    const workers = Array.from({ length: Math.min(CONCURRENCY_LIMIT, totalChunks) }, () =>
      runWorker(),
    )
    await Promise.all(workers)

    // 3. Kết thúc session và nhận mã hash Keccak-256 từ Frame
    const finalResult = await this.sdk.request<{
      hash: string
    }>('finalizeHashSession', { sessionId })

    return {
      hash: finalResult.hash,
    }
  }
}

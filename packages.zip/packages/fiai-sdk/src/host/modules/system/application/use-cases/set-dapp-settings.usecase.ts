import type { IUseCase } from '~/core/interfaces/IUseCase'
import type { FiaiSDK } from '~/host/FiaiSDK'

type SupportedLocale = 'vi' | 'en'

export interface SetDappSettingsUseCaseRequest {
  language?: SupportedLocale
  address?: string | null
}

export interface SetDappSettingsUseCaseResponse {
  success: boolean
  settings?: {
    language?: SupportedLocale
    address?: string | null
  }
}

export class SetDappSettingsUseCase
  implements IUseCase<SetDappSettingsUseCaseRequest, SetDappSettingsUseCaseResponse>
{
  constructor(private readonly sdk: FiaiSDK) {}

  execute(params: SetDappSettingsUseCaseRequest): Promise<SetDappSettingsUseCaseResponse> {
    const domain = window.location.hostname
    return this.sdk.request<SetDappSettingsUseCaseResponse>('setDappSettingsData', {
      ...params,
      domain,
    })
  }
}

import type { IUseCase } from '~/core/interfaces/IUseCase'

interface SetActiveWalletUseCaseRequest {
  address: string
}

interface SetActiveWalletUseCaseResponse {
  success: boolean
}

export class SetActiveWalletUseCase implements IUseCase<
  SetActiveWalletUseCaseRequest,
  SetActiveWalletUseCaseResponse
> {
  constructor(private readonly sdk: FiaiSDK) {}
  execute(params: SetActiveWalletUseCaseRequest): Promise<SetActiveWalletUseCaseResponse> {
    const domain = window.location.hostname
    return this.sdk.request<SetActiveWalletUseCaseResponse>('setActiveWalletDapp', {
      ...params,
      domain,
    })
  }
}

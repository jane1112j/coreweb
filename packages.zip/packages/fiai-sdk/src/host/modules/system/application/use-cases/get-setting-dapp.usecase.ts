import type { FiaiSDK } from '~/host/FiaiSDK'
import type { IUseCase } from '~/core/interfaces/IUseCase'

export class GetSettingDAppUseCase implements IUseCase<unknown, { address: string } | null> {
  constructor(private readonly sdk: FiaiSDK) {}
  async execute(): Promise<{ address: string } | null> {
    return await this.sdk.request('getActiveWallet')
  }
}

import type { IUseCase } from '~/core/interfaces/IUseCase'

export class GetFromClipboardUseCase implements IUseCase<void, { value: string }> {
  async execute(): Promise<{ value: string }> {
    if (typeof window === 'undefined') {
      throw new Error('Clipboard API is only available in the browser')
    }
    if (!navigator.clipboard) {
      throw new Error('Clipboard API is not supported by your browser')
    }
    const value = await navigator.clipboard.readText()
    return { value }
  }
}

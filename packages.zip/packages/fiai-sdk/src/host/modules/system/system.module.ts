import { GenericActionHandler } from '~/core/handlers/GenericActionHandler'
import type { ApplicationActionHandler } from '~/core/interfaces/IActionHandler'
import { WalletModal } from '~/host/ui/WalletModal'
import {
  ConnectWalletUseCase,
  CopyClipboardUseCase,
  GetDappSettingsUseCase,
  GetPlatformUseCase,
  GetSettingDAppUseCase,
  SetDappSettingsUseCase,
  SetSettingDAppUseCase,
  GetFromClipboardUseCase,
  CreateHashFromFileUseCase,
  SetActiveWalletUseCase,
  GetActiveWalletUseCase,
} from './application/use-cases'
import { DEFAULT_FRAME_URLS } from '~/core/constants'
import { SystemActions } from '~/core/actions'

import type { FiaiSDK } from '~/host/FiaiSDK'
import { CreateHashWithBufferUseCase } from './application/use-cases/create-hash-with-buffef.usecase'

export class SystemModule {
  constructor(private sdk: FiaiSDK) {}

  public getHandlers(): ApplicationActionHandler[] {
    const walletModal = WalletModal.getInstance(DEFAULT_FRAME_URLS.urlConnectWallet)
    return [
      new GenericActionHandler(SystemActions.COPY_CLIPBOARD, new CopyClipboardUseCase()),
      new GenericActionHandler(SystemActions.GET_PLATFORM, new GetPlatformUseCase()),
      new GenericActionHandler(
        SystemActions.CONNECT_WALLET,
        new ConnectWalletUseCase(walletModal, this.sdk),
      ),
      new GenericActionHandler(SystemActions.GET_SETTING_DAPP, new GetSettingDAppUseCase(this.sdk)),
      new GenericActionHandler(SystemActions.SET_SETTING_DAPP, new SetSettingDAppUseCase(this.sdk)),
      new GenericActionHandler(SystemActions.GET_DAPP_SETTINGS, new GetDappSettingsUseCase(this.sdk)),
      new GenericActionHandler(SystemActions.SET_DAPP_SETTINGS, new SetDappSettingsUseCase(this.sdk)),
      new GenericActionHandler(SystemActions.GET_FROM_CLIPBOARD, new GetFromClipboardUseCase()),
      new GenericActionHandler(
        SystemActions.CREATE_HASH_FROM_FILE,
        new CreateHashFromFileUseCase(this.sdk),
      ),
      new GenericActionHandler(
        SystemActions.CREATE_HASH_WITH_BUFFER,
        new CreateHashWithBufferUseCase(this.sdk),
      ),
      new GenericActionHandler(
        SystemActions.SET_ACTIVE_WALLET,
        new SetActiveWalletUseCase(this.sdk),
      ),
      new GenericActionHandler(
        SystemActions.GET_ACTIVE_WALLET,
        new GetActiveWalletUseCase(this.sdk),
      ),
    ]
  }
}

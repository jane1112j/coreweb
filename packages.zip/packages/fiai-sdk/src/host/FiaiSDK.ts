import { DEFAULT_FRAME_URLS, DEFAULT_TIMEOUT, FRAME_CONFIG_MAP } from '~/core/constants'
import type {
  FiaiOptions,
  FrameName,
  FrameStatus,
  FrameUrlConfig,
  RequestOptions,
} from '~/core/types'
import { FrameClient } from '../client/FrameClient'
import { FrameManager } from './FrameManager'
import { HostBridge } from './HostBridge'
import { SystemModule } from './modules/system'
import { RuntimeManager } from './runtime/RuntimeManager'
export class FiaiSDK {
  private frameManager: FrameManager
  private hostBridge: HostBridge
  public readonly runtime: RuntimeManager
  private _destroyed = false
  private hostActions = new Map<string, (params: unknown) => Promise<unknown>>()

  constructor(frameManager: FrameManager, hostBridge: HostBridge) {
    this.frameManager = frameManager
    this.hostBridge = hostBridge
    this.runtime = new RuntimeManager(this)
    this.setupBridgeListeners()
    this.registerDefaultHostActions()
  }

  private registerDefaultHostActions(): void {
    const systemModule = new SystemModule(this)
    const handlers = [...systemModule.getHandlers()]
    handlers.forEach((handler) => {
      this.registerHostAction(handler.action, (params) => handler.handle(params))
    })
  }

  public registerHostAction(action: string, handler: (params: unknown) => unknown): void {
    this.hostActions.set(action, async (params) => await handler(params))
  }

  private setupBridgeListeners(): void {
    this.hostBridge.on('iframe-request', (data: unknown) => {
      void (async () => {
        const { sourceFrame, messageId, action, params, origin } = data as {
          sourceFrame: FrameName
          messageId: string
          action: string
          params: unknown
          origin: string
        }

        try {
          const result = await this.request(action, params)
          void this.hostBridge.sendResponse(sourceFrame, messageId, result, origin)
        } catch (error: unknown) {
          const errorMessage = error instanceof Error ? error.message : String(error)
          this.hostBridge.sendError(sourceFrame, messageId, errorMessage, origin)
        }
      })()
    })
  }

  static async init(options: FiaiOptions): Promise<FiaiSDK> {
    const win = window as Window & { fiaiSDK?: FiaiSDK }
    if (typeof window !== 'undefined' && win.fiaiSDK && !win.fiaiSDK.isDestroyed) {
      return win.fiaiSDK
    }
    FiaiSDK.validateConfig(options)
    const timeout = options.timeout ?? DEFAULT_TIMEOUT
    const frameUrls = options.frameUrls ?? DEFAULT_FRAME_URLS

    const frameManager = new FrameManager(options.container)
    const hostBridge = new HostBridge(frameManager, timeout)

    const frameNames = Object.values(FRAME_CONFIG_MAP)
    const readyPromises = frameNames.map((name) =>
      hostBridge.waitForReady(name, 10_000).catch(() => {
        return null
      }),
    )

    const frameUrlsWithKey = {} as FrameUrlConfig
    for (const [key, url] of Object.entries(frameUrls) as [keyof FrameUrlConfig, string][]) {
      const hostOrigin = window.location.origin
      let frameUrl = `${url}${url.includes('#') ? '&' : '#'}origin=${encodeURIComponent(hostOrigin)}`

      // Append chainConfig vào blockchain-bridge URL hash
      if (key === 'blockchainBridge' && options.chainConfig) {
        const { rpcUrl, wsUrl, chainId } = options.chainConfig
        frameUrl += `&rpcUrl=${encodeURIComponent(rpcUrl)}`
        frameUrl += `&wsUrl=${encodeURIComponent(wsUrl)}`
        frameUrl += `&chainId=${chainId}`
      }

      frameUrlsWithKey[key] = frameUrl
    }

    frameManager.createAll(frameUrlsWithKey)

    // Wait for all frames to settle
    await Promise.all(readyPromises)
    const sdk = new FiaiSDK(frameManager, hostBridge)
    if (typeof window !== 'undefined') {
      ;(window as Window & { fiaiSDK?: FiaiSDK }).fiaiSDK = sdk

      // Auto-bridge nested SDKs (if running inside an iframe, forward events to parent)
      if (window !== window.parent) {
        const frameName = window.name || 'unknown_frame'
        const parentClient = new FrameClient(frameName as FrameName)
        // Intercept HostBridge emitter to forward events to parent
        const hostEmitter = hostBridge.emitter
        const originalEmit = hostEmitter.emit.bind(hostEmitter)
        hostEmitter.emit = (event: string, data: any) => {
          originalEmit(event, data)

          // Do not forward internal/system events
          if (
            event !== 'handshake-init' &&
            event !== 'iframe-request' &&
            event !== 'ready' &&
            !event.startsWith('ready:')
          ) {
            parentClient.emit(event, data).catch((err: unknown) => {
              console.warn('[FiaiSDK] Auto-bridging emit failed:', err)
            })
          }
        }
      }
    }

    // Pre-warm the runtime service worker under the host app's mount path
    sdk.runtime.setBasePath(options.basePath)
    sdk.runtime.ensureServiceWorker().catch((err) => {
      console.error('[FiaiSDK] Failed to pre-warm runtime Service Worker:', err)
    })

    // Auto-create hidden wallet
    const hiddenWallet = await sdk
      .request<{ address: string }>('getHiddenWallet', {})
      .catch(() => null)
    if (!hiddenWallet?.address) {
      await sdk.request('createHiddenWallet', {}).catch(() => null)
    }

    return sdk
  }

  public async request<T = unknown>(
    action: string,
    params: unknown = {},
    options: RequestOptions = {},
  ): Promise<T> {
    if (this._destroyed) throw new Error('FiaiSDK: SDK đã bị destroy')

    if (this.hostActions.has(action)) {
      const handler = this.hostActions.get(action)!
      try {
        const result = await handler(params)
        return result as T
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : String(err)
        throw new Error(`Host action "${action}" failed: ${errorMessage}`, { cause: err })
      }
    }

    return await this.hostBridge.request<T>(action, params, options)
  }

  public on<T = unknown>(event: string, listener: (data: T) => void): () => void {
    return this.hostBridge.on(event, listener)
  }

  public once<T = unknown>(event: string, listener: (data: T) => void): () => void {
    return this.hostBridge.once(event, listener)
  }

  public emit<T = unknown>(event: string, data: T): void {
    this.hostBridge.emit(event, data)
  }

  getStatus(): Record<FrameName, FrameStatus> {
    const states = this.frameManager.getAllStates()
    const result = {} as Record<FrameName, FrameStatus>
    for (const [name, state] of Array.from(states.entries())) {
      result[name] = state.status
    }
    return result
  }

  public get interceptors() {
    return this.hostBridge.interceptors
  }

  get isDestroyed(): boolean {
    return this._destroyed
  }

  destroy(): void {
    if (this._destroyed) return
    this._destroyed = true
    this.frameManager.destroyAll()
    this.hostBridge.destroy()
    if (typeof window !== 'undefined') {
      delete (window as Window & { fiaiSDK?: FiaiSDK }).fiaiSDK
    }
    console.warn('MetanodeSDK đã bị destroy ✓')
  }

  private static validateConfig(options: FiaiOptions): void {
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      throw new Error('FiaiSDK: Chỉ có thể chạy trong môi trường browser')
    }
    if (
      options.timeout !== undefined &&
      (typeof options.timeout !== 'number' || options.timeout <= 0)
    ) {
      throw new Error('FiaiSDK: "timeout" phải là số dương')
    }
    if (options.container && !(options.container instanceof HTMLElement)) {
      throw new Error('FiaiSDK: "container" phải là một HTMLElement')
    }
    if (options.frameUrls) {
      const requiredKeys = ['blockchainBridge', 'cryptoVault', 'fileProcessor'] as const
      for (const key of requiredKeys) {
        if (!options.frameUrls[key]) throw new Error(`FiaiSDK: Thiếu URL cho ${key}`)
      }
    }
  }
}

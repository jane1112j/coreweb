/**
 * MIME Type Resolver
 *
 * Maps file extensions to HTTP MIME types for correct Content-Type headers
 * when the Service Worker serves files from CacheStorage.
 */

const MIME_MAP: Record<string, string> = {
  // Web essentials
  html: 'text/html',
  htm: 'text/html',
  css: 'text/css',
  js: 'application/javascript',
  mjs: 'application/javascript',
  json: 'application/json',

  // WebAssembly
  wasm: 'application/wasm',

  // Images
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  svg: 'image/svg+xml',
  webp: 'image/webp',
  ico: 'image/x-icon',
  avif: 'image/avif',

  // Fonts
  woff: 'font/woff',
  woff2: 'font/woff2',
  ttf: 'font/ttf',
  otf: 'font/otf',
  eot: 'application/vnd.ms-fontobject',

  // Media
  mp4: 'video/mp4',
  webm: 'video/webm',
  mp3: 'audio/mpeg',
  ogg: 'audio/ogg',

  // Text / Data
  txt: 'text/plain',
  xml: 'application/xml',
  csv: 'text/csv',
  map: 'application/json', // Source maps

  // Manifest
  webmanifest: 'application/manifest+json',
} as const

const DEFAULT_MIME = 'application/octet-stream'

/**
 * Resolve MIME type from a file path based on its extension.
 *
 * @example
 * resolveMimeType('assets/index-abc.js')   // 'application/javascript'
 * resolveMimeType('image.png')             // 'image/png'
 * resolveMimeType('unknown.xyz')           // 'application/octet-stream'
 */
export function resolveMimeType(filePath: string): string {
  const lastDot = filePath.lastIndexOf('.')
  if (lastDot === -1) return DEFAULT_MIME

  const ext = filePath.substring(lastDot + 1).toLowerCase()
  return MIME_MAP[ext] ?? DEFAULT_MIME
}

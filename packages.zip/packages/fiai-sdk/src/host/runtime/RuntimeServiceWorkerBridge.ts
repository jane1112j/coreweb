/**
 * Runtime Service Worker Bridge
 *
 * Manages registration, lifecycle, and communication between the main thread
 * and the wallet-runtime Service Worker. Uses MessageChannel for reliable
 * request/response patterns.
 */

import type { RuntimeFile, SWResponseMessage } from './runtime.types'

/** Timeout for SW message responses (ms) */
const SW_MESSAGE_TIMEOUT = 15_000

/** Timeout for SW registration and activation (ms) */
const SW_ACTIVATION_TIMEOUT = 10_000

export class RuntimeServiceWorkerBridge {
  private registration: ServiceWorkerRegistration | null = null
  private swReady = false

  /**
   * Register the runtime Service Worker.
   *
   * @param swUrl - URL of the compiled SW file (default: '/wallet-runtime-sw.js')
   * @param scope - Scope for the SW (default: '/runtime/')
   */
  async register(
    swUrl: string = '/wallet-runtime-sw.js',
    scope: string = '/wallet-runtime/',
  ): Promise<ServiceWorkerRegistration> {
    if (!('serviceWorker' in navigator)) {
      throw new Error('[RuntimeSW] Service Workers are not supported in this browser.')
    }

    try {
      this.registration = await navigator.serviceWorker.register(swUrl, { scope })

      // Wait for the SW to be active
      await this.waitForActive()
      this.swReady = true

      console.warn(`[RuntimeSW] Service Worker registered and active. Scope: ${scope}`)
      return this.registration
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err)
      throw new Error(`[RuntimeSW] Registration failed: ${errorMessage}`, { cause: err })
    }
  }

  /**
   * Wait for the Service Worker to reach the "active" state.
   * Handles the installing → waiting → active lifecycle transitions.
   */
  private async waitForActive(): Promise<void> {
    if (!this.registration) throw new Error('[RuntimeSW] No registration available')

    // If already active, we're done
    if (this.registration.active) return

    const sw = this.registration.installing ?? this.registration.waiting
    if (!sw) throw new Error('[RuntimeSW] No Service Worker found in registration')

    return new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error('[RuntimeSW] Service Worker activation timed out'))
      }, SW_ACTIVATION_TIMEOUT)

      sw.addEventListener('statechange', () => {
        if (sw.state === 'activated') {
          clearTimeout(timer)
          resolve()
        }
      })

      // Race with navigator.serviceWorker.ready
      void navigator.serviceWorker.ready.then(() => {
        clearTimeout(timer)
        resolve()
      })
    })
  }

  /**
   * Get the active Service Worker, throwing if not ready.
   */
  private getActiveSW(): ServiceWorker {
    const sw = this.registration?.active ?? navigator.serviceWorker.controller
    if (!sw) {
      throw new Error('[RuntimeSW] No active Service Worker. Call register() first.')
    }
    return sw
  }

  /**
   * Send a message to the SW and wait for a response via MessageChannel.
   */
  private sendMessage<T extends SWResponseMessage>(
    message: Record<string, unknown>,
    transfer: Transferable[] = [],
  ): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const sw = this.getActiveSW()
      const channel = new MessageChannel()

      const timer = setTimeout(() => {
        reject(new Error(`[RuntimeSW] Message timed out: ${String(message.type)}`))
      }, SW_MESSAGE_TIMEOUT)

      channel.port1.onmessage = (event: MessageEvent<T>) => {
        clearTimeout(timer)
        const response = event.data

        if (response.type === 'error') {
          reject(new Error((response as SWResponseMessage & { message: string }).message))
        } else {
          resolve(response)
        }
      }

      sw.postMessage(message, [channel.port2, ...transfer])
    })
  }

  /**
   * Install an app's files into CacheStorage via the Service Worker.
   *
   * Files are sent with Transferable ArrayBuffers for zero-copy performance.
   */
  async installApp(appId: string, version: string, files: RuntimeFile[]): Promise<void> {
    if (!this.swReady) {
      throw new Error('[RuntimeSW] Service Worker not ready. Call register() first.')
    }

    // Prepare transferable list for zero-copy
    const transferables: ArrayBuffer[] = []
    const serializedFiles = files.map((f) => {
      transferables.push(f.content)
      return {
        path: f.path,
        mimeType: f.mimeType,
        content: f.content,
      }
    })

    const response = await this.sendMessage(
      {
        type: 'install',
        appId,
        version,
        files: serializedFiles,
      },
      transferables,
    )

    if (response.type !== 'installed') {
      throw new Error(`[RuntimeSW] Unexpected response: ${response.type}`)
    }

    console.warn(`[RuntimeSW] App "${appId}" v${version} installed (${files.length} files)`)
  }

  /**
   * Delete an app's cache from CacheStorage.
   */
  async deleteApp(appId: string): Promise<void> {
    if (!this.swReady) return

    const response = await this.sendMessage({
      type: 'delete',
      appId,
    })

    if (response.type !== 'deleted') {
      throw new Error(`[RuntimeSW] Unexpected response: ${response.type}`)
    }

    console.warn(`[RuntimeSW] App "${appId}" deleted from cache`)
  }

  /**
   * Check if an app exists in CacheStorage and optionally get its version.
   */
  async getAppStatus(appId: string): Promise<{ exists: boolean; version?: string }> {
    if (!this.swReady) return { exists: false }

    const response = await this.sendMessage<
      SWResponseMessage & { exists: boolean; version?: string }
    >({
      type: 'has-app',
      appId,
    })

    if (response.type !== 'app-status') {
      return { exists: false }
    }

    return response.version !== undefined
      ? { exists: response.exists, version: response.version }
      : { exists: response.exists }
  }

  /**
   * Check if the bridge is ready (SW registered and active).
   */
  get isReady(): boolean {
    return this.swReady
  }

  /**
   * Unregister the Service Worker and clean up.
   */
  async destroy(): Promise<void> {
    if (this.registration) {
      await this.registration.unregister()
      this.registration = null
      this.swReady = false
    }
  }
}

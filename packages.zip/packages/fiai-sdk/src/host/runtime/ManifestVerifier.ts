/**
 * Manifest Verifier
 *
 * Verifies the integrity and authenticity of downloaded ZIP bundles
 * using Web Crypto API. Supports SHA-256 hash verification and
 * pluggable signature verification (ECDSA P-256).
 */

export class ManifestVerifier {
  /**
   * Verify the SHA-256 hash of a ZIP binary against the expected hash
   * from the manifest.
   *
   * @param zipBuffer - The raw ZIP binary data
   * @param expectedHash - The expected SHA-256 hex hash from the manifest
   * @returns true if the hash matches
   */
  static async verifyHash(zipBuffer: ArrayBuffer, expectedHash: string): Promise<boolean> {
    if (!expectedHash) {
      console.warn('[ManifestVerifier] No hash provided, skipping verification')
      return true
    }

    const hashBuffer = await crypto.subtle.digest('SHA-256', zipBuffer)
    const actualHash = ManifestVerifier.bufferToHex(hashBuffer)
    const matches = actualHash === expectedHash.toLowerCase()

    if (!matches) {
      console.error(
        `[ManifestVerifier] Hash mismatch!\n  Expected: ${expectedHash}\n  Actual:   ${actualHash}`,
      )
    }

    return matches
  }

  /**
   * Verify the signature of a ZIP binary using ECDSA P-256.
   *
   * @param zipBuffer - The raw ZIP binary data
   * @param signatureHex - The signature in hex format
   * @param publicKeyHex - The public key in hex (raw format, 65 bytes uncompressed)
   * @returns true if the signature is valid
   */
  static async verifySignature(
    zipBuffer: ArrayBuffer,
    signatureHex: string,
    publicKeyHex: string,
  ): Promise<boolean> {
    if (!signatureHex || !publicKeyHex) {
      console.warn('[ManifestVerifier] No signature or public key provided, skipping verification')
      return true
    }

    try {
      const signatureBuffer = ManifestVerifier.hexToBuffer(signatureHex)
      const publicKeyBuffer = ManifestVerifier.hexToBuffer(publicKeyHex)

      const publicKey = await crypto.subtle.importKey(
        'raw',
        publicKeyBuffer,
        { name: 'ECDSA', namedCurve: 'P-256' },
        false,
        ['verify'],
      )

      const isValid = await crypto.subtle.verify(
        { name: 'ECDSA', hash: 'SHA-256' },
        publicKey,
        signatureBuffer,
        zipBuffer,
      )

      if (!isValid) {
        console.error('[ManifestVerifier] Signature verification failed!')
      }

      return isValid
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err)
      console.error(`[ManifestVerifier] Signature verification error: ${errorMessage}`)
      return false
    }
  }

  /**
   * Full verification: hash + signature.
   * Returns true only if both checks pass.
   */
  static async verify(
    zipBuffer: ArrayBuffer,
    expectedHash: string,
    signatureHex: string,
    publicKeyHex: string,
  ): Promise<{ valid: boolean; hashOk: boolean; signatureOk: boolean }> {
    const hashOk = await ManifestVerifier.verifyHash(zipBuffer, expectedHash)

    // Only verify signature if hash passes
    let signatureOk = true
    if (hashOk && signatureHex && publicKeyHex) {
      signatureOk = await ManifestVerifier.verifySignature(zipBuffer, signatureHex, publicKeyHex)
    }

    return {
      valid: hashOk && signatureOk,
      hashOk,
      signatureOk,
    }
  }

  // ─── Helpers ────────────────────────────────────────────────

  /** Convert ArrayBuffer to hex string */
  private static bufferToHex(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer)
    const hexParts: string[] = []
    for (let i = 0; i < bytes.length; i++) {
      hexParts.push(bytes[i]!.toString(16).padStart(2, '0'))
    }
    return hexParts.join('')
  }

  /** Convert hex string to ArrayBuffer */
  private static hexToBuffer(hex: string): ArrayBuffer {
    const cleanHex = hex.startsWith('0x') ? hex.substring(2) : hex
    const bytes = new Uint8Array(cleanHex.length / 2)
    for (let i = 0; i < cleanHex.length; i += 2) {
      bytes[i / 2] = parseInt(cleanHex.substring(i, i + 2), 16)
    }
    return bytes.buffer
  }
}

/**
 * Runtime Iframe Manager
 *
 * Creates and manages the sandboxed iframe that hosts the runtime app.
 * The iframe's src points to a URL under /runtime/{appId}/ which the
 * Service Worker intercepts and serves from CacheStorage.
 */

import { RUNTIME_PATH_PREFIX } from './runtime.types'

/** Sandbox attributes for the runtime iframe */
const IFRAME_SANDBOX = 'allow-scripts allow-forms allow-same-origin allow-popups allow-downloads'

/** Permission policy for the runtime iframe */
const IFRAME_ALLOW = 'publickey-credentials-get; publickey-credentials-create'

export class RuntimeIframe {
  private iframe: HTMLIFrameElement | null = null

  /**
   * Create the runtime iframe and attach it to the given container.
   *
   * IMPORTANT: The Service Worker MUST be registered and active before
   * calling this method, otherwise the fetch for index.html will 404.
   *
   * @param appId - The app identifier (e.g. "connect-wallet")
   * @param container - The DOM element to attach the iframe to
   * @param name - The iframe name attribute (for window.frames access)
   * @returns The created iframe element
   */
  create(
    appId: string,
    container: HTMLElement,
    name: string = 'mini_wallet',
    searchParams?: string,
    pathPrefix: string = RUNTIME_PATH_PREFIX,
  ): HTMLIFrameElement {
    if (this.iframe) {
      this.destroy()
    }

    const prefix = pathPrefix.endsWith('/') ? pathPrefix : `${pathPrefix}/`
    const iframe = document.createElement('iframe')
    iframe.src = `${prefix}${appId}/index.html${searchParams || ''}`
    iframe.name = name
    iframe.allow = IFRAME_ALLOW
    iframe.setAttribute('sandbox', IFRAME_SANDBOX)
    iframe.setAttribute('data-runtime-app', appId)

    Object.assign(iframe.style, {
      width: '100%',
      height: '100%',
      border: 'none',
      display: 'block',
    })

    this.iframe = iframe
    container.appendChild(iframe)

    return iframe
  }

  /**
   * Get the content window of the runtime iframe.
   */
  getContentWindow(): Window | null {
    return this.iframe?.contentWindow ?? null
  }

  /**
   * Get the iframe element.
   */
  getIframe(): HTMLIFrameElement | null {
    return this.iframe
  }

  /**
   * Destroy the iframe and clean up.
   */
  destroy(): void {
    if (this.iframe) {
      this.iframe.remove()
      this.iframe = null
    }
  }
}

/**
 * Runtime Types
 *
 * Core type definitions for the Secure Wallet Runtime Architecture.
 * Defines the contract between main thread, Service Worker, and runtime iframes.
 */

// ─── Manifest ───────────────────────────────────────────────

/** Remote manifest JSON describing a deployable mini-app */
export interface RuntimeManifest {
  /** Display name of the app */
  name: string
  /** Semantic version string (e.g. "1.2.3") */
  version: string
  /** SHA-256 hex hash of the ZIP binary */
  hash: string
  /** Public key for signature verification (hex or base64) */
  pubKey: string
  /** Signature of the ZIP binary (hex or base64) */
  sign: string
  /** Unique identifier for this app */
  id: string
  /** Preferred screen orientation */
  orientation: string
  /** App author */
  author: string
  /** URL to download the ZIP bundle */
  urlZip: string
}

// ─── Runtime Files ──────────────────────────────────────────

/**
 * A single file entry ready to be stored in CacheStorage.
 * Content is always a raw binary buffer; the MIME type determines
 * how the Service Worker serves it.
 */
export interface RuntimeFile {
  /** Relative path within the app (e.g. "index.html", "assets/index-abc.js") */
  path: string
  /** MIME type for the HTTP response (e.g. "text/html") */
  mimeType: string
  /** Raw binary content */
  content: ArrayBuffer
}

// ─── Runtime Lifecycle ──────────────────────────────────────

/** Lifecycle status of a runtime app */
export type RuntimeStatus =
  | 'idle'
  | 'downloading'
  | 'verifying'
  | 'extracting'
  | 'installing'
  | 'ready'
  | 'error'

/** Progress update emitted during download/install */
export interface RuntimeProgress {
  appId: string
  status: RuntimeStatus
  percent: number
  error?: string
}

// ─── Service Worker Messages ────────────────────────────────

/** Messages sent FROM main thread TO Service Worker */
export type SWRequestMessage =
  | {
      type: 'install'
      appId: string
      version: string
      files: Array<{ path: string; mimeType: string; content: ArrayBuffer }>
    }
  | { type: 'delete'; appId: string }
  | { type: 'has-app'; appId: string }

/** Messages sent FROM Service Worker TO main thread */
export type SWResponseMessage =
  | { type: 'installed'; appId: string }
  | { type: 'deleted'; appId: string }
  | { type: 'app-status'; appId: string; exists: boolean; version?: string }
  | { type: 'error'; message: string }

// ─── Constants ──────────────────────────────────────────────

/** Cache name prefix for runtime apps in CacheStorage */
export const RUNTIME_CACHE_PREFIX = 'fiai-runtime-' as const

/** URL path prefix used when the host app is served from the domain root */
export const RUNTIME_PATH_PREFIX = '/wallet-runtime/' as const

/** Version metadata key stored in CacheStorage */
export const RUNTIME_VERSION_KEY = '__version__' as const

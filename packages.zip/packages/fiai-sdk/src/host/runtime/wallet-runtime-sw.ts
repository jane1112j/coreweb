/**
 * Wallet Runtime Service Worker
 *
 * A dedicated Service Worker that intercepts fetch requests under /runtime/{appId}/
 * and serves files from CacheStorage. This enables Vite/React production builds
 * to work correctly with full ES module graph, dynamic imports, and asset resolution.
 *
 * Architecture:
 *   Main thread  →  postMessage({type:'install', appId, version, files})
 *   SW           →  stores files into CacheStorage as proper Response objects
 *   iframe       →  fetch('/runtime/connect-wallet/index.html')
 *   SW           →  intercepts, serves from CacheStorage
 *
 * This file is compiled SEPARATELY from the main SDK bundle and deployed next
 * to the host app's index.html (e.g. /wallet-runtime-sw.js or
 * /admin/wallet-runtime-sw.js). The intercept prefix is the registration
 * scope, so one script works for every mount path.
 */

/// <reference lib="webworker" />

const sw = self as unknown as ServiceWorkerGlobalScope

const RUNTIME_CACHE_PREFIX = 'fiai-runtime-'
const RUNTIME_VERSION_KEY = '__version__'

/** Scope the page registered, e.g. `/wallet-runtime/` or `/admin/wallet-runtime/`. */
function getRuntimePathPrefix(): string {
  const pathname = new URL(sw.registration.scope).pathname
  return pathname.endsWith('/') ? pathname : `${pathname}/`
}

// ─── Lifecycle ──────────────────────────────────────────────

/**
 * Skip waiting — activate immediately on install so we don't need
 * the user to close all tabs before the new SW takes over.
 */
sw.addEventListener('install', () => {
  void sw.skipWaiting()
})

/**
 * Claim all open clients immediately on activation.
 * This ensures the SW starts intercepting requests for existing tabs
 * without requiring a page reload.
 */
sw.addEventListener('activate', (event) => {
  event.waitUntil(sw.clients.claim())
})

// ─── Fetch Interception ─────────────────────────────────────

sw.addEventListener('fetch', (event: FetchEvent) => {
  const url = new URL(event.request.url)
  const runtimePrefix = getRuntimePathPrefix()

  if (!url.pathname.startsWith(runtimePrefix)) return

  event.respondWith(handleRuntimeFetch(url, runtimePrefix))
})

async function handleRuntimeFetch(url: URL, runtimePrefix: string): Promise<Response> {
  // Parse: {base}/wallet-runtime/{appId}/{...path}
  const pathAfterRuntime = url.pathname.substring(runtimePrefix.length)
  console.log('[Wallet Runtime SW] pathAfterRuntime', pathAfterRuntime)
  const slashIndex = pathAfterRuntime.indexOf('/')
  if (slashIndex === -1) {
    return new Response('Not Found', { status: 404, statusText: 'Not Found' })
  }

  const appId = pathAfterRuntime.substring(0, slashIndex)
  const filePath = pathAfterRuntime.substring(slashIndex + 1)

  if (!appId || !filePath) {
    return new Response('Not Found', { status: 404, statusText: 'Not Found' })
  }

  const cacheName = RUNTIME_CACHE_PREFIX + appId

  try {
    const cache = await caches.open(cacheName)
    // Try exact match first
    const cacheKey = `/${filePath}`
    const cachedResponse = await cache.match(cacheKey)

    if (cachedResponse) {
      return cachedResponse
    }

    // Fallback: try index.html for SPA routing (pushState)
    if (!filePath.includes('.')) {
      const indexResponse = await cache.match('/index.html')
      if (indexResponse) {
        return indexResponse
      }
    }

    return new Response(`File not found: ${filePath}`, {
      status: 404,
      statusText: 'Not Found',
    })
  } catch {
    return new Response('Cache error', { status: 500, statusText: 'Internal Error' })
  }
}

// ─── Message Handling ───────────────────────────────────────
sw.addEventListener('message', (event: ExtendableMessageEvent) => {
  const data = event.data as { type: string; [key: string]: unknown }
  if (!data || typeof data.type !== 'string') return

  const port = event.ports[0]
  if (!port) return // Every request expects a MessageChannel reply port

  switch (data.type) {
    case 'install':
      void handleInstall(data as unknown as InstallMessage, port)
      break
    case 'delete':
      void handleDelete(data as unknown as DeleteMessage, port)
      break
    case 'has-app':
      void handleHasApp(data as unknown as HasAppMessage, port)
      break
    default:
      port.postMessage({ type: 'error', message: `Unknown message type: ${data.type}` })
  }
})

// ─── Install ────────────────────────────────────────────────

interface InstallFileEntry {
  path: string
  mimeType: string
  content: ArrayBuffer
}

interface InstallMessage {
  type: 'install'
  appId: string
  version: string
  files: InstallFileEntry[]
}

async function handleInstall(msg: InstallMessage, port: MessagePort): Promise<void> {
  try {
    const { appId, version, files } = msg
    const cacheName = RUNTIME_CACHE_PREFIX + appId

    // Delete old cache first (clean install)
    await caches.delete(cacheName)
    const cache = await caches.open(cacheName)

    // Write all files as proper Response objects
    const puts: Promise<void>[] = []

    for (const file of files) {
      const normalizedPath = file.path.startsWith('/') ? file.path : `/${file.path}`
      const response = new Response(file.content, {
        status: 200,
        statusText: 'OK',
        headers: {
          'Content-Type': file.mimeType,
          'Content-Length': String(file.content.byteLength),
          'Cache-Control': 'no-cache', // SW controls caching, not HTTP cache
          'X-Runtime-Version': version,
        },
      })
      puts.push(cache.put(normalizedPath, response))
    }

    // Store version metadata
    const versionResponse = new Response(version, {
      status: 200,
      headers: { 'Content-Type': 'text/plain' },
    })
    puts.push(cache.put(`/${RUNTIME_VERSION_KEY}`, versionResponse))

    await Promise.all(puts)

    port.postMessage({ type: 'installed', appId })
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err)
    port.postMessage({ type: 'error', message: `Install failed: ${errorMessage}` })
  }
}

// ─── Delete ─────────────────────────────────────────────────

interface DeleteMessage {
  type: 'delete'
  appId: string
}

async function handleDelete(msg: DeleteMessage, port: MessagePort): Promise<void> {
  try {
    const cacheName = RUNTIME_CACHE_PREFIX + msg.appId
    await caches.delete(cacheName)
    port.postMessage({ type: 'deleted', appId: msg.appId })
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err)
    port.postMessage({ type: 'error', message: `Delete failed: ${errorMessage}` })
  }
}

// ─── Has App ────────────────────────────────────────────────

interface HasAppMessage {
  type: 'has-app'
  appId: string
}

async function handleHasApp(msg: HasAppMessage, port: MessagePort): Promise<void> {
  try {
    const cacheName = RUNTIME_CACHE_PREFIX + msg.appId
    const exists = await caches.has(cacheName)
    let version: string | undefined

    if (exists) {
      const cache = await caches.open(cacheName)
      const versionResp = await cache.match(`/${RUNTIME_VERSION_KEY}`)
      if (versionResp) {
        version = await versionResp.text()
      }
    }

    port.postMessage({
      type: 'app-status',
      appId: msg.appId,
      exists,
      version,
    })
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err)
    port.postMessage({ type: 'error', message: `Has-app check failed: ${errorMessage}` })
  }
}

/**
 * Runtime Manager (Orchestrator)
 *
 * Top-level controller that orchestrates the entire runtime lifecycle:
 *   1. Check if app is cached (via SW)
 *   2. If not, fetch manifest and download ZIP (via file-processor frame)
 *   3. Verify hash/signature
 *   4. Convert raw files to RuntimeFile format
 *   5. Install into CacheStorage (via SW)
 *   6. Create sandboxed iframe
 *
 * This is the single entry point that WalletModal calls.
 */

import {
  resolveAppBasePath,
  walletRuntimePaths,
  type WalletRuntimePaths,
} from '~/core/runtime-path'
import type { FiaiSDK } from '../FiaiSDK'
import { resolveMimeType } from './mime-resolver'
import { RuntimeIframe } from './RuntimeIframe'
import { RuntimeServiceWorkerBridge } from './RuntimeServiceWorkerBridge'
import type { RuntimeFile, RuntimeStatus } from './runtime.types'

/** Timeout for waiting on runtime-ready event (ms) */
const SYNC_TIMEOUT = 60_000

export interface RuntimeLoadOptions {
  /** Domain to query for manifest (e.g. "connect-wallet-web.iqnb.com") */
  domain: string
  /** Container element to attach the iframe to */
  container: HTMLElement
  /** Iframe name attribute */
  iframeName?: string
  /** URL search parameters to append (e.g. "?isChooseWallet=true") */
  searchParams?: string
  /** Progress callback */
  onProgress?: (status: RuntimeStatus, percent: number) => void
}

export class RuntimeManager {
  private swBridge: RuntimeServiceWorkerBridge
  private iframes = new Map<string, RuntimeIframe>()
  private swRegistered = false
  private paths: WalletRuntimePaths

  constructor(private readonly sdk: FiaiSDK) {
    this.swBridge = new RuntimeServiceWorkerBridge()
    this.paths = walletRuntimePaths(resolveAppBasePath())
  }

  /**
   * Mount path of the host app. Call before the Service Worker is registered.
   * `/admin` registers `/admin/wallet-runtime-sw.js` with scope `/admin/wallet-runtime/`.
   * Omit the argument to detect the path from the page.
   */
  setBasePath(basePath?: string): void {
    if (this.swRegistered) return
    this.paths = walletRuntimePaths(resolveAppBasePath(basePath))
  }

  /**
   * Ensure the runtime Service Worker is registered.
   * Safe to call multiple times — only registers once.
   */
  async ensureServiceWorker(swUrl?: string, scope?: string): Promise<void> {
    if (this.swRegistered) return

    await this.swBridge.register(swUrl ?? this.paths.swUrl, scope ?? this.paths.scope)
    this.swRegistered = true
  }

  /**
   * Load a runtime app. This is the main entry point.
   *
   * Flow:
   * 1. Ensure SW is registered
   * 2. Check CacheStorage for existing version
   * 3. Fetch manifest via SDK (file-processor frame)
   * 4. If update needed, wait for download + extract
   * 5. Convert files → RuntimeFile[]
   * 6. Install into CacheStorage via SW
   * 7. Create iframe at /runtime/{appId}/index.html
   */
  async loadApp(appId: string, options: RuntimeLoadOptions): Promise<HTMLIFrameElement> {
    const { domain, container, iframeName, onProgress } = options

    // 1. Ensure SW is ready
    onProgress?.('idle', 0)
    await this.ensureServiceWorker()

    // 2. Check if already cached
    const cachedStatus = await this.swBridge.getAppStatus(appId)
    // Listen before getDomainInfo. The frame starts the zip download inside that
    // request and can emit runtime-ready before this method continues.
    const runtimeReady = this.listenForRuntimeReady(domain, onProgress)

    try {
      // 3. Fetch manifest from file-processor
      onProgress?.('downloading', 5)
      const domainInfo = await this.sdk.request<{
        files: Record<string, unknown> | undefined
        updateNeeded: boolean
        version: string
        id: string
      }>('getDomainInfo', { domain })
      // 4. If cached version matches, skip download
      if (
        cachedStatus.exists &&
        cachedStatus.version === domainInfo.version &&
        !domainInfo.updateNeeded
      ) {
        runtimeReady.cancel()
        console.warn(
          `[RuntimeManager] App "${appId}" v${domainInfo.version} already cached, skipping download`,
        )

        onProgress?.('ready', 100)
        return this.createIframe(appId, container, iframeName, options.searchParams)
      }

      // 5. Get files — either already available or wait for download
      let rawFiles: Record<string, unknown>

      if (domainInfo.files && Object.keys(domainInfo.files).length > 0 && !domainInfo.updateNeeded) {
        runtimeReady.cancel()
        rawFiles = domainInfo.files
      } else {
        onProgress?.('downloading', 10)
        rawFiles = await runtimeReady.promise
      }

      // 6. Convert to RuntimeFile format
      onProgress?.('installing', 80)
      const runtimeFiles = RuntimeManager.convertFiles(rawFiles)
      if (runtimeFiles.length === 0) {
        throw new Error(`[RuntimeManager] No valid files to install for "${appId}"`)
      }

      // 7. Install into CacheStorage via SW
      await this.swBridge.installApp(appId, domainInfo.version, runtimeFiles)

      // 8. Create iframe
      onProgress?.('ready', 100)
      return this.createIframe(appId, container, iframeName, options.searchParams)
    } catch (error) {
      runtimeReady.cancel()
      throw error
    }
  }

  /**
   * Wait for the file-processor frame to emit 'runtime-ready' with files.
   * Uses `on` so an unrelated event does not consume the only listener.
   */
  private listenForRuntimeReady(
    domain: string,
    onProgress?: (status: RuntimeStatus, percent: number) => void,
  ): { promise: Promise<Record<string, unknown>>; cancel: () => void } {
    let settled = false
    let unsubscribeProgress = () => {}
    let unsubscribeReady = () => {}
    let unsubscribeError = () => {}
    let timer: ReturnType<typeof setTimeout> | undefined

    const cleanup = () => {
      if (timer) clearTimeout(timer)
      unsubscribeProgress()
      unsubscribeReady()
      unsubscribeError()
    }

    const promise = new Promise<Record<string, unknown>>((resolve, reject) => {
      timer = setTimeout(() => {
        if (settled) return
        settled = true
        cleanup()
        reject(new Error(`[RuntimeManager] Sync timed out for "${domain}" after ${SYNC_TIMEOUT}ms`))
      }, SYNC_TIMEOUT)

      unsubscribeProgress = this.sdk.on(
        'on-process-download-file',
        (data: { domain: string; percent: number; status: string }) => {
          if (data.domain === domain) {
            const mapped = 10 + Math.round(data.percent * 0.6)
            onProgress?.('downloading', mapped)
          }
        },
      )

      unsubscribeReady = this.sdk.on(
        'runtime-ready',
        (data: { domain: string; files?: Record<string, unknown> }) => {
          if (settled || data.domain !== domain || !data.files) return
          settled = true
          cleanup()
          onProgress?.('extracting', 75)
          resolve(data.files)
        },
      )

      unsubscribeError = this.sdk.on(
        'runtime-error',
        (data: { domain: string; message?: string }) => {
          if (settled || data.domain !== domain) return
          settled = true
          cleanup()
          reject(new Error(data.message ?? `Sync failed for "${domain}"`))
        },
      )
    })

    return {
      promise,
      cancel: () => {
        if (settled) return
        settled = true
        cleanup()
      },
    }
  }

  /**
   * Convert raw files (from file-processor) to RuntimeFile format.
   *
   * Handles various content types:
   * - string → TextEncoder → ArrayBuffer
   * - ArrayBuffer → direct
   * - Uint8Array → ArrayBuffer
   * - {data: number[]} (serialized via postMessage) → ArrayBuffer
   */
  static convertFiles(rawFiles: Record<string, unknown>): RuntimeFile[] {
    const result: RuntimeFile[] = []

    for (const [path, content] of Object.entries(rawFiles)) {
      const cleanPath = path.startsWith('/') ? path.substring(1) : path
      const mimeType = resolveMimeType(cleanPath)

      let buffer: ArrayBuffer | null = null

      if (typeof content === 'string') {
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        buffer = new TextEncoder().encode(content).buffer as ArrayBuffer
      } else if (content instanceof ArrayBuffer) {
        buffer = content
      } else if (content instanceof Uint8Array) {
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        buffer = content.buffer as ArrayBuffer
      } else if (content && typeof content === 'object') {
        const obj = content as Record<string, unknown>
        if ('data' in obj && Array.isArray(obj.data)) {
          // Serialized Uint8Array from postMessage: {data: [1,2,3,...]}
          // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
          buffer = new Uint8Array(obj.data as number[]).buffer as ArrayBuffer
        }
      }

      if (buffer) {
        result.push({ path: cleanPath, mimeType, content: buffer })
      }
    }

    return result
  }

  /**
   * Create the sandboxed iframe for a runtime app.
   */
  private createIframe(
    appId: string,
    container: HTMLElement,
    name?: string,
    searchParams?: string,
  ): HTMLIFrameElement {
    // Destroy existing iframe for this app
    const existing = this.iframes.get(appId)
    if (existing) {
      existing.destroy()
    }

    const runtimeIframe = new RuntimeIframe()
    const iframe = runtimeIframe.create(
      appId,
      container,
      name,
      searchParams,
      this.paths.iframePrefix,
    )
    this.iframes.set(appId, runtimeIframe)

    return iframe
  }

  /**
   * Unload an app: destroy iframe and optionally delete cache.
   */
  async unloadApp(appId: string, deleteCache: boolean = false): Promise<void> {
    const runtimeIframe = this.iframes.get(appId)
    if (runtimeIframe) {
      runtimeIframe.destroy()
      this.iframes.delete(appId)
    }

    if (deleteCache) {
      await this.swBridge.deleteApp(appId)
    }
  }

  /**
   * Get the SW bridge (for advanced usage).
   */
  get bridge(): RuntimeServiceWorkerBridge {
    return this.swBridge
  }

  /**
   * Cleanup all iframes and the SW bridge.
   */
  async destroy(): Promise<void> {
    for (const [appId, runtimeIframe] of Array.from(this.iframes.entries())) {
      runtimeIframe.destroy()
      this.iframes.delete(appId)
    }
    await this.swBridge.destroy()
    this.swRegistered = false
  }
}

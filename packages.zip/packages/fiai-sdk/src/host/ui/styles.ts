export const walletModalStyles = `
  @keyframes fiaiFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  @keyframes fiaiSlideIn {
    from { transform: translateX(100%); }
    to { transform: translateX(0); }
  }
  .fiai-modal-overlay {
    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
    z-index: 999999; display: flex; align-items: center; justify-content: flex-end;
    animation: fiaiFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }
  .fiai-modal-container {
    position: relative;
    width: 440px; height: 100vh; background: #09090b;
    border-radius: 32px 0 0 32px;
    border-left: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: -10px 0 40px rgba(0, 0, 0, 0.5);
    display: flex; flex-direction: column; overflow: hidden;
    animation: fiaiSlideIn 0.35s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }
  .fiai-modal-close-btn {
    position: absolute; top: 24px; right: 24px;
    width: 32px; height: 32px; border-radius: 50%;
    background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    font-size: 14px; font-weight: bold; color: rgba(255, 255, 255, 0.6);
    transition: all 0.2s ease; z-index: 10;
    outline: none;
  }
  .fiai-modal-close-btn:hover {
    background: rgba(239, 68, 68, 0.2); border-color: rgba(239, 68, 68, 0.3); color: #ef4444;
  }
`

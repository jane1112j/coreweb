import { walletModalStyles } from './styles'
import type { IWalletModal } from '~/core/interfaces/IWalletModal'
import type { FiaiSDK } from '../FiaiSDK'
import type { RuntimeManager } from '../runtime/RuntimeManager'

/**
 * WalletModal
 *
 * Displays the wallet UI in a slide-in panel.
 * - In dev mode: points iframe directly to localhost
 * - In production: uses RuntimeManager to serve the wallet app
 *   from CacheStorage via a dedicated Service Worker
 */
export class WalletModal implements IWalletModal {
  private static instance: WalletModal | null = null
  private overlay: HTMLDivElement | null = null
  private container: HTMLDivElement | null = null
  private iframe: HTMLIFrameElement | null = null
  private runtimeManager: RuntimeManager | null = null
  private currentLocale: 'vi' | 'en' = 'vi'
  private onClose: (() => void) | null = null

  private constructor(private readonly walletUrl: string = 'http://localhost:3000/') {}

  public static getInstance(url?: string): WalletModal {
    return (WalletModal.instance ??= new WalletModal(url))
  }

  public show(options?: { isChooseWallet?: boolean; locale?: 'vi' | 'en'; onClose?: () => void }): {
    contentWindow: Window | null
  } {
    if (this.overlay) return { contentWindow: this.iframe?.contentWindow ?? null }
    this.currentLocale = options?.locale ?? 'vi'
    this.onClose = options?.onClose ?? null

    // 1. Inject CSS stylesheet
    if (!document.getElementById('fiai-wallet-modal-styles')) {
      const styleTag = document.createElement('style')
      styleTag.id = 'fiai-wallet-modal-styles'
      styleTag.innerHTML =
        walletModalStyles +
        `
        .fiai-modal-loader {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
          color: #a1a1aa;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }
        .fiai-spinner {
          width: 36px;
          height: 36px;
          border: 3px solid rgba(255, 255, 255, 0.1);
          border-radius: 50%;
          border-top-color: #0A84FF;
          animation: fiaiSpin 0.8s linear infinite;
          margin-bottom: 16px;
        }
        @keyframes fiaiSpin {
          to { transform: rotate(360deg); }
        }
        .fiai-progress-bar {
          width: 200px;
          height: 4px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 2px;
          margin-top: 12px;
          overflow: hidden;
        }
        .fiai-progress-fill {
          height: 100%;
          background: #0A84FF;
          border-radius: 2px;
          transition: width 0.3s ease;
          width: 0%;
        }
      `
      document.head.appendChild(styleTag)
    }

    // 2. Create Backdrop Overlay
    this.overlay = document.createElement('div')
    this.overlay.className = 'fiai-modal-overlay'
    this.overlay.onclick = (e) => {
      if (e.target === this.overlay) {
        this.hide()
      }
    }

    // 3. Create Modal Container
    this.container = document.createElement('div')
    this.container.className = 'fiai-modal-container'

    const isLocal =
      window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    if (isLocal) {
      // DEV MODE: Direct iframe to localhost wallet app
      this.iframe = document.createElement('iframe')
      const url = new URL(this.walletUrl)
      if (options?.isChooseWallet) url.searchParams.set('isChooseWallet', 'true')
      if (options?.locale) url.searchParams.set('locale', options.locale)
      this.iframe.src = url.toString()
      this.iframe.name = 'mini_wallet'
      this.iframe.allow = 'publickey-credentials-get; publickey-credentials-create'
      this.iframe.setAttribute(
        'sandbox',
        'allow-scripts allow-forms allow-same-origin allow-downloads',
      )
      this.iframe.setAttribute(
        'allow',
        'publickey-credentials-get; publickey-credentials-create; clipboard-read; clipboard-write',
      )

      Object.assign(this.iframe.style, {
        width: '100%',
        height: '100%',
        border: 'none',
      })
      this.container.appendChild(this.iframe)
      this.overlay.appendChild(this.container)
      document.body.appendChild(this.overlay)
      window.miniWalletWindow = this.iframe.contentWindow
    } else {
      // PRODUCTION MODE: Use RuntimeManager + Service Worker
      const loader = document.createElement('div')
      loader.className = 'fiai-modal-loader'
      const loaderCopy = this.getLoaderCopy()
      loader.innerHTML = `
        <div class="fiai-spinner"></div>
        <div class="fiai-modal-status" style="font-size: 14px; font-weight: 500;">${loaderCopy.secure}</div>
        <div class="fiai-progress-bar"><div class="fiai-progress-fill"></div></div>
      `
      this.container.appendChild(loader)
      this.overlay.appendChild(this.container)
      document.body.appendChild(this.overlay)

      void this.loadDeployedWallet(options?.isChooseWallet, options?.locale)
    }

    window.addEventListener('keydown', this.handleKeyDown)

    return { contentWindow: this.iframe?.contentWindow ?? null }
  }

  /**
   * Load wallet via RuntimeManager (Service Worker + CacheStorage).
   *
   * Flow:
   * 1. Get/create RuntimeManager
   * 2. Call runtimeManager.loadApp() — this handles everything:
   *    - SW registration
   *    - Cache check
   *    - Manifest fetch
   *    - ZIP download (via file-processor)
   *    - File conversion
   *    - CacheStorage install
   *    - iframe creation at /runtime/connect-wallet/index.html
   */
  private async loadDeployedWallet(isChooseWallet?: boolean, locale?: 'vi' | 'en') {
    try {
      const sdk = (window as Window & { fiaiSDK?: FiaiSDK }).fiaiSDK
      if (!sdk) {
        throw new Error('Kernel Communication Layer (FiaiSDK) not found.')
      }

      if (!this.runtimeManager) {
        this.runtimeManager = sdk.runtime
      }

      if (!this.container) return

      // Load the wallet app through the full runtime pipeline
      const searchOptions: { isChooseWallet?: boolean; locale?: 'vi' | 'en' } = {}
      if (isChooseWallet !== undefined) {
        searchOptions.isChooseWallet = isChooseWallet
      }
      if (locale !== undefined) {
        searchOptions.locale = locale
      }

      this.iframe = await this.runtimeManager.loadApp('connect-wallet', {
        domain: 'connect-wallet-web.iqnb.com',
        container: this.container,
        iframeName: 'mini_wallet',
        ...(Object.keys(searchOptions).length > 0
          ? {
              searchParams: this.buildSearchParams(searchOptions),
            }
          : {}),
        onProgress: (status, percent) => {
          this.updateLoaderStatus(status, percent)
        },
      })

      // Remove loader now that iframe is created
      const loader = this.container.querySelector('.fiai-modal-loader')
      if (loader) loader.remove()

      window.miniWalletWindow = this.iframe.contentWindow
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      console.error('[WalletModal] Failed to load deployed wallet:', error)
      this.showErrorUI(errorMessage)
    }
  }

  /**
   * Update the loading UI with progress information.
   */
  private updateLoaderStatus(status: string, percent: number): void {
    if (!this.container) return

    const statusEl = this.container.querySelector('.fiai-modal-status')
    const progressFill = this.container.querySelector<HTMLElement>('.fiai-progress-fill')

    const statusMessages = this.getStatusMessages()

    if (statusEl) {
      statusEl.textContent = statusMessages[status] ?? 'Loading...'
    }

    if (progressFill) {
      progressFill.style.width = `${percent}%`
    }
  }

  /**
   * Show error UI with retry button.
   */
  private showErrorUI(errorMessage: string): void {
    if (!this.container) return
    const loaderCopy = this.getLoaderCopy()

    this.container.innerHTML = `
      <div class="fiai-modal-loader" style="padding: 32px; text-align: center;">
        <div style="font-size: 18px; font-weight: 600; color: #ff453a; margin-bottom: 8px;">${loaderCopy.alert}</div>
        <div style="font-size: 13px; opacity: 0.8; margin-bottom: 24px; max-width: 280px; line-height: 1.5;">${errorMessage}</div>
        <button id="fiai-retry-btn" style="background: #0A84FF; border: none; color: #fff; padding: 10px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: opacity 0.2s;">${loaderCopy.retry}</button>
      </div>
    `
    const retryBtn = document.getElementById('fiai-retry-btn')
    if (retryBtn) {
      retryBtn.onclick = () => {
        if (this.container) {
          const retryCopy = this.getLoaderCopy()
          this.container.innerHTML = `
            <div class="fiai-modal-loader">
              <div class="fiai-spinner"></div>
              <div class="fiai-modal-status" style="font-size: 14px; font-weight: 500;">${retryCopy.secure}</div>
              <div class="fiai-progress-bar"><div class="fiai-progress-fill"></div></div>
            </div>
          `
          void this.loadDeployedWallet()
        }
      }
    }
  }

  public hide(): void {
    if (this.overlay) {
      const onClose = this.onClose
      this.overlay.remove()
      this.overlay = null
      this.container = null
      this.iframe = null
      this.onClose = null
      window.miniWalletWindow = null
      window.removeEventListener('keydown', this.handleKeyDown)
      onClose?.()
    }
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      this.hide()
    }
  }

  private buildSearchParams(options: { isChooseWallet?: boolean; locale?: 'vi' | 'en' }): string {
    const searchParams = new URLSearchParams()

    if (options.isChooseWallet) {
      searchParams.set('isChooseWallet', 'true')
    }

    if (options.locale) {
      searchParams.set('locale', options.locale)
    }

    const query = searchParams.toString()
    return query ? `?${query}` : ''
  }

  private getLoaderCopy() {
    if (this.currentLocale === 'en') {
      return {
        alert: 'System Alert',
        retry: 'Retry Connection',
        secure: 'Securing wallet sync...',
      }
    }

    return {
      alert: 'Canh bao he thong',
      retry: 'Thu lai ket noi',
      secure: 'Dang dong bo vi an toan...',
    }
  }

  private getStatusMessages(): Record<string, string> {
    if (this.currentLocale === 'en') {
      return {
        idle: 'Initializing...',
        downloading: 'Downloading wallet assets...',
        verifying: 'Verifying integrity...',
        extracting: 'Extracting files...',
        installing: 'Installing runtime...',
        ready: 'Ready!',
        error: 'Error occurred',
      }
    }

    return {
      idle: 'Dang khoi tao...',
      downloading: 'Dang tai tai nguyen vi...',
      verifying: 'Dang xac minh toan ven...',
      extracting: 'Dang giai nen tep...',
      installing: 'Dang cai dat runtime...',
      ready: 'San sang!',
      error: 'Da xay ra loi',
    }
  }
}

import { FRAME_CONFIG_MAP, IFRAME_ID_PREFIX } from '~/core/constants'
import type { FrameName, FrameState, FrameUrlConfig } from '~/core/types'

const HIDDEN_IFRAME_STYLES: Partial<CSSStyleDeclaration> = {
  width: '0',
  height: '0',
  border: 'none',
  position: 'absolute',
  top: '-9999px',
  left: '-9999px',
  visibility: 'hidden',
  pointerEvents: 'none',
  display: 'none',
  background: 'transparent',
  backdropFilter: 'none',
  zIndex: '',
}

const HIDDEN_WRAPPER_STYLES: Partial<CSSStyleDeclaration> = {
  display: 'none',
  visibility: 'hidden',
  pointerEvents: 'none',
  width: '0',
  height: '0',
  position: 'absolute',
  top: '-9999px',
  left: '-9999px',
  zIndex: '',
}

export class FrameManager {
  private iframes = new Map<FrameName, HTMLIFrameElement>()
  private states = new Map<FrameName, FrameState>()
  private wrapper: HTMLElement

  constructor(private container: HTMLElement = document.documentElement) {
    this.wrapper = this.getOrCreateWrapper()
  }

  private getOrCreateWrapper(): HTMLElement {
    const tagName = 'fiaisdk-div'
    let wrapper = document.getElementsByTagName(tagName)[0] as HTMLElement

    if (!wrapper) {
      wrapper = document.createElement(tagName)
      wrapper.setAttribute('data-fiai-sdk', 'true')
      Object.assign(wrapper.style, HIDDEN_WRAPPER_STYLES)
      this.container.appendChild(wrapper)
    }

    return wrapper
  }

  createAll(urls: FrameUrlConfig): void {
    for (const [configKey, frameName] of Object.entries(FRAME_CONFIG_MAP)) {
      const url = urls[configKey as keyof FrameUrlConfig]
      if (url) {
        this.createIframe(frameName, url)
      }
    }
  }

  private createIframe(name: FrameName, url: string): HTMLIFrameElement {
    if (this.iframes.has(name)) {
      this.destroyOne(name)
    }

    const iframe = document.createElement('iframe')
    iframe.id = `${IFRAME_ID_PREFIX}${name}`
    iframe.src = url
    iframe.setAttribute('data-metanode-frame', name)
    iframe.setAttribute('sandbox', 'allow-scripts allow-forms allow-same-origin allow-downloads')
    iframe.setAttribute(
      'allow',
      'publickey-credentials-get; publickey-credentials-create; clipboard-read; clipboard-write',
    )

    Object.assign(iframe.style, HIDDEN_IFRAME_STYLES)

    this.states.set(name, { status: 'loading', url })
    this.wrapper.appendChild(iframe)
    this.iframes.set(name, iframe)

    return iframe
  }

  getIframe(name: FrameName): HTMLIFrameElement | undefined {
    return this.iframes.get(name)
  }

  getContentWindow(name: FrameName): Window | null {
    return this.iframes.get(name)?.contentWindow ?? null
  }

  getState(name: FrameName): FrameState | undefined {
    return this.states.get(name)
  }

  getAllStates(): Map<FrameName, FrameState> {
    return new Map(this.states)
  }

  updateStatus(name: FrameName, status: FrameState['status']): void {
    const current = this.states.get(name)
    if (current) {
      this.states.set(name, { ...current, status })
    }
  }

  showIframe(name: FrameName): void {
    const iframe = this.iframes.get(name)
    if (iframe) {
      Object.assign(this.wrapper.style, {
        display: 'block',
        visibility: 'visible',
        width: '100vw',
        height: '100vh',
        position: 'fixed',
        top: '0',
        left: '0',
        zIndex: '999998',
        pointerEvents: 'auto',
      })

      Object.assign(iframe.style, {
        width: '100vw',
        height: '100vh',
        position: 'fixed',
        top: '0',
        left: '0',
        zIndex: '999999',
        visibility: 'visible',
        display: 'block',
        pointerEvents: 'auto',
        background: 'rgba(0,0,0,0.4)',
        backdropFilter: 'blur(4px)',
      })
    }
  }

  hideIframe(name: FrameName): void {
    const iframe = this.iframes.get(name)
    if (iframe) {
      Object.assign(iframe.style, HIDDEN_IFRAME_STYLES)
      Object.assign(this.wrapper.style, HIDDEN_WRAPPER_STYLES)
    }
  }

  destroyOne(name: FrameName): void {
    const iframe = this.iframes.get(name)
    if (iframe) {
      iframe.remove()
      this.iframes.delete(name)
      this.states.set(name, {
        status: 'destroyed',
        url: this.states.get(name)?.url ?? '',
      })
    }
  }

  destroyAll(): void {
    for (const name of Array.from(this.iframes.keys())) {
      this.destroyOne(name)
    }
    if (this.wrapper?.parentNode) {
      this.wrapper.remove()
    }
  }
}

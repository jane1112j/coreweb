import * as cryptoUtils from '~/utils/crypto'

export class HandshakeProvider {
  /**
   * (Client-side) Sinh cặp khóa RSA để bắt đầu handshake
   */
  static async generateKeyPair(): Promise<CryptoKeyPair> {
    return cryptoUtils.generateRSAKeyPair()
  }

  /**
   * (Client-side) Xuất Public Key để gửi cho Host
   */
  static async exportPublicKey(key: CryptoKey): Promise<ArrayBuffer> {
    return cryptoUtils.exportPublicKey(key)
  }

  /**
   * (Host-side) Nhập Public Key từ Client
   */
  static async importPublicKey(buffer: ArrayBuffer): Promise<CryptoKey> {
    return cryptoUtils.importPublicKey(buffer)
  }

  /**
   * (Host-side) Mã hóa Session Key bằng Public Key của Client
   */
  static async encryptSessionKey(
    publicKey: CryptoKey,
    sessionKey: ArrayBuffer,
  ): Promise<ArrayBuffer> {
    return cryptoUtils.encryptWithRSA(publicKey, sessionKey)
  }

  /**
   * (Client-side) Giải mã Session Key bằng Private Key của mình
   */
  static async decryptSessionKey(
    privateKey: CryptoKey,
    encryptedKey: ArrayBuffer,
  ): Promise<ArrayBuffer> {
    return cryptoUtils.decryptWithRSA(privateKey, encryptedKey)
  }
}

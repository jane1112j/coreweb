import * as cryptoUtils from '~/utils/crypto'

export class EncryptionProvider {
  constructor(private key: CryptoKey) {}

  async encrypt(data: unknown): Promise<{ ciphertext: ArrayBuffer; iv: Uint8Array }> {
    return cryptoUtils.encryptPayloadSmart(this.key, data)
  }

  async decrypt<T = unknown>(ciphertext: ArrayBuffer, iv: Uint8Array): Promise<T> {
    return cryptoUtils.decryptPayloadSmart<T>(this.key, ciphertext, iv)
  }

  async encryptRaw(
    data: ArrayBuffer | ArrayBufferView,
  ): Promise<{ ciphertext: ArrayBuffer; iv: Uint8Array }> {
    return cryptoUtils.encryptRaw(this.key, data)
  }

  async decryptRaw(ciphertext: ArrayBuffer, iv: Uint8Array): Promise<ArrayBuffer> {
    return cryptoUtils.decryptRaw(this.key, ciphertext, iv)
  }

  static async generateKey(): Promise<CryptoKey> {
    return cryptoUtils.generateKey()
  }

  static async importRawKey(buffer: ArrayBuffer): Promise<CryptoKey> {
    return cryptoUtils.importRawKey(buffer)
  }

  static async exportRawKey(key: CryptoKey): Promise<ArrayBuffer> {
    return cryptoUtils.exportRawKey(key)
  }
}

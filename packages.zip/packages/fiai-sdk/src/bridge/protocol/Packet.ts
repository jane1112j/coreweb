import type { FrameName } from '~/core/types'

export type MessageType =
  | 'handshake-init'
  | 'handshake-confirm'
  | 'ready'
  | 'request'
  | 'response'
  | 'error'
  | 'event'
  | 'ui-show'
  | 'ui-hide'
  | 'chunk' // Thêm loại tin nhắn phân đoạn

export interface Packet<T = unknown> {
  type: MessageType
  messageId: string // Định danh duy nhất cho toàn bộ message (thay thế requestId)
  frameName?: FrameName | undefined
  encryptedPayload?: ArrayBuffer | undefined
  iv?: Uint8Array | undefined
  data?: T & {
    message?: string
    success?: boolean
    publicKey?: ArrayBuffer
    actions?: string[]
    encryptedSessionKey?: ArrayBuffer
    originalType?: MessageType
  } // Dữ liệu thô (cho handshake, ready, error, hoặc data không mã hóa)
  // Thuộc tính hỗ trợ Chunking
  chunkIndex?: number | undefined
  totalChunks?: number | undefined
  isChunkEncrypted?: boolean | undefined
  isAssembled?: boolean | undefined
}

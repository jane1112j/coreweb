import type { MessageType, Packet } from '../protocol/Packet'

export class ChunkManager {
  private buffers = new Map<
    string,
    {
      chunks: ArrayBuffer[]
      received: number
      total: number
      iv?: Uint8Array | undefined
      originalType?: MessageType | undefined
      timer?: ReturnType<typeof setTimeout> | undefined
    }
  >()
  /**
   * Chia nhỏ ArrayBuffer đã mã hóa thành các chunks
   */
  public static split(
    payload: ArrayBuffer,
    chunkSize: number,
    messageId: string,
    originalType: MessageType,
  ): Packet[] {
    const totalChunks = Math.ceil(payload.byteLength / chunkSize)
    const packets: Packet[] = []

    for (let i = 0; i < totalChunks; i++) {
      const start = i * chunkSize
      const end = Math.min(start + chunkSize, payload.byteLength)
      const chunkData = payload.slice(start, end)

      const packet: Packet = {
        type: 'chunk',
        messageId,
        chunkIndex: i,
        totalChunks,
        encryptedPayload: chunkData,
      }

      if (i === 0) {
        packet.data = { originalType }
      }

      packets.push(packet)
    }

    return packets
  }

  /**
   * Chia nhỏ ArrayBuffer thô thành các chunks (chưa mã hóa)
   */
  public static splitRaw(
    payload: ArrayBuffer,
    chunkSize: number,
    messageId: string,
    originalType: MessageType,
  ): Packet[] {
    const totalChunks = Math.ceil(payload.byteLength / chunkSize)
    const packets: Packet[] = []

    for (let i = 0; i < totalChunks; i++) {
      const start = i * chunkSize
      const end = Math.min(start + chunkSize, payload.byteLength)
      const chunkData = payload.slice(start, end)

      const packet: Packet = {
        type: 'chunk',
        messageId,
        chunkIndex: i,
        totalChunks,
        encryptedPayload: chunkData, // Lưu tạm vào đây, sẽ được mã hóa sau
        isChunkEncrypted: true,
      }

      if (i === 0) {
        packet.data = { originalType }
      }

      packets.push(packet)
    }

    return packets
  }

  /**
   * Lắp ghép chunk nhận được. Trả về ArrayBuffer hoàn chỉnh nếu đã nhận đủ.
   */
  public assemble(packet: Packet): {
    payload: ArrayBuffer
    iv?: Uint8Array | undefined
    originalType?: MessageType | undefined
  } | null {
    const { messageId, chunkIndex, totalChunks, iv, encryptedPayload } = packet
    if (!messageId || chunkIndex === undefined || !totalChunks || !encryptedPayload) {
      console.warn('[ChunkManager] Missing required chunk fields:', {
        messageId,
        chunkIndex,
        totalChunks,
        hasPayload: !!encryptedPayload,
      })
      return null
    }

    if (!this.buffers.has(messageId)) {
      this.buffers.set(messageId, {
        chunks: new Array<ArrayBuffer>(totalChunks),
        received: 0,
        total: totalChunks,
        iv: iv,
        originalType: packet.data?.originalType,
        timer: setTimeout(() => {
          this.reportMissing(messageId)
        }, 30000), // Timeout 30s cho một gói tin lớn
      })
    }

    const buffer = this.buffers.get(messageId)!

    if (iv) buffer.iv = iv

    if (!buffer.chunks[chunkIndex]) {
      buffer.chunks[chunkIndex] = encryptedPayload
      buffer.received++
    }

    if (buffer.received === buffer.total) {
      if (buffer.timer) clearTimeout(buffer.timer)
      const finalPayload = this.concatenateChunks(buffer.chunks)
      const finalIv = buffer.iv
      const originalType = buffer.originalType
      this.buffers.delete(messageId)
      return { payload: finalPayload, iv: finalIv, originalType }
    }

    return null
  }

  private concatenateChunks(chunks: ArrayBuffer[]): ArrayBuffer {
    const totalLength = chunks.reduce((acc, chunk) => acc + chunk.byteLength, 0)
    const result = new Uint8Array(totalLength)
    let offset = 0
    for (const chunk of chunks) {
      result.set(new Uint8Array(chunk), offset)
      offset += chunk.byteLength
    }
    return result.buffer
  }

  public clear(messageId: string) {
    const buffer = this.buffers.get(messageId)
    if (buffer?.timer) clearTimeout(buffer.timer)
    this.buffers.delete(messageId)
  }

  private reportMissing(messageId: string) {
    const buffer = this.buffers.get(messageId)
    if (!buffer) return

    const missing = []
    for (let i = 0; i < buffer.total; i++) {
      if (!buffer.chunks[i]) missing.push(i)
    }
    this.buffers.delete(messageId)
  }
}

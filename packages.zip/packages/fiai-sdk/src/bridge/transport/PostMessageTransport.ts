import type { ITransport } from './ITransport'

export class PostMessageTransport implements ITransport {
  private handlers = new Set<(event: MessageEvent) => void>()
  private messageListener: (event: MessageEvent) => void

  constructor(private targetWindow: Window) {
    this.messageListener = (event: MessageEvent) => {
      for (const handler of this.handlers) {
        handler(event)
      }
    }
    window.addEventListener('message', this.messageListener)
  }

  send(
    message: unknown,
    targetOrigin: string,
    transfer?: Transferable[],
    targetWindow?: Window,
  ): void {
    const win = targetWindow ?? this.targetWindow
    win.postMessage(message, targetOrigin, transfer)
  }

  onMessage(handler: (event: MessageEvent) => void): () => void {
    this.handlers.add(handler)
    return () => this.handlers.delete(handler)
  }

  destroy(): void {
    window.removeEventListener('message', this.messageListener)
    this.handlers.clear()
  }
}

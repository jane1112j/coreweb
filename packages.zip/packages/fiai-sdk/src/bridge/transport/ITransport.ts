export interface ITransport {
  send(
    message: unknown,
    targetOrigin: string,
    transfer?: Transferable[],
    targetWindow?: Window,
  ): void
  onMessage(handler: (event: MessageEvent) => void): () => void
  destroy(): void
}

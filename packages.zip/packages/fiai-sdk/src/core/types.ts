/**
 * Core type definitions for MetanodeSDK
 */

// ─── Chain Configuration ────────────────────────────────────

export interface ChainConfig {
  rpcUrl: string
  wsUrl: string
  chainId: number
}

// ─── SDK Configuration ──────────────────────────────────────

/** Config truyền vào khi khởi tạo SDK */
export interface FiaiOptions {
  container?: HTMLElement
  timeout?: number
  debug?: boolean
  /** Callback nhận tiến độ khởi tạo (0-100) */
  onLoading?: (progress: number) => void
  /** Callback khi khởi tạo thành công */
  onSuccess?: () => void
  /** Callback khi khởi tạo thất bại */
  onError?: (error: Error) => void
  /** URL mapping cho từng frame service */
  frameUrls?: FrameUrlConfig
  /**
   * Callback khi SDK cần hiển thị UI để mở khoá (cho các sensitive actions)
   * Trả về Promise resolve khi mở khoá thành công
   */
  onNeedUnlock?: () => Promise<void>
  /** Chain config cho blockchain-bridge. Nếu không truyền, sẽ dùng public chain mặc định */
  chainConfig?: ChainConfig
  /**
   * Thư mục deploy của web trên domain chung.
   * Ví dụ `'/admin'` → Service Worker tại `/admin/wallet-runtime-sw.js`,
   * scope và iframe tại `/admin/wallet-runtime/`.
   * Bỏ trống để SDK tự lấy từ `<base href>` hoặc URL script `{base}assets/...`.
   * Web ở gốc domain giữ nguyên `/wallet-runtime/`.
   */
  basePath?: string
}

/** URL mapping cho từng frame service */
export interface FrameUrlConfig {
  blockchainBridge: string
  cryptoVault: string
  fileProcessor: string
}

// ─── Frame Identification ───────────────────────────────────

/** Tên định danh cho từng frame service */
export type FrameName = 'blockchain-bridge' | 'crypto-vault' | 'file-processor'

/** Trạng thái lifecycle của mỗi frame */
export type FrameStatus = 'loading' | 'ready' | 'error' | 'destroyed'

/** Thông tin trạng thái chi tiết của frame */
export interface FrameState {
  status: FrameStatus
  url: string
  error?: string
}

// ─── PostMessage Protocol ───────────────────────────────────

/** Nguồn gửi message (để phân biệt SDK vs Frame) */
export type MessageSource = 'fiai-sdk' | 'fiai-frame'

/** Payload cho message loại REQUEST */
export interface RequestPayload<T = unknown> {
  /** Tên action cần frame xử lý */
  action: string
  /** Dữ liệu đi kèm action */
  data: T
}

/** Tuỳ chọn khi gửi request */
export interface RequestOptions {
  /** Timeout riêng cho request này (ms) */
  timeout?: number
}

/** Payload cho message loại RESPONSE */
export interface ResponsePayload<T = unknown> {
  /** Action đã xử lý (mirror từ request) */
  action: string
  /** Thành công hay thất bại */
  success: boolean
  /** Dữ liệu kết quả (khi success = true) */
  data?: T
  /** Thông tin lỗi (khi success = false) */
  error?: string
}

/** Payload cho message loại EVENT */
export interface EventPayload<T = unknown> {
  /** Tên event */
  eventName: string
  /** Dữ liệu event */
  data: T
}

// ─── Callback Types ─────────────────────────────────────────

/** Callback handler cho events từ frame */
export type FrameEventHandler<T = unknown> = (data: T) => void

/** Hàm huỷ đăng ký listener */
export type Unsubscribe = () => void

// ─── Middleware / Interceptors ──────────────────────────────

/** Dữ liệu request trước khi đi vào transport */
export interface RequestData {
  action: string
  params: unknown
}

/**
 * Interceptor cho Request: cho phép sửa đổi action/params
 * hoặc thực hiện logging/validation.
 */
export type RequestInterceptor = (request: RequestData) => Promise<RequestData> | RequestData

/**
 * Interceptor cho Response: cho phép sửa đổi dữ liệu kết quả
 * trước khi trả về cho caller.
 */
export type ResponseInterceptor = (response: unknown) => unknown

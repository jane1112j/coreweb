import type { ApplicationActionHandler } from '../interfaces/IActionHandler'
import type { IUseCase } from '../interfaces/IUseCase'

/**
 * GenericActionHandler - Lớp Handler dùng chung dựa trên Interface IUseCase.
 * Loại bỏ hoàn toàn sự phụ thuộc trực tiếp vật lý giữa tầng Infrastructure và tầng Application.
 */
export class GenericActionHandler<T = unknown, R = unknown> implements ApplicationActionHandler<
  T,
  R
> {
  constructor(
    readonly action: string,
    private readonly useCase: IUseCase<T, R>,
  ) {}

  async handle(params: T): Promise<R> {
    return await this.useCase.execute(params)
  }
}

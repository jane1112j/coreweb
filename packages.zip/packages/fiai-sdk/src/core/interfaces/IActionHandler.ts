/**
 * Interface chuẩn cho tất cả các Action Handlers trong hệ thống Frame
 */
export interface ApplicationActionHandler<P = unknown, R = unknown> {
  /** Tên định danh của action (vd: 'vault:ping') */
  readonly action: string

  /** Hàm thực thi logic của action */
  handle(params: P): Promise<R> | R
}

export interface IUseCase<I = unknown, O = unknown> {
  execute(params: I): O | Promise<O>
}

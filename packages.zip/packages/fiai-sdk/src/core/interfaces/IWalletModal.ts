export interface IWalletModal {
  show(options?: {
    isChooseWallet?: boolean
    locale?: 'vi' | 'en'
    onClose?: () => void
  }): {
    contentWindow: Window | null
  }
  hide(): void
}

/**
 * Định nghĩa tập trung các action names của System (Host)
 */
export const SystemActions = {
  COPY_CLIPBOARD: 'copy-clipboard',
  GET_PLATFORM: 'getPlatform',
  CONNECT_WALLET: 'connect-wallet',
  GET_SETTING_DAPP: 'getSettingDApp',
  SET_SETTING_DAPP: 'setSettingDApp',
  GET_DAPP_SETTINGS: 'getDappSettings',
  SET_DAPP_SETTINGS: 'setDappSettings',
  GET_FROM_CLIPBOARD: 'get-from-clipboard',
  CREATE_HASH_FROM_FILE: 'createHashFromFile',
  CREATE_HASH_WITH_BUFFER: 'createHashWithBuffer',
  SET_ACTIVE_WALLET: 'setActiveWallet',
  GET_ACTIVE_WALLET: 'getActiveWallet',
} as const

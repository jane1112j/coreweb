/**
 * Wallet runtime URLs follow the host app's mount path.
 * A site at / uses /wallet-runtime/. A site at /admin uses /admin/wallet-runtime/.
 */

export const WALLET_RUNTIME_SEGMENT = 'wallet-runtime'
export const WALLET_RUNTIME_SW_FILE = 'wallet-runtime-sw.js'

export interface WalletRuntimePaths {
  swUrl: string
  scope: string
  iframePrefix: string
}

/** Leading slash, trailing slash. Root is "/". */
export function normalizeAppBasePath(basePath: string): string {
  let value = basePath.trim()
  if (!value || value === '/' || value === '.' || value === './') return '/'

  if (value.startsWith('http://') || value.startsWith('https://')) {
    try {
      value = new URL(value).pathname
    } catch {
      return '/'
    }
  }

  if (!value.startsWith('/')) value = `/${value}`
  value = value.replace(/\/{2,}/g, '/')
  if (!value.endsWith('/')) value = `${value}/`
  return value
}

/**
 * Directory the page was actually built into.
 * Vite emits the app entry at `{base}assets/...`, so `/admin/assets/index-xxxx.js`
 * means the app base is `/admin/`.
 */
export function detectAppBasePath(): string {
  if (typeof document === 'undefined' || typeof window === 'undefined') return '/'

  const fromBase = readBaseElement()
  if (fromBase) return fromBase

  const fromScript = readAssetsScriptBase()
  if (fromScript) return fromScript

  return '/'
}

export function resolveAppBasePath(explicit?: string): string {
  if (explicit != null && explicit !== '' && explicit !== '.' && explicit !== './') {
    return normalizeAppBasePath(explicit)
  }
  return detectAppBasePath()
}

export function walletRuntimePaths(appBasePath: string): WalletRuntimePaths {
  const base = normalizeAppBasePath(appBasePath)
  const root = base === '/' ? '' : base.slice(0, -1)
  const scope = `${root}/${WALLET_RUNTIME_SEGMENT}/`
  return {
    swUrl: `${root}/${WALLET_RUNTIME_SW_FILE}`,
    scope,
    iframePrefix: scope,
  }
}

function readBaseElement(): string | null {
  const href = document.querySelector('base')?.getAttribute('href')
  if (!href || href === '.' || href === './') return null

  try {
    const url = new URL(href, window.location.href)
    if (url.origin !== window.location.origin) return null
    return normalizeAppBasePath(url.pathname)
  } catch {
    return null
  }
}

function readAssetsScriptBase(): string | null {
  const scripts = document.querySelectorAll('script[src]')
  for (const node of scripts) {
    const script = node as HTMLScriptElement
    const raw = script.src || script.getAttribute('src') || ''
    if (!raw) continue

    let url: URL
    try {
      url = new URL(raw, window.location.href)
    } catch {
      continue
    }
    if (url.origin !== window.location.origin) continue

    const assetsIndex = url.pathname.lastIndexOf('/assets/')
    if (assetsIndex < 0) continue
    return normalizeAppBasePath(url.pathname.slice(0, assetsIndex + 1))
  }
  return null
}

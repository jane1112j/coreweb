/**
 * SDK Constants
 */
import type { FrameName } from './types'

/** Message source identifier cho SDK side */
export const SDK_SOURCE = 'fiai-sdk' as const

/** Message source identifier cho Frame side */
export const FRAME_SOURCE = 'fiai-frame' as const

/** Timeout mặc định chờ frame ready (ms) */
export const DEFAULT_TIMEOUT = 30_000
export const CHUNK_SIZE = 4 * 1024 * 1024 // 1MB (Transport limit)
export const RAW_CHUNK_SIZE = CHUNK_SIZE - 16384 // Chừa khoảng trống cho metadata và encryption overhead (tag 16 bytes + IV)

export const MAX_PARALLEL_CHUNKS = 1

/** Danh sách tất cả frame names */
export const FRAME_NAMES: readonly FrameName[] = [
  'blockchain-bridge',
  'crypto-vault',
  'file-processor',
] as const

/** Mapping từ config key sang frame name */
export const FRAME_CONFIG_MAP: Record<string, FrameName> = {
  blockchainBridge: 'blockchain-bridge',
  cryptoVault: 'crypto-vault',
  fileProcessor: 'file-processor',
} as const

/** Prefix cho iframe element IDs */
export const IFRAME_ID_PREFIX = 'fiai-frame-' as const

/** URL mặc định cho các iframes (được inject từ env khi build) */
export const DEFAULT_FRAME_URLS = {
  blockchainBridge: process.env.FIAI_BLOCKCHAIN_BRIDGE_URL || 'http://localhost:6001',
  cryptoVault: process.env.FIAI_CRYPTO_VAULT_URL || 'http://localhost:6002',
  fileProcessor: process.env.FIAI_FILE_PROCESSOR_URL || 'http://localhost:6003',
  urlConnectWallet: process.env.VITE_URL_CONNECT_WALLET || 'http://localhost:6005',
} as const

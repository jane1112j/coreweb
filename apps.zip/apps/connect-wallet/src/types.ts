export interface FinSdk {
  init: (config: {
    onProgress?: (percent: string) => void
    onFinish?: () => Promise<void>
    onError?: (error: unknown) => void
  }) => void
}

declare global {
  interface Window {
    finSdk?: FinSdk
    isHasNotch?: boolean
  }
}

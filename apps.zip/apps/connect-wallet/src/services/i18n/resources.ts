import enCommon from './en/common.json'
import viCommon from './vi/common.json'

export const resources = {
  en: {
    common: enCommon,
  },
  vi: {
    common: viCommon,
  },
} as const

export const defaultNS = 'common'

export type Resources = typeof resources

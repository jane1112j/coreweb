import { sendCommand } from '@metanodejs/system-core'
import { isSupportedLanguage, type Locale } from './utils'

interface LanguageResponse {
  language?: string
}

const DEFAULT_LANGUAGE: Locale = 'vi'

export async function getCoreLanguage(): Promise<Locale> {
  try {
    const response = (await sendCommand('getDappSettings')) as LanguageResponse

    if (response?.language && isSupportedLanguage(response.language)) {
      return response.language
    }
  } catch (error) {
    console.error('Failed to load language from core:', error)
  }

  return DEFAULT_LANGUAGE
}

export async function setCoreLanguage(locale: Locale): Promise<boolean> {
  try {
    const result = (await sendCommand('setDappSettings', { language: locale })) as
      | boolean
      | { success?: boolean }

    if (typeof result === 'boolean') {
      return result
    }

    return Boolean(result?.success)
  } catch (error) {
    console.error('Failed to set language in core:', error)
    return false
  }
}

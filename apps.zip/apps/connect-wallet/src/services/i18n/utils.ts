export type Locale = 'vi' | 'en'

const SUPPORTED_LANGUAGES: Locale[] = ['vi', 'en']

export function isSupportedLanguage(value: string): value is Locale {
  return SUPPORTED_LANGUAGES.includes(value as Locale)
}

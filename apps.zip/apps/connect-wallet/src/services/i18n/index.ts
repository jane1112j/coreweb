import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import { defaultNS, resources } from './resources'
import { isSupportedLanguage, type Locale } from './utils'

function resolveInitialLanguage(): Locale {
  try {
    const locale = new URLSearchParams(window.location.search).get('locale')
    if (locale && isSupportedLanguage(locale)) {
      return locale
    }
  } catch (error) {
    console.warn('[connect-wallet i18n] Failed to resolve initial locale from URL:', error)
  }

  return 'vi'
}

const initialLanguage: Locale = resolveInitialLanguage()

i18n.use(initReactI18next).init({
  resources,
  lng: initialLanguage,
  fallbackLng: 'vi',
  defaultNS,
  debug: import.meta.env.DEV,
  interpolation: {
    escapeValue: false,
  },
})

export async function applyLanguage(locale: Locale): Promise<void> {
  await i18n.changeLanguage(locale)
}

export { i18n }

export function ConnectWalletPageLoading() {
  return (
    <div className="flex-1 flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-white/10 border-t-blue-500 rounded-full animate-spin" />
    </div>
  )
}

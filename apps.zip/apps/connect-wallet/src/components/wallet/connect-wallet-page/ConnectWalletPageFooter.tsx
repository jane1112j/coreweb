import { DrawerFooter } from '@/components/wallet/wallet-drawer/DrawerFooter'
import { useTranslation } from 'react-i18next'

interface ConnectWalletPageFooterProps {
  hasWallets: boolean
  onSelectWallet: () => void
}

export function ConnectWalletPageFooter({
  hasWallets,
  onSelectWallet,
}: ConnectWalletPageFooterProps) {
  const { t } = useTranslation()

  return (
    <div className="mt-auto pt-6 space-y-4">
      {hasWallets && (
        <button
          onClick={onSelectWallet}
          className="w-full text-center text-sm text-zinc-400 hover:text-white transition-colors py-2"
        >
          {t('wallet.footer.alreadyHaveWallet')}{' '}
          <span className="text-emerald-400 font-medium">{t('wallet.footer.selectItHere')}</span>
        </button>
      )}
      <DrawerFooter onSupport={() => console.log('Support clicked')} />
    </div>
  )
}

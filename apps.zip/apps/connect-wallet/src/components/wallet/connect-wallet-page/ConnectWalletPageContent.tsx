import { TabsContent } from '@/components/ui/tabs'
import { CreateWalletInitial } from '@/components/wallet/wallet-drawer/CreateWalletInitial'
import { CreateWalletSeed } from '@/components/wallet/wallet-drawer/CreateWalletSeed'
import { ImportWalletInitial } from '@/components/wallet/wallet-drawer/ImportWalletInitial'
import { ImportWalletPrivateKey } from '@/components/wallet/wallet-drawer/ImportWalletPrivateKey'
import { ImportWalletSeed } from '@/components/wallet/wallet-drawer/ImportWalletSeed'

export type ConnectWalletPageStep =
  | 'initial'
  | 'create-seed'
  | 'import-private-key'
  | 'import-seed'
  | 'select-wallet'

interface ConnectWalletPageContentProps {
  currentStep: ConnectWalletPageStep
  onImportPrivateKey: () => void
  onImportSeed: () => void
  onReset: () => void
  onWalletSuccess: (wallet?: { address?: string; name?: string }) => Promise<void>
  onCreateSeed: () => void
}

export function ConnectWalletPageContent({
  currentStep,
  onImportPrivateKey,
  onImportSeed,
  onReset,
  onWalletSuccess,
  onCreateSeed,
}: ConnectWalletPageContentProps) {
  return (
    <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden py-2">
      <TabsContent
        value="create"
        className="relative z-10 m-0 flex min-h-0 flex-1 flex-col overflow-hidden outline-none animate-in fade-in slide-in-from-bottom-4 duration-500"
      >
        {currentStep === 'initial' ? (
          <CreateWalletInitial onNext={onCreateSeed} />
        ) : currentStep === 'create-seed' ? (
          <CreateWalletSeed onBack={onReset} onSuccess={onWalletSuccess} />
        ) : null}
      </TabsContent>

      <TabsContent
        value="import"
        className="relative z-10 m-0 flex min-h-0 flex-1 flex-col overflow-hidden outline-none animate-in fade-in slide-in-from-bottom-4 duration-500"
      >
        {currentStep === 'initial' ? (
          <ImportWalletInitial onImport={onImportPrivateKey} onImportSeed={onImportSeed} />
        ) : currentStep === 'import-private-key' ? (
          <ImportWalletPrivateKey onBack={onReset} onSuccess={onWalletSuccess} />
        ) : currentStep === 'import-seed' ? (
          <ImportWalletSeed onBack={onReset} onSuccess={onWalletSuccess} />
        ) : null}
      </TabsContent>
    </div>
  )
}

import { SelectWallet } from '@/components/wallet/wallet-drawer/SelectWallet'
import type { WalletData } from '@/hooks/useGetAllWallets'

interface ConnectWalletPageSelectWalletProps {
  activeWalletAddress: string | null
  onAddNew: () => void
  onSelect: (wallet: WalletData) => Promise<void>
  wallets: WalletData[]
}

export function ConnectWalletPageSelectWallet({
  activeWalletAddress,
  onAddNew,
  onSelect,
  wallets,
}: ConnectWalletPageSelectWalletProps) {
  return (
    <div className="relative z-10 flex flex-1 min-h-0 flex-col overflow-hidden py-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <SelectWallet
        wallets={wallets}
        activeWalletAddress={activeWalletAddress}
        onSelect={onSelect}
        onAddNew={onAddNew}
      />
    </div>
  )
}

import type { PropsWithChildren } from 'react'

export function ConnectWalletPageShell({ children }: PropsWithChildren) {
  return (
    <div className="flex h-full min-h-0 w-full max-w-[440px] flex-1 flex-col justify-between mx-auto overflow-hidden border-x border-white/5 bg-[#09090B] p-6 text-white shadow-2xl relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-[100px] rounded-full pointer-events-none z-0" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 blur-[100px] rounded-full pointer-events-none z-0" />
      {children}
    </div>
  )
}

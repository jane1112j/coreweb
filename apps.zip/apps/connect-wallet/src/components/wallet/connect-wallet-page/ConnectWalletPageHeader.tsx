import { TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useTranslation } from 'react-i18next'

export function ConnectWalletPageHeader() {
  const { t } = useTranslation()

  return (
    <div className="pt-4 pb-6 relative">
      <TabsList className="grid w-full grid-cols-2 bg-black/40 border border-white/5 p-1.5 h-12! rounded-2xl shadow-inner relative z-10">
        <TabsTrigger
          value="import"
          className="rounded-xl data-[state=active]:bg-linear-to-b data-[state=active]:from-zinc-800 data-[state=active]:to-zinc-900 data-[state=active]:text-white text-zinc-500 font-semibold transition-all duration-300 data-[state=active]:shadow-md border border-transparent data-[state=active]:border-white/10 hover:text-white"
        >
          {t('wallet.tabs.import')}
        </TabsTrigger>
        <TabsTrigger
          value="create"
          className="rounded-xl data-[state=active]:bg-linear-to-b data-[state=active]:from-zinc-800 data-[state=active]:to-zinc-900 data-[state=active]:text-white text-zinc-500 font-semibold transition-all duration-300 data-[state=active]:shadow-md border border-transparent data-[state=active]:border-white/10 hover:text-white"
        >
          {t('wallet.tabs.create')}
        </TabsTrigger>
      </TabsList>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-12 bg-white/5 blur-3xl rounded-full z-0 pointer-events-none" />
    </div>
  )
}

import { Drawer, DrawerContent } from '@/components/ui/drawer'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useGetActiveWallet } from '@/hooks/useGetActiveWallet'
import { type WalletData, useGetAllWallets } from '@/hooks/useGetAllWallets'
import { useSetActiveWallet } from '@/hooks/useSetActiveWallet'
import { useState } from 'react'
import { CreateWalletInitial } from './wallet-drawer/CreateWalletInitial'
import { CreateWalletSeed } from './wallet-drawer/CreateWalletSeed'
import { ImportWalletInitial } from './wallet-drawer/ImportWalletInitial'
import { ImportWalletPrivateKey } from './wallet-drawer/ImportWalletPrivateKey'
import { ImportWalletSeed } from './wallet-drawer/ImportWalletSeed'
import { DrawerFooter } from './wallet-drawer/DrawerFooter'
import { SelectWallet } from './wallet-drawer/SelectWallet'

interface WalletActionDrawerProps {
  isOpen: boolean
  onClose: () => void
}

export function WalletActionDrawer({ isOpen, onClose }: WalletActionDrawerProps) {
  const [step, setStep] = useState<
    'initial' | 'create-seed' | 'import-private-key' | 'import-seed' | 'select-wallet'
  >('initial')
  const setActiveWallet = useSetActiveWallet()
  const allWalletsQuery = useGetAllWallets({ enabled: isOpen })
  const activeWalletQuery = useGetActiveWallet({ enabled: isOpen })

  const wallets = allWalletsQuery.data ?? []
  const activeWallet = activeWalletQuery.data ?? null

  const handleClose = (open: boolean) => {
    if (!open) {
      onClose()
      setTimeout(() => setStep('initial'), 300)
    }
  }

  const handleWalletSuccess = async () => {
    try {
      const [{ data: refreshedWallets }] = await Promise.all([
        allWalletsQuery.refetch(),
        activeWalletQuery.refetch(),
      ])
      setStep((refreshedWallets?.length ?? 0) > 0 ? 'select-wallet' : 'initial')
    } catch (error) {
      console.error('Failed to refresh wallet list after wallet mutation:', error)
      setStep('initial')
    }
  }

  const handleSelectWallet = async (wallet: WalletData) => {
    try {
      await setActiveWallet(wallet)
      onClose()
    } catch (error) {
      console.error('Failed to set active wallet:', error)
    }
  }

  return (
    <Drawer open={isOpen} onOpenChange={handleClose} direction="right">
      <DrawerContent className="bg-[#09090B]/95 backdrop-blur-3xl border-white/10 text-white h-full w-full max-w-[440px]! rounded-l-[32px] p-0 border-l overflow-hidden shadow-[-10px_0_40px_rgba(0,0,0,0.5)]">
        <Tabs defaultValue="create" className="flex flex-col h-full outline-none">
          {/* Header with Tabs - only show in initial step */}
          {step === 'initial' && (
            <div className="px-6 pt-8 pb-4 relative">
              <TabsList className="grid w-full grid-cols-2 bg-black/40 border border-white/5 p-1.5 h-12! rounded-2xl shadow-inner relative z-10">
                <TabsTrigger
                  value="import"
                  className="rounded-xl data-[state=active]:bg-linear-to-b data-[state=active]:from-zinc-800 data-[state=active]:to-zinc-900 data-[state=active]:text-white text-zinc-500 font-semibold transition-all duration-300 data-[state=active]:shadow-md border border-transparent data-[state=active]:border-white/10 hover:text-white"
                >
                  Import
                </TabsTrigger>
                <TabsTrigger
                  value="create"
                  className="rounded-xl data-[state=active]:bg-linear-to-b data-[state=active]:from-zinc-800 data-[state=active]:to-zinc-900 data-[state=active]:text-white text-zinc-500 font-semibold transition-all duration-300 data-[state=active]:shadow-md border border-transparent data-[state=active]:border-white/10 hover:text-white"
                >
                  Create
                </TabsTrigger>
              </TabsList>

              {/* Subtle glow effect behind tabs */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-12 bg-white/5 blur-3xl rounded-full z-0 pointer-events-none" />
            </div>
          )}

          {/* Content Area */}
          <div
            className={`relative flex-1 min-h-0 px-6 py-2 ${
              step === 'initial' ? 'overflow-y-auto custom-scrollbar pr-4' : 'overflow-hidden'
            }`}
          >
            {step === 'select-wallet' && (
              <div className="flex h-full min-h-0 overflow-hidden py-4">
                <SelectWallet
                  wallets={wallets}
                  activeWalletAddress={activeWallet?.address || null}
                  onSelect={handleSelectWallet}
                  onAddNew={() => setStep('initial')}
                />
              </div>
            )}

            <TabsContent
              value="create"
              className="m-0 flex h-full min-h-0 flex-col overflow-hidden outline-none animate-in fade-in slide-in-from-bottom-4 duration-500 relative z-10"
            >
              {step === 'initial' ? (
                <CreateWalletInitial onNext={() => setStep('create-seed')} />
              ) : step === 'create-seed' ? (
                <CreateWalletSeed
                  onBack={() => setStep('initial')}
                  onSuccess={handleWalletSuccess}
                />
              ) : null}

              {/* Decorative background light - only show in initial step */}
              {step === 'initial' && (
                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 blur-[80px] rounded-full pointer-events-none -z-10" />
              )}
            </TabsContent>

            <TabsContent
              value="import"
              className="m-0 h-full min-h-0 outline-none animate-in fade-in slide-in-from-bottom-4 duration-500 relative z-10"
            >
              {step === 'initial' ? (
                <ImportWalletInitial
                  onImport={() => setStep('import-private-key')}
                  onImportSeed={() => setStep('import-seed')}
                />
              ) : step === 'import-private-key' ? (
                <ImportWalletPrivateKey
                  onBack={() => setStep('initial')}
                  onSuccess={handleWalletSuccess}
                />
              ) : step === 'import-seed' ? (
                <ImportWalletSeed
                  onBack={() => setStep('initial')}
                  onSuccess={handleWalletSuccess}
                />
              ) : null}

              {/* Decorative background light */}
              {step === 'initial' && (
                <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 blur-[80px] rounded-full pointer-events-none -z-10" />
              )}
            </TabsContent>
          </div>

          {/* Footer - only show in initial step */}
          {step === 'initial' && <DrawerFooter onSupport={() => console.log('Support clicked')} />}
        </Tabs>
      </DrawerContent>
    </Drawer>
  )
}

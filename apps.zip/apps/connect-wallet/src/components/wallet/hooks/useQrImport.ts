import jsQR from 'jsqr'
import { toast } from 'sonner'

export function useQrImport() {
  const handleScan = async (): Promise<string | null> => {
    // Browser camera fallback
    return new Promise((resolve) => {
      const video = document.createElement('video')
      const canvas = document.createElement('canvas')
      const context = canvas.getContext('2d')
      const container = document.createElement('div')

      // Style the camera overlay with glassmorphism
      container.style.position = 'fixed'
      container.style.top = '0'
      container.style.left = '0'
      container.style.width = '100vw'
      container.style.height = '100vh'
      container.style.backgroundColor = 'rgba(0,0,0,0.85)'
      container.style.backdropFilter = 'blur(10px)'
      container.style.zIndex = '9999'
      container.style.display = 'flex'
      container.style.flexDirection = 'column'
      container.style.alignItems = 'center'
      container.style.justifyContent = 'center'
      container.style.fontFamily = 'system-ui, sans-serif'

      const scanWindow = document.createElement('div')
      scanWindow.style.position = 'relative'
      scanWindow.style.width = '280px'
      scanWindow.style.height = '280px'
      scanWindow.style.border = '2px solid rgba(255,255,255,0.3)'
      scanWindow.style.borderRadius = '24px'
      scanWindow.style.overflow = 'hidden'
      scanWindow.style.boxShadow = '0 0 0 1000px rgba(0,0,0,0.5)'
      scanWindow.style.marginBottom = '40px'

      // Corner accents for scan window
      for (let i = 0; i < 4; i++) {
        const accent = document.createElement('div')
        accent.style.position = 'absolute'
        accent.style.width = '20px'
        accent.style.height = '20px'
        accent.style.borderColor = '#ffffff'
        accent.style.borderStyle = 'solid'
        accent.style.zIndex = '10'

        if (i === 0) {
          accent.style.top = '0'
          accent.style.left = '0'
          accent.style.borderWidth = '4px 0 0 4px'
          accent.style.borderRadius = '12px 0 0 0'
        }
        if (i === 1) {
          accent.style.top = '0'
          accent.style.right = '0'
          accent.style.borderWidth = '4px 4px 0 0'
          accent.style.borderRadius = '0 12px 0 0'
        }
        if (i === 2) {
          accent.style.bottom = '0'
          accent.style.left = '0'
          accent.style.borderWidth = '0 0 4px 4px'
          accent.style.borderRadius = '0 0 0 12px'
        }
        if (i === 3) {
          accent.style.bottom = '0'
          accent.style.right = '0'
          accent.style.borderWidth = '0 4px 4px 0'
          accent.style.borderRadius = '0 0 12px 0'
        }

        scanWindow.appendChild(accent)
      }

      const closeBtn = document.createElement('button')
      closeBtn.innerText = 'Cancel'
      closeBtn.style.padding = '14px 40px'
      closeBtn.style.backgroundColor = 'rgba(255,255,255,0.1)'
      closeBtn.style.color = 'white'
      closeBtn.style.borderRadius = '99px'
      closeBtn.style.fontWeight = '600'
      closeBtn.style.border = '1px solid rgba(255,255,255,0.2)'
      closeBtn.style.cursor = 'pointer'
      closeBtn.style.backdropFilter = 'blur(5px)'
      closeBtn.style.transition = 'all 0.2s'

      video.style.position = 'absolute'
      video.style.top = '50%'
      video.style.left = '50%'
      video.style.transform = 'translate(-50%, -50%)'
      video.style.minWidth = '100%'
      video.style.minHeight = '100%'
      video.style.objectFit = 'cover'

      const hint = document.createElement('div')
      hint.innerText = 'Position QR code within the frame'
      hint.style.color = 'rgba(255,255,255,0.7)'
      hint.style.fontSize = '14px'
      hint.style.marginBottom = '20px'

      scanWindow.appendChild(video)
      container.appendChild(scanWindow)
      container.appendChild(hint)
      container.appendChild(closeBtn)
      document.body.appendChild(container)

      let stream: MediaStream | null = null
      let animationId: number | null = null

      const cleanup = () => {
        if (stream) stream.getTracks().forEach((track) => track.stop())
        if (animationId) cancelAnimationFrame(animationId)
        if (document.body.contains(container)) document.body.removeChild(container)
      }

      closeBtn.onclick = () => {
        cleanup()
        resolve(null)
      }

      const tick = () => {
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          context?.drawImage(video, 0, 0, canvas.width, canvas.height)
          const imageData = context?.getImageData(0, 0, canvas.width, canvas.height)

          if (imageData) {
            const code = jsQR(imageData.data, imageData.width, imageData.height)
            if (code) {
              cleanup()
              resolve(code.data)
              return
            }
          }
        }
        animationId = requestAnimationFrame(tick)
      }

      // Check and request permission
      const startCamera = async () => {
        try {
          // Some browsers support checking permission state
          if (navigator.permissions && navigator.permissions.query) {
            try {
              const result = await navigator.permissions.query({ name: 'camera' })
              if (result.state === 'denied') {
                toast.error('Camera access is blocked. Please enable it in your browser settings.')
                cleanup()
                resolve(null)
                return
              }
            } catch {
              // Ignore if query('camera') is not supported
            }
          }

          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: 'environment',
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
          })

          video.srcObject = stream
          video.setAttribute('playsinline', 'true')
          video.play()
          animationId = requestAnimationFrame(tick)
        } catch (err) {
          console.error('Camera access error:', err)
          if (
            (err as Error).name === 'NotAllowedError' ||
            (err as Error).name === 'PermissionDeniedError'
          ) {
            toast.error('Camera permission denied. Please allow access to scan QR codes.')
          } else {
            toast.error('Could not start camera. Make sure no other app is using it.')
          }
          cleanup()
          resolve(null)
        }
      }

      startCamera()
    })
  }

  const handleBrowserFile = async (file: File) => {
    try {
      const imageUrl = URL.createObjectURL(file)
      const image = new Image()
      image.src = imageUrl

      await new Promise((resolve, reject) => {
        image.onload = resolve
        image.onerror = reject
      })

      const canvas = document.createElement('canvas')
      const context = canvas.getContext('2d')
      if (!context) {
        URL.revokeObjectURL(imageUrl)
        throw new Error('Could not get canvas context')
      }

      canvas.width = image.width
      canvas.height = image.height
      context.drawImage(image, 0, 0)

      const imageData = context.getImageData(0, 0, canvas.width, canvas.height)
      const code = jsQR(imageData.data, imageData.width, imageData.height)

      URL.revokeObjectURL(imageUrl)

      if (!code) {
        toast.error('No QR code detected in this image')
        return null
      }

      return code.data
    } catch (error) {
      console.error('Browser file QR error:', error)
      toast.error((error as Error).message || 'Failed to read QR code from file')
      return null
    }
  }

  return { handleScan, handleBrowserFile }
}

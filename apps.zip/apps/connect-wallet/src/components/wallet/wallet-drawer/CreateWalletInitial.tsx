import { ChevronRight, Network } from 'lucide-react'
import { useTranslation } from 'react-i18next'

interface CreateWalletInitialProps {
  onNext: () => void
}

export function CreateWalletInitial({ onNext }: CreateWalletInitialProps) {
  const { t } = useTranslation()

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-linear-to-r from-white to-zinc-400 tracking-tight">
          {t('wallet.create.title')}
        </h2>
        <p className="text-zinc-400 text-sm leading-relaxed">
          {t('wallet.create.description')}
        </p>
      </div>

      <button
        onClick={onNext}
        className="w-full flex items-center justify-between p-4 rounded-2xl bg-linear-to-r from-emerald-500/5 to-teal-500/5 border border-emerald-500/10 hover:from-emerald-500/10 hover:to-teal-500/10 hover:border-emerald-500/20 transition-all duration-300 group shadow-[0_0_0_1px_rgba(255,255,255,0.02)] hover:shadow-[0_4px_20px_rgba(16,185,129,0.1)]"
      >
        <div className="flex items-center gap-4">
          <div className="h-10 w-10 rounded-full bg-linear-to-br from-emerald-400/20 to-teal-500/20 flex items-center justify-center border border-emerald-400/30 group-hover:from-emerald-400/30 group-hover:to-teal-500/30 transition-all shadow-[inset_0_0_10px_rgba(16,185,129,0.2)]">
            <Network className="h-5 w-5 text-emerald-300 group-hover:text-emerald-200" />
          </div>
          <span className="text-zinc-100 font-semibold text-base group-hover:text-white transition-colors">
            {t('wallet.create.action')}
          </span>
        </div>
        <ChevronRight className="h-5 w-5 text-emerald-500/50 group-hover:text-emerald-400 transition-colors group-hover:translate-x-1" />
      </button>
    </div>
  )
}

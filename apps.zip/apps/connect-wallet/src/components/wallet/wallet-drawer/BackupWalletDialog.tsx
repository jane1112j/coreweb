import { Dialog, DialogContent } from '@/components/ui/dialog'
import { useSaveQrCode } from '@/hooks/useSaveQrCode'
import { type BackupWalletResponse, useBackupWallet } from '@/hooks/useBackupWallet'
import { Copy, Download, KeyRound, ShieldAlert } from 'lucide-react'
import QRCode from 'react-qr-code'
import { useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { MaskedQrPreview, MaskedSecretPreview } from './BackupWalletMaskedPreviews'

interface BackupWalletPreview {
  address: string
  name?: string
}

interface BackupWalletDialogProps {
  wallet: BackupWalletPreview | null
  onOpenChange: (open: boolean) => void
}

export function BackupWalletDialog({ wallet, onOpenChange }: BackupWalletDialogProps) {
  const qrContainerRef = useRef<HTMLDivElement>(null)
  const { saveQrCode } = useSaveQrCode()
  const backupWalletMutation = useBackupWallet()
  const { isPending, mutateAsync, reset } = backupWalletMutation
  const [backupData, setBackupData] = useState<BackupWalletResponse | null>(null)

  useEffect(() => {
    setBackupData(null)
    reset()
  }, [reset, wallet?.address])

  const ensureBackupData = async () => {
    if (!wallet) {
      return null
    }

    if (backupData) {
      return backupData
    }

    const revealedData = await mutateAsync({ address: wallet.address })
    setBackupData(revealedData)
    return revealedData
  }

  const handleCopy = async (value: string, label: string) => {
    if (!value) {
      toast.error(`${label} is unavailable for this wallet`)
      return
    }

    await navigator.clipboard.writeText(value)
    toast.success(`${label} copied to clipboard`)
  }

  const handleCopyPrivateKey = async () => {
    const revealedData = await ensureBackupData()
    if (!revealedData) {
      return
    }

    await handleCopy(revealedData.privateKey, 'Private key')
  }

  const handleCopySeedPhrase = async () => {
    const revealedData = await ensureBackupData()
    if (!revealedData) {
      return
    }

    await handleCopy(revealedData.seedPhrase, 'Seed phrase')
  }

  const handleDownloadQrCode = async () => {
    const revealedData = await ensureBackupData()
    if (!revealedData?.seedPhrase) {
      toast.error('QR code is unavailable for this wallet')
      return
    }

    requestAnimationFrame(() => {
      saveQrCode(
        qrContainerRef,
        `wallet-seed-qr-${(revealedData.name || revealedData.address.slice(-6)).replace(/\s+/g, '-').toLowerCase()}.png`,
      )
    })
  }

  const displayName = backupData?.name || wallet?.name || 'Unnamed Wallet'
  const displayAddress = backupData?.address || wallet?.address || ''
  const isLoading = isPending

  return (
    <Dialog open={Boolean(wallet)} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className="max-h-[calc(100vh-1rem)] w-[min(26rem,calc(100vw-1rem))] overflow-y-auto rounded-[clamp(1.25rem,5vw,1.75rem)] border border-white/10 bg-[#111113]/96 p-[clamp(1rem,4vw,1.5rem)] text-white shadow-[0_24px_80px_rgba(0,0,0,0.55)] backdrop-blur-2xl"
      >
        {wallet ? (
          <div className="space-y-[clamp(1rem,4vw,1.25rem)]">
            <div className="mx-auto flex h-[clamp(3.5rem,14vw,4rem)] w-[clamp(3.5rem,14vw,4rem)] items-center justify-center rounded-full border border-amber-500/25 bg-amber-500/10 shadow-[inset_0_0_20px_rgba(245,158,11,0.16)]">
              <ShieldAlert className="h-[clamp(1.5rem,6vw,1.75rem)] w-[clamp(1.5rem,6vw,1.75rem)] text-amber-300" />
            </div>

            <div className="space-y-2 text-center">
              <h3 className="text-[clamp(1.5rem,6vw,1.75rem)] font-semibold tracking-tight text-zinc-50">
                Backup Wallet
              </h3>
              <p className="text-[clamp(0.8125rem,3vw,0.875rem)] leading-relaxed text-zinc-400">
                Store this information securely. Anyone with these credentials can control your
                wallet.
              </p>
            </div>

            <div className="space-y-3 rounded-[clamp(1rem,4vw,1.25rem)] border border-white/8 bg-black/20 p-[clamp(0.875rem,3vw,1rem)]">
              <p className="text-sm font-semibold text-zinc-100">{displayName}</p>
              <p className="truncate font-mono text-[11px] text-zinc-500">{displayAddress}</p>
            </div>

            <div className="space-y-[clamp(0.75rem,3vw,1rem)]">
              <div className="rounded-[clamp(1rem,4vw,1.25rem)] border border-white/8 bg-white/[0.02] p-[clamp(0.875rem,3vw,1rem)]">
                <div className="mb-[clamp(0.75rem,3vw,0.875rem)] flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <KeyRound className="h-4 w-4 text-zinc-400" />
                    <span className="text-sm font-semibold text-zinc-100">Private Key</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleCopyPrivateKey()}
                    disabled={isLoading}
                    className="shrink-0 rounded-full border border-white/10 px-[clamp(0.625rem,2.5vw,0.75rem)] py-[clamp(0.35rem,1.5vw,0.375rem)] text-[clamp(0.6875rem,2.6vw,0.75rem)] font-medium text-zinc-300 transition-colors hover:bg-white/[0.05] hover:text-white disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    <span className="flex items-center gap-1">
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy</span>
                    </span>
                  </button>
                </div>
                {backupData ? (
                  <textarea
                    readOnly
                    value={backupData.privateKey}
                    className="min-h-[clamp(5.25rem,20vw,6rem)] w-full resize-none rounded-[clamp(0.75rem,3vw,0.9rem)] border border-white/12 bg-white/[0.06] px-[clamp(0.75rem,3vw,0.875rem)] py-[clamp(0.75rem,3vw,0.875rem)] text-xs leading-relaxed text-zinc-200 outline-none"
                  />
                ) : (
                  <MaskedSecretPreview />
                )}
              </div>

              <div className="rounded-[clamp(1rem,4vw,1.25rem)] border border-white/8 bg-white/[0.02] p-[clamp(0.875rem,3vw,1rem)]">
                <div className="mb-[clamp(0.75rem,3vw,0.875rem)] flex items-center gap-2">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 text-zinc-400" />
                    <span className="text-sm font-semibold text-zinc-100">Seed Phrase</span>
                  </div>
                </div>
                {backupData ? (
                  <div className="flex flex-wrap items-start justify-center gap-[clamp(0.75rem,3vw,1rem)]">
                    <div className="flex shrink-0 flex-col items-center gap-3">
                      <div
                        ref={qrContainerRef}
                        className="w-fit rounded-[clamp(1rem,4vw,1.375rem)] bg-white p-[clamp(0.625rem,2.5vw,0.75rem)] shadow-xl"
                      >
                        <QRCode
                          value={backupData.seedPhrase}
                          size={256}
                          className="h-[clamp(7rem,30vw,9.25rem)] w-[clamp(7rem,30vw,9.25rem)]"
                        />
                      </div>
                    </div>

                    <div className="min-w-[min(100%,14rem)] flex-1 space-y-[clamp(0.75rem,3vw,0.875rem)]">
                      <div
                        className="max-h-[clamp(5.5rem,20vw,6.5rem)] min-h-[clamp(4.75rem,18vw,5.25rem)] w-full overflow-y-auto overscroll-contain rounded-[clamp(0.75rem,3vw,0.9rem)] border border-white/8 bg-black/20 px-[clamp(0.75rem,3vw,0.875rem)] py-[clamp(0.75rem,3vw,0.875rem)] pr-[clamp(0.5rem,2vw,0.75rem)] text-xs leading-relaxed text-zinc-300 [scrollbar-gutter:stable] custom-scrollbar"
                      >
                        <p className="break-words whitespace-pre-wrap">{backupData.seedPhrase}</p>
                      </div>

                      <div className="flex justify-center [@media(min-width:23rem)]:justify-start">
                        <button
                          type="button"
                          onClick={() => void handleCopySeedPhrase()}
                          disabled={isLoading}
                          className="rounded-full border border-white/10 px-[clamp(0.625rem,2.5vw,0.75rem)] py-[clamp(0.35rem,1.5vw,0.375rem)] text-[clamp(0.6875rem,2.5vw,0.75rem)] font-medium text-zinc-300 transition-colors hover:bg-white/[0.05] hover:text-white disabled:cursor-not-allowed disabled:opacity-70"
                        >
                          <span className="flex items-center gap-1">
                            <Copy className="h-3 w-3" />
                            <span>Copy seed phrase</span>
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-start justify-center gap-[clamp(0.75rem,3vw,1rem)]">
                    <div className="flex shrink-0 flex-col items-center gap-3">
                      <MaskedQrPreview />
                    </div>

                    <div className="min-w-[min(100%,14rem)] flex-1 space-y-[clamp(0.75rem,3vw,0.875rem)]">
                      <MaskedSecretPreview compact />
                      <div className="flex justify-center [@media(min-width:23rem)]:justify-start">
                        <button
                          type="button"
                          onClick={() => void handleCopySeedPhrase()}
                          disabled={isLoading}
                          className="rounded-full border border-white/10 px-[clamp(0.625rem,2.5vw,0.75rem)] py-[clamp(0.35rem,1.5vw,0.375rem)] text-[clamp(0.6875rem,2.5vw,0.75rem)] font-medium text-zinc-300 transition-colors hover:bg-white/[0.05] hover:text-white disabled:cursor-not-allowed disabled:opacity-70"
                        >
                          <span className="flex items-center gap-1">
                            <Copy className="h-3 w-3" />
                            <span>Copy seed phrase</span>
                          </span>
                        </button>
                      </div>
                      <p className="text-center text-[clamp(0.75rem,2.8vw,0.8125rem)] leading-relaxed text-zinc-500 [@media(min-width:23rem)]:text-left">
                        Copy or download to unlock this wallet with your password and reveal the
                        recovery phrase.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={() => void handleDownloadQrCode()}
                disabled={isLoading}
                className="flex h-[clamp(2.75rem,11vw,3rem)] w-full items-center justify-center gap-2 rounded-[clamp(1rem,4vw,1.25rem)] bg-linear-to-r from-blue-500 to-indigo-500 text-sm font-semibold text-white transition-all hover:from-blue-400 hover:to-indigo-400 disabled:cursor-not-allowed disabled:opacity-70"
              >
                <Download className="h-4 w-4" />
                <span>Download QR Code</span>
              </button>

              <button
                type="button"
                onClick={() => onOpenChange(false)}
                className="h-[clamp(2.75rem,11vw,3rem)] w-full rounded-[clamp(1rem,4vw,1.25rem)] border border-white/10 bg-white/[0.02] text-sm font-semibold text-zinc-200 transition-colors hover:bg-white/[0.05]"
              >
                Close
              </button>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}

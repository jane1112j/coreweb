import { ArrowLeft, Clipboard, Image as ImageIcon, Scan, Loader2, Eraser } from 'lucide-react'
import { useState, useRef } from 'react'
import { useCreateWallet } from '../../../hooks/useCreateWallet'
import { useQrImport } from '../hooks/useQrImport'
import { getFromClipboard } from '@metanodejs/system-core'
import { toast } from 'sonner'
import { convertStringToSeedPhrase } from '../../../utils'

interface ImportWalletSeedProps {
  onBack: () => void
  onSuccess: (wallet?: { address?: string; name?: string }) => void
}

export function ImportWalletSeed({ onBack, onSuccess }: ImportWalletSeedProps) {
  const [words, setWords] = useState<string[]>([])
  const [inputValue, setInputValue] = useState('')
  const [name, setName] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { handleScan, handleBrowserFile } = useQrImport()

  const createWalletMutation = useCreateWallet()
  const isImporting = createWalletMutation.isPending

  const lastAddedRef = useRef<{ word: string; time: number } | null>(null)

  const addWords = (text: string) => {
    const trimmed = text.trim()
    if (!trimmed) return

    // Detect encoded seed phrase string (e.g. Mx3S5FembodyFpowder...)
    let parsedWords: string[]
    if (trimmed.startsWith('Mx3S5')) {
      parsedWords = convertStringToSeedPhrase(trimmed)
      if (parsedWords.length === 0) {
        toast.error('Invalid encoded seed phrase')
        return
      }
    } else {
      parsedWords = trimmed.split(/[\s,]+/).filter((w) => w.length > 0)
    }

    if (parsedWords.length === 0) return

    // Prevent Telex/IME double-commit in rapid succession (<200ms)
    const now = Date.now()
    if (
      parsedWords.length === 1 &&
      lastAddedRef.current &&
      lastAddedRef.current.word === parsedWords[0] &&
      now - lastAddedRef.current.time < 200
    ) {
      return
    }

    if (parsedWords.length === 1) {
      lastAddedRef.current = { word: parsedWords[0], time: now }
    }

    setWords((prev) => {
      const combined = [...prev, ...parsedWords]
      if (combined.length > 24) {
        toast.warning('Maximum 24 words allowed')
        return combined.slice(0, 24)
      }
      return combined
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value
    if (val.endsWith(' ')) {
      const cleanWord = val.trim()
      if (cleanWord) {
        addWords(cleanWord)
      }
      setInputValue('')
    } else {
      setInputValue(val)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      const cleanWord = inputValue.trim()
      if (cleanWord) {
        addWords(cleanWord)
      }
      setInputValue('')
    } else if (e.key === 'Backspace' && !inputValue && words.length > 0) {
      setWords((prev) => prev.slice(0, -1))
    }
  }

  const handleInputPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault()
    const text = e.clipboardData.getData('text')
    if (text.trim()) {
      addWords(text)
    }
  }

  const handleRemoveWord = (index: number) => {
    setWords((prev) => prev.filter((_, i) => i !== index))
  }

  const handleClearAll = () => {
    setWords([])
    setInputValue('')
  }

  const handleScanQR = async () => {
    const result = await handleScan()
    if (result !== null) {
      handleClearAll()
      addWords(result)
    }
  }

  const handleUploadQR = async () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const result = await handleBrowserFile(file)
    if (result !== null) {
      handleClearAll()
      addWords(result)
    }

    // Reset input
    event.target.value = ''
  }

  const handlePaste = async () => {
    try {
      const text = await getFromClipboard()
      if (text.value.trim()) {
        addWords(text.value.trim())
        toast.success('Pasted and parsed seed phrase')
      } else {
        toast.error('Clipboard is empty')
      }
    } catch (err) {
      console.error('Failed to read clipboard:', err)
      toast.error('Permission to access clipboard denied')
    }
  }

  const handleConfirm = async () => {
    if (words.length !== 24) {
      toast.error(`Seed phrase must contain exactly 24 words (currently: ${words.length})`)
      return
    }

    createWalletMutation.mutate(
      {
        seedPhrase: words,
        name: name.trim() || undefined,
      },
      {
        onSuccess: (createdWallet) => {
          onSuccess(createdWallet)
        },
      },
    )
  }

  return (
    <div
      data-vaul-no-drag
      className="flex h-full min-h-0 flex-1 flex-col gap-[clamp(0.875rem,2vh,1.5rem)] overflow-y-auto overscroll-contain pr-1 pb-[clamp(1rem,2.4vh,1.5rem)] pt-[clamp(1rem,2.4vh,1.5rem)] animate-in slide-in-from-right duration-300 custom-scrollbar"
    >
      <h2 className="text-[clamp(1.25rem,2.8vw,1.375rem)] font-semibold text-zinc-100 tracking-tight">
        Import with Seed Phrase
      </h2>

      <div className="space-y-[clamp(0.75rem,1.8vh,1rem)]">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Wallet name (Optional)"
          className="w-full rounded-xl border border-white/10 bg-[#242427]/90 px-4 py-[clamp(0.75rem,1.8vh,0.875rem)] text-sm text-white placeholder:text-zinc-400 transition-colors focus:border-white/25 focus:bg-[#2A2A2D] focus:outline-none"
          disabled={isImporting}
        />

        {/* Interactive Seed Phrase Container */}
        <div className="group relative flex min-h-[clamp(10rem,24vh,12rem)] w-full flex-col justify-between rounded-2xl border border-white/10 bg-[#242427]/90 p-[clamp(0.875rem,2vh,1rem)] transition-all focus-within:border-white/20">
          <div className="mb-3 flex max-h-[clamp(8rem,22vh,13.75rem)] flex-wrap gap-2 overflow-y-auto overscroll-contain pr-1 custom-scrollbar">
            {words.map((word, index) => (
              <div
                key={index}
                className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-[#313136] px-3 py-1.5 text-xs text-white"
              >
                <span className="text-zinc-500 font-medium">{index + 1}.</span>
                <span className="font-semibold text-zinc-200">{word}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveWord(index)}
                  className="text-zinc-500 hover:text-red-400 transition-colors ml-1 font-bold text-[10px] focus:outline-none"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>

          <div className="relative mt-auto flex min-h-[64px] items-center gap-3 rounded-2xl border border-white/12 bg-white/[0.05] px-3 py-2.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] transition-colors group-focus-within:border-white/20 group-focus-within:bg-white/[0.07]">
            {words.length < 24 ? (
              <input
                type="text"
                value={inputValue}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                onPaste={handleInputPaste}
                placeholder={
                  words.length === 0 ? 'Type word and press Space...' : 'Type next word...'
                }
                className="w-full flex-1 bg-transparent py-2 text-[15px] text-white placeholder:text-zinc-400 focus:outline-none"
                disabled={isImporting}
              />
            ) : (
              <span className="py-2 text-sm text-zinc-400">Enough 24 Seed Phrases</span>
            )}

            <div className="ml-auto flex shrink-0 items-center gap-2">
              <button
                type="button"
                onClick={handlePaste}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/10 text-zinc-300 transition-colors hover:border-white/15 hover:bg-white/15 hover:text-white"
                title="Paste seed phrase"
              >
                <Clipboard className="h-4 w-4" />
              </button>
              {words.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/10 text-zinc-300 transition-colors hover:border-white/15 hover:bg-white/15 hover:text-white"
                  title="Clear all"
                >
                  <Eraser className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4 py-1">
        <div className="h-px flex-1 bg-white/10" />
        <span className="text-zinc-500 text-xs font-medium uppercase tracking-wider">Or</span>
        <div className="h-px flex-1 bg-white/10" />
      </div>

      <div className="flex min-h-[clamp(11rem,26vh,14rem)] flex-col items-center justify-center rounded-2xl border-2 border-dashed border-white/10 bg-white/2 p-[clamp(1rem,2.8vh,2rem)] space-y-[clamp(1rem,2vh,1.5rem)]">
        <div className="flex flex-col items-center gap-3 text-zinc-400">
          <div className="h-12 w-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/5">
            <ImageIcon className="h-6 w-6" />
          </div>
          <span className="text-sm font-medium">Input with QR code</span>
        </div>

        <div className="grid w-full grid-cols-2 gap-3">
          <button
            onClick={handleScanQR}
            disabled={isImporting}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-xs font-medium text-zinc-300 disabled:opacity-50"
          >
            <Scan className="h-4 w-4" />
            Scan QR code
          </button>
          <button
            onClick={handleUploadQR}
            disabled={isImporting}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-xs font-medium text-zinc-300 disabled:opacity-50"
          >
            <ImageIcon className="h-4 w-4" />
            Upload image
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
        </div>
      </div>

      <div className="mt-auto flex items-center gap-4 pt-2">
        <button
          onClick={onBack}
          disabled={isImporting}
          className="h-[52px] w-[52px] rounded-full border border-white/20 flex items-center justify-center hover:bg-white/5 transition-colors shrink-0 disabled:opacity-50"
        >
          <ArrowLeft className="h-5 w-5 text-zinc-300" />
        </button>
        <button
          onClick={handleConfirm}
          disabled={isImporting || words.length === 0}
          className="flex-1 h-[52px] rounded-full border border-white/20 bg-white/5 hover:bg-white/10 text-zinc-200 font-semibold transition-colors tracking-wide text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isImporting && <Loader2 className="h-4 w-4 animate-spin" />}
          {isImporting ? 'IMPORTING...' : 'CONFIRM'}
        </button>
      </div>
    </div>
  )
}

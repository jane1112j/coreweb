import {
  Download,
  MoreVertical,
  PencilLine,
  Trash2,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface WalletItemActionsProps {
  walletName?: string
  isActive?: boolean
  disabled?: boolean
  onRename?: () => void
  onBackup?: () => void
  onDelete?: () => void
}

const walletActionItems = [
  { label: 'Rename', icon: PencilLine },
  { label: 'Backup wallet', icon: Download },
  { label: 'Delete wallet', icon: Trash2, variant: 'destructive' as const },
]

export function WalletItemActions({
  walletName,
  isActive = false,
  disabled = false,
  onRename,
  onBackup,
  onDelete,
}: WalletItemActionsProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          data-vaul-no-drag
          disabled={disabled}
          aria-label={`Open actions for ${walletName || 'Unnamed Wallet'}`}
          className={`flex h-10 w-10 items-center justify-center rounded-full border transition-all outline-none disabled:cursor-not-allowed disabled:opacity-50 ${
            isActive
              ? 'border-blue-400/20 bg-blue-500/10 text-blue-200 hover:bg-blue-500/15'
              : 'border-white/10 bg-white/[0.03] text-zinc-400 hover:border-white/15 hover:bg-white/[0.06] hover:text-white'
          }`}
        >
          <MoreVertical className="h-4 w-4" />
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-52 rounded-2xl border border-white/10 bg-[#111113]/95 p-2 text-zinc-100 shadow-[0_20px_60px_rgba(0,0,0,0.45)] backdrop-blur-xl"
      >
        {walletActionItems.map((item) => {
          const Icon = item.icon
          return (
            <DropdownMenuItem
              key={item.label}
              variant={item.variant}
              disabled={disabled}
              onSelect={
                item.label === 'Rename'
                  ? onRename
                  : item.label === 'Backup wallet'
                  ? onBackup
                  : item.label === 'Delete wallet'
                    ? onDelete
                    : undefined
              }
              className="cursor-pointer rounded-xl px-3 py-2.5 text-sm"
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

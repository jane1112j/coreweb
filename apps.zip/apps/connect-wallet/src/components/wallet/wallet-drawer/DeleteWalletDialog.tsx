import { Checkbox } from '@/components/ui/checkbox'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { useDeleteWallet } from '@/hooks/useDeleteWallet'
import { Check, Download, Loader2, Trash2, Wallet as WalletIcon } from 'lucide-react'
import { useEffect, useState } from 'react'

interface DeleteWalletTarget {
  address: string
  name?: string
}

interface DeleteWalletDialogProps {
  wallet: DeleteWalletTarget | null
  onOpenChange: (open: boolean) => void
  onRequestBackup?: (wallet: DeleteWalletTarget) => void
}

export function DeleteWalletDialog({
  wallet,
  onOpenChange,
  onRequestBackup,
}: DeleteWalletDialogProps) {
  const deleteWalletMutation = useDeleteWallet()
  const [isConfirmed, setIsConfirmed] = useState(false)
  const [dialogMode, setDialogMode] = useState<'confirm' | 'success' | null>(null)
  const [currentWallet, setCurrentWallet] = useState<DeleteWalletTarget | null>(null)

  const isOpen = dialogMode !== null
  const isDeleting = deleteWalletMutation.isPending

  useEffect(() => {
    if (wallet) {
      setCurrentWallet(wallet)
      setDialogMode('confirm')
      setIsConfirmed(false)
    }
  }, [wallet])

  const handleOpenChange = (open: boolean) => {
    if (!open && isDeleting) {
      return
    }

    if (!open) {
      setIsConfirmed(false)
      setDialogMode(null)
      setCurrentWallet(null)
      onOpenChange(false)
    }
  }

  const handleDeleteWallet = () => {
    if (!currentWallet || !isConfirmed || isDeleting) {
      return
    }

    deleteWalletMutation.mutate(
      { address: currentWallet.address },
      {
        onSuccess: () => {
          setDialogMode('success')
          setIsConfirmed(false)
          onOpenChange(false)
        },
      },
    )
  }

  const handleBackupWallet = () => {
    if (!currentWallet || isDeleting) {
      return
    }

    setIsConfirmed(false)
    setDialogMode(null)
    onOpenChange(false)
    onRequestBackup?.(currentWallet)
    setCurrentWallet(null)
  }

  if (dialogMode === null) {
    return null
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent
        showCloseButton={false}
        className="w-[calc(100%-2rem)] max-w-[360px] rounded-[28px] border border-white/10 bg-[#111113]/96 p-6 text-white shadow-[0_24px_80px_rgba(0,0,0,0.55)] backdrop-blur-2xl"
      >
        {dialogMode === 'success' ? (
          <div className="space-y-5 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-emerald-500/25 bg-emerald-500/10 shadow-[inset_0_0_20px_rgba(34,197,94,0.18)]">
              <Check className="h-7 w-7 text-emerald-400" />
            </div>

            <div className="space-y-2">
              <h3 className="text-[28px] font-semibold tracking-tight text-zinc-50">
                Wallet Deleted
              </h3>
              <p className="text-sm leading-relaxed text-zinc-400">
                The wallet has been successfully removed.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleOpenChange(false)}
              className="h-12 w-full rounded-2xl border border-white/10 bg-white/[0.02] text-sm font-semibold text-zinc-200 transition-colors hover:bg-white/[0.05]"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="space-y-5">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-red-500/25 bg-red-500/10 shadow-[inset_0_0_20px_rgba(239,68,68,0.16)]">
              <Trash2 className="h-7 w-7 text-red-400" />
            </div>

            <div className="space-y-2 text-center">
              <h3 className="text-[28px] font-semibold tracking-tight text-zinc-50">
                Delete Wallet
              </h3>
              <p className="text-sm leading-relaxed text-zinc-400">
                This action cannot be undone. Deleting this wallet will remove it from your list.
              </p>
            </div>

            {currentWallet && (
              <div className="flex items-center gap-3 rounded-2xl border border-white/8 bg-black/20 px-4 py-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-zinc-800">
                  <WalletIcon className="h-5 w-5 text-zinc-400" />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-zinc-100">
                    {currentWallet.name || 'Unnamed Wallet'}
                  </p>
                  <p className="mt-1 truncate font-mono text-[11px] text-zinc-500">
                    0x{currentWallet.address.slice(0, 6)}...{currentWallet.address.slice(-4)}
                  </p>
                </div>
              </div>
            )}

            <div className="space-y-3 rounded-2xl border border-amber-500/15 bg-amber-500/[0.06] px-4 py-4">
              <div className="space-y-1.5">
                <p className="text-sm font-semibold text-zinc-100">Have you backed up this wallet?</p>
                <p className="text-sm leading-relaxed text-zinc-400">
                  If not, back it up now so you can still recover the seed phrase and private key
                  before deleting it.
                </p>
              </div>

              <button
                type="button"
                onClick={handleBackupWallet}
                disabled={isDeleting}
                className="flex h-11 w-full items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] text-sm font-semibold text-zinc-100 transition-colors hover:bg-white/[0.07] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Download className="h-4 w-4" />
                <span>Backup Wallet First</span>
              </button>
            </div>

            <label className="flex items-start gap-3 rounded-xl border border-white/8 bg-white/[0.02] px-3 py-3 text-sm text-zinc-300">
              <Checkbox
                checked={isConfirmed}
                onCheckedChange={(checked) => setIsConfirmed(checked === true)}
                disabled={isDeleting}
                className="mt-0.5 border-white/15 bg-black/20 data-checked:border-red-500/70 data-checked:bg-red-500 data-checked:text-white"
              />
              <span>I understand that this action cannot be undone.</span>
            </label>

            <div className="space-y-3">
              <button
                type="button"
                onClick={handleDeleteWallet}
                disabled={!isConfirmed || isDeleting}
                className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-linear-to-r from-red-500 to-red-600 text-sm font-semibold text-white transition-all hover:from-red-400 hover:to-red-500 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isDeleting && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>{isDeleting ? 'Deleting Wallet...' : 'Delete Wallet'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenChange(false)}
                disabled={isDeleting}
                className="h-12 w-full rounded-2xl border border-white/10 bg-white/[0.02] text-sm font-semibold text-zinc-200 transition-colors hover:bg-white/[0.05] disabled:cursor-not-allowed disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

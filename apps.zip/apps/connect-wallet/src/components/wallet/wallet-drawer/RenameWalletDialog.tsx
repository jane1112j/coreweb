import { Dialog, DialogContent } from '@/components/ui/dialog'
import { useUpdateWalletInfo } from '@/hooks/useUpdateWalletInfo'
import { Loader2, PencilLine, Wallet as WalletIcon } from 'lucide-react'
import { useEffect, useState } from 'react'

interface RenameWalletTarget {
  address: string
  name?: string
}

interface RenameWalletDialogProps {
  wallet: RenameWalletTarget | null
  onOpenChange: (open: boolean) => void
}

export function RenameWalletDialog({ wallet, onOpenChange }: RenameWalletDialogProps) {
  const updateWalletInfoMutation = useUpdateWalletInfo()
  const [name, setName] = useState('')

  useEffect(() => {
    setName(wallet?.name || '')
  }, [wallet])

  const isOpen = Boolean(wallet)
  const isSaving = updateWalletInfoMutation.isPending
  const trimmedName = name.trim()

  const handleSave = () => {
    if (!wallet || !trimmedName || isSaving) {
      return
    }

    updateWalletInfoMutation.mutate(
      { address: wallet.address, name: trimmedName },
      {
        onSuccess: () => {
          onOpenChange(false)
        },
      },
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className="w-[calc(100%-2rem)] max-w-[360px] rounded-[28px] border border-white/10 bg-[#111113]/96 p-6 text-white shadow-[0_24px_80px_rgba(0,0,0,0.55)] backdrop-blur-2xl"
      >
        {wallet ? (
          <div className="space-y-5">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-blue-500/25 bg-blue-500/10 shadow-[inset_0_0_20px_rgba(59,130,246,0.16)]">
              <PencilLine className="h-7 w-7 text-blue-300" />
            </div>

            <div className="space-y-2 text-center">
              <h3 className="text-[28px] font-semibold tracking-tight text-zinc-50">
                Rename Wallet
              </h3>
              <p className="text-sm leading-relaxed text-zinc-400">
                Update the display name for this wallet. Only the wallet name will be changed.
              </p>
            </div>

            <div className="flex items-center gap-3 rounded-2xl border border-white/8 bg-black/20 px-4 py-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-zinc-800">
                <WalletIcon className="h-5 w-5 text-zinc-400" />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-zinc-100">
                  {wallet.name || 'Unnamed Wallet'}
                </p>
                <p className="mt-1 truncate font-mono text-[11px] text-zinc-500">
                  0x{wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="wallet-name" className="text-sm font-medium text-zinc-200">
                Wallet name
              </label>
              <input
                id="wallet-name"
                type="text"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Enter wallet name"
                disabled={isSaving}
                className="w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-3 text-sm text-white outline-none transition-colors placeholder:text-zinc-400 focus:border-white/20 focus:bg-white/[0.08] disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={handleSave}
                disabled={!trimmedName || isSaving}
                className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-linear-to-r from-blue-500 to-indigo-500 text-sm font-semibold text-white transition-all hover:from-blue-400 hover:to-indigo-400 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isSaving && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
              </button>

              <button
                type="button"
                onClick={() => onOpenChange(false)}
                disabled={isSaving}
                className="h-12 w-full rounded-2xl border border-white/10 bg-white/[0.02] text-sm font-semibold text-zinc-200 transition-colors hover:bg-white/[0.05] disabled:cursor-not-allowed disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}

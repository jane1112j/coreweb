import { useTranslation } from 'react-i18next'

interface DrawerFooterProps {
  onSupport: () => void
}

export function DrawerFooter({ onSupport }: DrawerFooterProps) {
  const { t } = useTranslation()

  return (
    <div className="py-4 mt-auto text-center">
      <p className="text-zinc-500 text-xs font-medium">
        {t('wallet.footer.needHelp')}{' '}
        <button
          onClick={onSupport}
          className="text-zinc-300 hover:text-white transition-all font-semibold"
        >
          {t('wallet.footer.contactSupport')}
        </button>
      </p>
    </div>
  )
}

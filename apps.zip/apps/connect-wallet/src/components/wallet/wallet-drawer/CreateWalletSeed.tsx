import { seedPhraseToString } from '@/utils'
import { ArrowLeft, Copy, Image as ImageIcon, Loader2 } from 'lucide-react'
import { useRef, useState } from 'react'
import QRCode from 'react-qr-code'
import { toast } from 'sonner'
import { useSaveQrCode } from '../../../hooks/useSaveQrCode'
import { useSeedPhrase } from '../../../hooks/useSeedPhrase'
import { useCreateWallet } from '../../../hooks/useCreateWallet'
import { CustomYourSeed } from './CustomYourSeed'

interface CreateWalletSeedProps {
  onBack: () => void
  onSuccess: (wallet?: { address?: string; name?: string }) => void
}

export function CreateWalletSeed({ onBack, onSuccess }: CreateWalletSeedProps) {
  const qrContainerRef = useRef<HTMLDivElement>(null)
  const [walletName, setWalletName] = useState('')
  const [customSeed, setCustomSeed] = useState<string[] | null>(null)
  const [isCustomizingSeed, setIsCustomizingSeed] = useState(false)

  const { data: seedData, isLoading: isFetchingSeed } = useSeedPhrase()
  const { saveQrCode } = useSaveQrCode()
  const createWalletMutation = useCreateWallet()

  const generatedSeed = seedData?.listSeed || []
  const seed = customSeed ?? generatedSeed
  const seedString = seedPhraseToString(seed)
  const isCreating = createWalletMutation.isPending
  const isUsingCustomSeed = customSeed !== null

  const handleApplyCustomSeed = (words: string[]) => {
    setCustomSeed(words)
    setIsCustomizingSeed(false)
    toast.success('Custom seed phrase applied')
  }

  const handleUseGeneratedSeed = () => {
    setCustomSeed(null)
    toast.success('Switched back to generated seed phrase')
  }

  const handleCopySeed = () => {
    if (seedString && seed.length > 0) {
      navigator.clipboard.writeText(seedString)
      toast.success('Seed phrase copied to clipboard')
    }
  }

  const handleSaveQR = () => {
    saveQrCode(qrContainerRef)
  }

  const handleCreateWallet = () => {
    if (seed.length === 0) {
      toast.error('Seed phrase not ready')
      return
    }

    createWalletMutation.mutate(
      {
        seedPhrase: seed,
        name: walletName.trim() || undefined,
      },
      {
        onSuccess: (createdWallet) => {
          onSuccess(createdWallet)
        },
      },
    )
  }

  if (isCustomizingSeed) {
    return (
      <div className="flex h-full min-h-0 overflow-hidden">
        <CustomYourSeed
          initialWords={customSeed ?? []}
          onBack={() => setIsCustomizingSeed(false)}
          onConfirm={handleApplyCustomSeed}
          disabled={isCreating}
        />
      </div>
    )
  }

  if (isFetchingSeed && !isUsingCustomSeed) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <Loader2 className="h-8 w-8 animate-spin text-zinc-500" />
        <p className="text-zinc-400 text-sm">Generating seed phrase...</p>
      </div>
    )
  }

  return (
    <div
      data-vaul-no-drag
      className="flex h-full min-h-0 flex-1 flex-col gap-[clamp(0.875rem,2vh,1.5rem)] overflow-y-auto overscroll-contain pr-1 pb-[clamp(1rem,2.4vh,1.5rem)] animate-in slide-in-from-right duration-300 custom-scrollbar"
    >
      <h2 className="text-[clamp(1.25rem,2.8vw,1.375rem)] font-semibold text-zinc-100 tracking-tight">
        Create with Seed Phrase!
      </h2>

      <div className="relative">
        <input
          type="text"
          value={walletName}
          onChange={(e) => setWalletName(e.target.value)}
          placeholder="Enter name..."
          disabled={isCreating}
          className="w-full rounded-xl border border-white/10 bg-[#242427]/90 px-4 py-[clamp(0.75rem,1.8vh,0.875rem)] text-sm text-white placeholder:text-zinc-400 transition-colors focus:border-white/25 focus:bg-[#2A2A2D] focus:outline-none disabled:opacity-50"
        />
        <Copy
          className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-400 hover:text-white cursor-pointer transition-colors"
          onClick={handleCopySeed}
        />
      </div>

      <p className="text-[clamp(0.75rem,1.45vw,0.8125rem)] leading-snug text-zinc-400">
        Please save these 24 words on a piece of paper. This seed will allow you to sign in your
        account.
      </p>

      {isUsingCustomSeed && (
        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-[12px] text-emerald-300">
          You are using your custom 24-word seed phrase for this wallet.
        </div>
      )}

      <div className="grid grid-cols-4 gap-[clamp(0.375rem,0.9vw,0.5rem)]">
        {seed.map((word, i) => (
          <div
            key={i}
            className="flex min-w-0 items-center rounded-lg border border-white/5 bg-[#1C1C1E] px-[clamp(0.375rem,0.8vw,0.5rem)] py-[clamp(0.375rem,0.8vh,0.5rem)] text-[clamp(0.8125rem,1.45vw,0.875rem)] text-white transition-colors hover:bg-white/5"
          >
            <span className="mr-1 text-zinc-500">{String(i + 1).padStart(2, '0')}.</span>
            <span className="truncate font-medium text-zinc-200">{word}</span>
          </div>
        ))}
      </div>

      <div className="flex flex-col items-center gap-[clamp(0.5rem,1.2vh,0.75rem)] pt-1">
        <button
          type="button"
          onClick={() => setIsCustomizingSeed(true)}
          disabled={isCreating}
          className="text-zinc-300 hover:text-white text-sm font-medium underline underline-offset-4 decoration-zinc-600 hover:decoration-white transition-all disabled:opacity-50"
        >
          {isUsingCustomSeed ? 'Edit your custom seed phrase' : 'Custom your seed phrase'}
        </button>
        {isUsingCustomSeed && (
          <button
            type="button"
            onClick={handleUseGeneratedSeed}
            disabled={isCreating}
            className="text-zinc-400 hover:text-white text-sm font-medium underline underline-offset-4 decoration-zinc-700 hover:decoration-white transition-all disabled:opacity-50"
          >
            Use generated seed phrase
          </button>
        )}
        <button
          type="button"
          onClick={handleCopySeed}
          disabled={isCreating || seed.length === 0}
          className="text-zinc-300 hover:text-white text-sm font-medium underline underline-offset-4 decoration-zinc-600 hover:decoration-white transition-all disabled:opacity-50"
        >
          Copy your seed
        </button>
      </div>

      <div className="flex justify-center pt-1">
        <div
          ref={qrContainerRef}
          className="rounded-2xl bg-white p-[clamp(0.625rem,1.5vh,0.75rem)] shadow-xl"
        >
          <QRCode
            value={seedString}
            size={160}
            className="h-[clamp(7rem,18vh,10rem)] w-[clamp(7rem,18vh,10rem)]"
          />
        </div>
      </div>

      <button
        onClick={handleSaveQR}
        disabled={isCreating}
        className="mx-auto flex items-center justify-center gap-2 pb-2 pt-1 text-sm font-medium text-zinc-400 transition-colors hover:text-white disabled:opacity-50"
      >
        <span>Save your QR code in your device</span>
        <ImageIcon className="h-5 w-5" />
      </button>

      <div className="mt-auto flex items-center gap-4 pt-2">
        <button
          onClick={onBack}
          disabled={isCreating}
          className="h-[52px] w-[52px] rounded-full border border-white/20 flex items-center justify-center hover:bg-white/5 transition-colors shrink-0 disabled:opacity-50"
        >
          <ArrowLeft className="h-5 w-5 text-zinc-300" />
        </button>
        <button
          onClick={handleCreateWallet}
          disabled={isCreating || seed.length === 0}
          className="flex-1 h-[52px] rounded-full border border-white/20 bg-white/5 hover:bg-white/10 text-zinc-200 font-semibold transition-colors tracking-wide text-sm flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isCreating && <Loader2 className="h-4 w-4 animate-spin" />}
          {isCreating ? 'CREATING...' : 'CONTINUE'}
        </button>
      </div>
    </div>
  )
}

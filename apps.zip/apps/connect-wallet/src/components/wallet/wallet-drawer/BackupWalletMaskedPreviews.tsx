interface MaskedSecretPreviewProps {
  compact?: boolean
}

export function MaskedSecretPreview({ compact = false }: MaskedSecretPreviewProps) {
  return (
    <div
      aria-hidden="true"
      className={`relative w-full overflow-hidden rounded-[clamp(0.75rem,3vw,0.9rem)] border border-white/8 bg-black/20 px-[clamp(0.75rem,3vw,0.875rem)] py-[clamp(0.75rem,3vw,0.875rem)] ${
        compact ? 'min-h-[clamp(4.75rem,18vw,5.25rem)]' : 'min-h-[clamp(5.25rem,20vw,6rem)]'
      }`}
    >
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.03),transparent_42%,rgba(255,255,255,0.02)_68%,transparent)]" />
      <div className="pointer-events-none absolute inset-0 opacity-50 [background-image:repeating-linear-gradient(0deg,transparent_0,transparent_8px,rgba(255,255,255,0.03)_8px,rgba(255,255,255,0.03)_9px)]" />
      <div className="relative space-y-[clamp(0.5rem,2vw,0.625rem)]">
        <div className="h-[clamp(0.625rem,2.4vw,0.75rem)] w-[88%] rounded-full bg-white/[0.08] blur-[1px]" />
        <div className="h-[clamp(0.625rem,2.4vw,0.75rem)] w-[76%] rounded-full bg-white/[0.07] blur-[1px]" />
        <div className="h-[clamp(0.625rem,2.4vw,0.75rem)] w-[92%] rounded-full bg-white/[0.08] blur-[1px]" />
        {!compact && (
          <div className="h-[clamp(0.625rem,2.4vw,0.75rem)] w-[64%] rounded-full bg-white/[0.06] blur-[1px]" />
        )}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-[-30%] w-[36%] rotate-6 bg-linear-to-r from-transparent via-white/10 to-transparent blur-2xl animate-pulse" />
    </div>
  )
}

export function MaskedQrPreview() {
  return (
    <div
      aria-hidden="true"
      className="relative flex h-[clamp(8.25rem,36vw,10.75rem)] w-[clamp(8.25rem,36vw,10.75rem)] items-center justify-center overflow-hidden rounded-[clamp(1rem,4vw,1.375rem)] border border-white/8 bg-white/[0.04] p-[clamp(0.625rem,2.5vw,0.75rem)]"
    >
      <div className="grid grid-cols-6 gap-[clamp(0.18rem,0.8vw,0.25rem)] opacity-70 blur-[0.6px]">
        {Array.from({ length: 36 }, (_, index) => (
          <div
            key={index}
            className={`h-[clamp(0.72rem,3.2vw,1rem)] w-[clamp(0.72rem,3.2vw,1rem)] rounded-[4px] ${
              index % 3 === 0 || index % 5 === 0 ? 'bg-white/18' : 'bg-white/7'
            }`}
          />
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-[-28%] w-[34%] rotate-6 bg-linear-to-r from-transparent via-white/12 to-transparent blur-2xl animate-pulse" />
    </div>
  )
}

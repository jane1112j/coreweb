import { ArrowLeft, Clipboard, Image as ImageIcon, Scan, Loader2 } from 'lucide-react'
import { useState, useRef } from 'react'
import { useImportPrivateKey } from '../../../hooks/useImportPrivateKey'
import { useQrImport } from '../hooks/useQrImport'
import { toast } from 'sonner'
import { getFromClipboard } from '@metanodejs/system-core'

interface ImportWalletPrivateKeyProps {
  onBack: () => void
  onSuccess: (wallet?: { address?: string; name?: string }) => void
}

export function ImportWalletPrivateKey({ onBack, onSuccess }: ImportWalletPrivateKeyProps) {
  const [privateKey, setPrivateKey] = useState('')
  const [name, setName] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { handleScan, handleBrowserFile } = useQrImport()

  const { mutate: importWallet, isPending: isImporting } = useImportPrivateKey()

  const handleScanQR = async () => {
    const result = await handleScan()
    if (result !== null) setPrivateKey(result)
  }

  const handleUploadQR = async () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const result = await handleBrowserFile(file)
    if (result !== null) setPrivateKey(result)

    // Reset input
    event.target.value = ''
  }

  const handlePaste = async () => {
    try {
      const text = await getFromClipboard()
      console.log('text', text)
      if (text.value.trim()) {
        setPrivateKey(text.value.trim())
        toast.success('Pasted from clipboard')
      } else {
        toast.error('Clipboard is empty')
      }
    } catch (err) {
      console.error('Failed to read clipboard:', err)
      toast.error('Permission to access clipboard denied')
    }
  }

  const handleConfirm = async () => {
    if (!privateKey.trim()) {
      toast.error('Please enter your private key')
      return
    }

    importWallet(
      { privateKey, name: name.trim() || undefined },
      {
        onSuccess: (createdWallet) => {
          onSuccess(createdWallet)
        },
      },
    )
  }

  return (
    <div
      data-vaul-no-drag
      className="flex h-full min-h-0 flex-1 flex-col gap-[clamp(0.875rem,2vh,1.5rem)] overflow-y-auto overscroll-contain pr-1 pb-[clamp(1rem,2.4vh,1.5rem)] pt-[clamp(1rem,2.4vh,1.5rem)] animate-in slide-in-from-right duration-300 custom-scrollbar"
    >
      <h2 className="text-[clamp(1.25rem,2.8vw,1.375rem)] font-semibold text-zinc-100 tracking-tight">
        Import with Private Key
      </h2>

      <div className="space-y-[clamp(0.75rem,1.8vh,1rem)]">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Wallet name (Optional)"
          className="w-full rounded-xl border border-white/10 bg-[#242427]/90 px-4 py-[clamp(0.75rem,1.8vh,0.875rem)] text-sm text-white placeholder:text-zinc-400 transition-colors focus:border-white/25 focus:bg-[#2A2A2D] focus:outline-none"
          disabled={isImporting}
        />

        <div className="relative">
          <input
            type="text"
            value={privateKey}
            onChange={(e) => setPrivateKey(e.target.value)}
            placeholder="Enter your private key"
            className="w-full rounded-xl border border-white/10 bg-[#242427]/90 px-4 py-[clamp(0.75rem,1.8vh,0.875rem)] pr-12 text-sm text-white placeholder:text-zinc-400 transition-colors focus:border-white/25 focus:bg-[#2A2A2D] focus:outline-none"
            disabled={isImporting}
          />
          <Clipboard
            className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-400 hover:text-white cursor-pointer transition-colors"
            onClick={handlePaste}
          />
        </div>
      </div>

      <div className="flex items-center gap-4 py-1">
        <div className="h-px flex-1 bg-white/10" />
        <span className="text-zinc-500 text-xs font-medium uppercase tracking-wider">Or</span>
        <div className="h-px flex-1 bg-white/10" />
      </div>

      <div className="flex min-h-[clamp(12rem,30vh,15rem)] flex-col items-center justify-center rounded-2xl border-2 border-dashed border-white/10 bg-white/2 p-[clamp(1rem,2.8vh,2rem)] space-y-[clamp(1rem,2vh,1.5rem)]">
        <div className="flex flex-col items-center gap-3 text-zinc-400">
          <div className="h-12 w-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/5">
            <ImageIcon className="h-6 w-6" />
          </div>
          <span className="text-sm font-medium">Input with QR code</span>
        </div>

        <div className="grid w-full grid-cols-2 gap-3">
          <button
            onClick={handleScanQR}
            disabled={isImporting}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-xs font-medium text-zinc-300 disabled:opacity-50"
          >
            <Scan className="h-4 w-4" />
            Scan QR code
          </button>
          <button
            onClick={handleUploadQR}
            disabled={isImporting}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-xs font-medium text-zinc-300 disabled:opacity-50"
          >
            <ImageIcon className="h-4 w-4" />
            Upload image
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
        </div>
      </div>

      <div className="mt-auto flex items-center gap-4 pt-2">
        <button
          onClick={onBack}
          disabled={isImporting}
          className="h-[52px] w-[52px] rounded-full border border-white/20 flex items-center justify-center hover:bg-white/5 transition-colors shrink-0 disabled:opacity-50"
        >
          <ArrowLeft className="h-5 w-5 text-zinc-300" />
        </button>
        <button
          onClick={handleConfirm}
          disabled={isImporting || !privateKey.trim()}
          className="flex-1 h-[52px] rounded-full border border-white/20 bg-white/5 hover:bg-white/10 text-zinc-200 font-semibold transition-colors tracking-wide text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isImporting && <Loader2 className="h-4 w-4 animate-spin" />}
          {isImporting ? 'IMPORTING...' : 'CONFIRM'}
        </button>
      </div>
    </div>
  )
}

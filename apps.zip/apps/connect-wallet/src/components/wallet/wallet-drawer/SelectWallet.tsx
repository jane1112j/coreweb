import { useState } from 'react'
import { CheckCircle2, PlusCircle, Wallet as WalletIcon } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { BackupWalletDialog } from './BackupWalletDialog'
import { DeleteWalletDialog } from './DeleteWalletDialog'
import { RenameWalletDialog } from './RenameWalletDialog'
import { WalletItemActions } from './WalletItemActions'

interface Wallet {
  address: string
  name?: string
  // other properties...
}

interface SelectWalletProps {
  wallets: Wallet[]
  activeWalletAddress: string | null
  onSelect: (wallet: Wallet) => void
  onAddNew: () => void
}

export function SelectWallet({
  wallets,
  activeWalletAddress,
  onSelect,
  onAddNew,
}: SelectWalletProps) {
  const { t } = useTranslation()
  const [walletPendingRename, setWalletPendingRename] = useState<Wallet | null>(null)
  const [walletPendingBackup, setWalletPendingBackup] = useState<Wallet | null>(null)
  const [walletPendingDelete, setWalletPendingDelete] = useState<Wallet | null>(null)

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col overflow-hidden">
      <div className="shrink-0 space-y-2 pb-5 pt-2">
        <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-linear-to-r from-white to-zinc-400 tracking-tight">
          {t('wallet.select.title')}
        </h2>
        <p className="text-zinc-400 text-sm leading-relaxed">
          {t('wallet.select.description')}
        </p>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain custom-scrollbar space-y-3 pr-2 pt-1">
        {wallets.map((wallet) => {
          const isActive = wallet.address === activeWalletAddress
          return (
            <div
              key={wallet.address}
              className={`group w-full rounded-2xl p-4 shadow-[0_0_0_1px_rgba(255,255,255,0.02)] transition-all duration-300 ${
                isActive
                  ? 'border border-blue-500/20 bg-linear-to-r from-blue-500/10 to-indigo-500/10 shadow-[0_4px_20px_rgba(59,130,246,0.1)]'
                  : 'cursor-pointer border border-white/5 bg-black/20 hover:-translate-y-0.5 hover:border-white/20 hover:bg-white/[0.06] hover:shadow-[0_10px_30px_rgba(0,0,0,0.28)]'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => onSelect(wallet)}
                className="flex min-w-0 flex-1 cursor-pointer items-center gap-4 text-left"
              >
                <div
                  className={`h-10 w-10 rounded-full flex items-center justify-center border transition-all ${
                    isActive
                      ? 'bg-linear-to-br from-blue-400/20 to-indigo-500/20 border-blue-400/30'
                      : 'border-zinc-700 bg-zinc-800 group-hover:border-white/20 group-hover:bg-zinc-700/80'
                  }`}
                >
                  <WalletIcon
                    className={`h-5 w-5 transition-colors ${isActive ? 'text-blue-400' : 'text-zinc-400 group-hover:text-zinc-200'}`}
                  />
                </div>
                <div className="flex min-w-0 flex-col items-start">
                  <span
                    className={`font-semibold text-base transition-colors ${isActive ? 'text-white' : 'text-zinc-300 group-hover:text-white'}`}
                  >
                    {wallet.name || t('wallet.select.unnamed')}
                  </span>
                  <span className="mt-1 truncate text-xs font-mono text-zinc-500">
                    0x{wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}
                  </span>
                </div>
              </button>

              <div className="ml-3 flex shrink-0 items-center gap-2">
                {isActive && <CheckCircle2 className="h-6 w-6 text-blue-500" />}
                <WalletItemActions
                  walletName={wallet.name}
                  isActive={isActive}
                  onRename={() => setWalletPendingRename(wallet)}
                  onBackup={() => setWalletPendingBackup(wallet)}
                  onDelete={() => setWalletPendingDelete(wallet)}
                />
              </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="shrink-0 bg-linear-to-t from-[#09090B] via-[#09090B] to-[#09090B]/80 pt-4">
        <button
          onClick={onAddNew}
          className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-transparent border border-dashed border-white/20 hover:border-white/40 hover:bg-white/5 text-zinc-400 hover:text-white transition-all duration-300"
        >
          <PlusCircle className="h-5 w-5" />
          <span className="font-medium text-sm">{t('wallet.select.addNew')}</span>
        </button>
      </div>

      <RenameWalletDialog
        wallet={walletPendingRename}
        onOpenChange={(open) => {
          if (!open) {
            setWalletPendingRename(null)
          }
        }}
      />

      <DeleteWalletDialog
        wallet={walletPendingDelete}
        onOpenChange={(open) => {
          if (!open) {
            setWalletPendingDelete(null)
          }
        }}
        onRequestBackup={(wallet) => {
          setWalletPendingDelete(null)
          setWalletPendingBackup(wallet)
        }}
      />

      <BackupWalletDialog
        wallet={walletPendingBackup}
        onOpenChange={(open) => {
          if (!open) {
            setWalletPendingBackup(null)
          }
        }}
      />
    </div>
  )
}

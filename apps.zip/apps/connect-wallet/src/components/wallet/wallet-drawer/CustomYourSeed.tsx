import {
  createCustomSeedWordsState,
  CUSTOM_SEED_WORD_COUNT,
  mergeCustomSeedWords,
  normalizeCustomSeedWord,
  splitCustomSeedWords,
  validateCustomSeedWords,
} from '@/utils'
import { ArrowLeft, Eraser } from 'lucide-react'
import {
  type ChangeEvent,
  type ClipboardEvent,
  type KeyboardEvent,
  useMemo,
  useRef,
  useState,
} from 'react'
import { toast } from 'sonner'

interface CustomYourSeedProps {
  initialWords?: string[]
  onBack: () => void
  onConfirm: (seedPhrase: string[]) => void
  disabled?: boolean
}

export function CustomYourSeed({
  initialWords = [],
  onBack,
  onConfirm,
  disabled = false,
}: CustomYourSeedProps) {
  const [words, setWords] = useState<string[]>(() => createCustomSeedWordsState(initialWords))
  const inputRefs = useRef<Array<HTMLInputElement | null>>([])

  const validation = useMemo(() => validateCustomSeedWords(words), [words])

  const invalidSet = new Set(validation.invalidIndexes)
  const duplicateSet = new Set(validation.duplicateIndexes)

  const focusInput = (index: number) => {
    inputRefs.current[index]?.focus()
  }

  const updateWordAt = (index: number, value: string) => {
    const nextValue = normalizeCustomSeedWord(value)
    setWords((prev) => {
      const next = [...prev]
      next[index] = nextValue
      return next
    })
  }

  const fillWordsFromIndex = (index: number, rawValue: string) => {
    const { nextFocusIndex, nextWords, parsedWords, truncated } = mergeCustomSeedWords(
      words,
      index,
      rawValue,
    )

    if (parsedWords.length === 0) {
      updateWordAt(index, '')
      return
    }

    setWords(nextWords)

    if (truncated) {
      toast.warning('Only 24 words can be entered')
    }

    requestAnimationFrame(() => focusInput(nextFocusIndex))
  }

  const handleInputChange = (index: number, event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value
    const parsedWords = splitCustomSeedWords(value)

    if (/[,\s]/.test(value) && parsedWords.length > 0) {
      fillWordsFromIndex(index, value)
      return
    }

    updateWordAt(index, value)
  }

  const handleInputPaste = (index: number, event: ClipboardEvent<HTMLInputElement>) => {
    const pastedText = event.clipboardData.getData('text')
    const parsedWords = splitCustomSeedWords(pastedText)

    if (parsedWords.length === 0) return

    event.preventDefault()
    fillWordsFromIndex(index, pastedText)
  }

  const handleKeyDown = (index: number, event: KeyboardEvent<HTMLInputElement>) => {
    if ((event.key === ' ' || event.key === 'Enter') && words[index]) {
      event.preventDefault()
      focusInput(Math.min(index + 1, CUSTOM_SEED_WORD_COUNT - 1))
      return
    }

    if (event.key === 'Backspace' && !words[index] && index > 0) {
      event.preventDefault()
      focusInput(index - 1)
      return
    }

    if (event.key === 'ArrowLeft' && index > 0 && event.currentTarget.selectionStart === 0) {
      event.preventDefault()
      focusInput(index - 1)
      return
    }

    if (
      event.key === 'ArrowRight' &&
      index < CUSTOM_SEED_WORD_COUNT - 1 &&
      event.currentTarget.selectionStart === event.currentTarget.value.length
    ) {
      event.preventDefault()
      focusInput(index + 1)
    }
  }

  const handleClearAll = () => {
    setWords(createCustomSeedWordsState([]))
    requestAnimationFrame(() => focusInput(0))
  }

  const handleConfirm = () => {
    const firstEmptyIndex = words.findIndex((word) => !word)

    if (firstEmptyIndex !== -1) {
      toast.error(`Please enter all ${CUSTOM_SEED_WORD_COUNT} words`)
      focusInput(firstEmptyIndex)
      return
    }

    if (validation.invalidIndexes.length > 0) {
      toast.error('Words can only contain letters a-z without accents or special characters')
      focusInput(validation.invalidIndexes[0])
      return
    }

    if (validation.duplicateIndexes.length > 0) {
      toast.error('Each seed word must be different')
      focusInput(validation.duplicateIndexes[0])
      return
    }

    if (!validation.isPhraseValid) {
      toast.error('Please review your 24 words again')
      return
    }

    onConfirm(words)
  }

  const wordsRemaining = CUSTOM_SEED_WORD_COUNT - validation.filledCount

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col gap-[clamp(0.625rem,1.4vh,0.875rem)] overflow-hidden pb-[clamp(1rem,2vh,1.25rem)] pt-[clamp(1rem,2vh,1.25rem)] animate-in slide-in-from-right duration-300">
      <div className="shrink-0 space-y-[clamp(0.25rem,0.8vh,0.375rem)]">
        <h2 className="text-[clamp(1.125rem,2.6vw,1.375rem)] font-semibold text-zinc-100 tracking-tight">
          Custom Your Seed Phrase
        </h2>
        <p className="text-zinc-400 text-[clamp(0.6875rem,1.45vw,0.75rem)] leading-snug">
          Enter exactly 24 different words using only letters a-z. Do not use special characters or
          accented Vietnamese characters.
        </p>
      </div>

      <div className="shrink-0 flex items-center justify-between gap-[clamp(0.5rem,1vw,0.75rem)]">
        <div className="flex flex-wrap gap-[clamp(0.25rem,0.75vw,0.375rem)] text-[clamp(0.5625rem,1.1vw,0.625rem)]">
          <span className="rounded-full border border-white/10 bg-white/5 px-[clamp(0.5rem,1vw,0.625rem)] py-[clamp(0.1875rem,0.45vh,0.25rem)] text-zinc-300">
            {validation.filledCount}/{CUSTOM_SEED_WORD_COUNT} words
          </span>
          <span className="rounded-full border border-white/10 bg-white/5 px-[clamp(0.5rem,1vw,0.625rem)] py-[clamp(0.1875rem,0.45vh,0.25rem)] text-zinc-300">
            Letters a-z only
          </span>
          <span
            className={`rounded-full border px-[clamp(0.5rem,1vw,0.625rem)] py-[clamp(0.1875rem,0.45vh,0.25rem)] ${
              validation.duplicateIndexes.length === 0
                ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-300'
                : 'border-amber-500/20 bg-amber-500/10 text-amber-300'
            }`}
          >
            {validation.duplicateIndexes.length === 0
              ? 'Words are unique'
              : 'Duplicate words found'}
          </span>
        </div>

        <button
          type="button"
          onClick={handleClearAll}
          disabled={disabled}
          className="inline-flex items-center gap-[clamp(0.25rem,0.7vw,0.375rem)] rounded-full border border-white/10 bg-white/5 px-[clamp(0.5rem,1vw,0.625rem)] py-[clamp(0.3125rem,0.75vh,0.375rem)] text-[clamp(0.625rem,1.25vw,0.6875rem)] font-medium text-zinc-300 transition-colors hover:bg-white/10 hover:text-white disabled:opacity-50"
        >
          <Eraser className="h-[clamp(0.75rem,1.6vw,0.875rem)] w-[clamp(0.75rem,1.6vw,0.875rem)]" />
          Clear
        </button>
      </div>

      <div
        data-vaul-no-drag
        className="min-h-0 flex-1 overflow-y-auto overscroll-contain rounded-[clamp(0.875rem,2vw,1rem)] border border-white/5 bg-[#131316]/70 p-[clamp(0.625rem,1.4vw,0.75rem)] pr-[clamp(0.375rem,0.9vw,0.5rem)] custom-scrollbar"
      >
        <div className="grid grid-cols-2 gap-[clamp(0.5rem,1.2vw,0.625rem)]">
          {Array.from({ length: CUSTOM_SEED_WORD_COUNT }, (_, index) => {
            const word = words[index]
            const isInvalid = invalidSet.has(index)
            const isDuplicate = duplicateSet.has(index)
            const hasError = isInvalid || isDuplicate

            return (
              <label key={index} className="block min-w-0">
                <div className="relative">
                  <span className="pointer-events-none absolute left-[clamp(0.5rem,1vw,0.625rem)] top-1/2 flex h-[clamp(1.25rem,2.8vh,1.5rem)] w-[clamp(1.5rem,3.3vw,1.75rem)] -translate-y-1/2 items-center justify-center rounded-md border border-white/5 bg-black/20 text-[clamp(0.5625rem,1.1vw,0.625rem)] font-semibold text-zinc-500">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  {isInvalid ? (
                    <span className="pointer-events-none absolute right-[clamp(0.5rem,1vw,0.625rem)] top-1/2 flex h-[clamp(1.25rem,2.8vh,1.5rem)] min-w-[clamp(1.625rem,3.8vw,2rem)] -translate-y-1/2 items-center justify-center rounded-md border border-red-500/20 bg-red-500/10 px-[clamp(0.25rem,0.8vw,0.375rem)] text-[clamp(0.5rem,1vw,0.5625rem)] font-medium uppercase tracking-wide text-red-400">
                      Bad
                    </span>
                  ) : isDuplicate ? (
                    <span className="pointer-events-none absolute right-[clamp(0.5rem,1vw,0.625rem)] top-1/2 flex h-[clamp(1.25rem,2.8vh,1.5rem)] min-w-[clamp(1.625rem,3.8vw,2rem)] -translate-y-1/2 items-center justify-center rounded-md border border-amber-500/20 bg-amber-500/10 px-[clamp(0.25rem,0.8vw,0.375rem)] text-[clamp(0.5rem,1vw,0.5625rem)] font-medium uppercase tracking-wide text-amber-400">
                      Dup
                    </span>
                  ) : null}
                  <input
                    ref={(element) => {
                      inputRefs.current[index] = element
                    }}
                    type="text"
                    value={word}
                    onChange={(event) => handleInputChange(index, event)}
                    onPaste={(event) => handleInputPaste(index, event)}
                    onKeyDown={(event) => handleKeyDown(index, event)}
                    autoCapitalize="none"
                    autoComplete="off"
                    autoCorrect="off"
                    spellCheck={false}
                    disabled={disabled}
                    placeholder="Enter word"
                    className={`h-[clamp(2.125rem,4.6vh,2.5rem)] w-full min-w-0 rounded-[clamp(0.625rem,1.4vw,0.75rem)] border bg-[#242427]/90 pl-[clamp(2.5rem,5vw,2.75rem)] ${hasError ? 'pr-[clamp(2.75rem,5vw,3rem)]' : 'pr-[clamp(0.625rem,1.4vw,0.75rem)]'} text-[clamp(0.75rem,1.45vw,0.8125rem)] text-white placeholder:text-zinc-400 transition-colors focus:bg-[#2A2A2D] focus:outline-none ${
                      isInvalid
                        ? 'border-red-500/40 focus:border-red-500/60'
                        : isDuplicate
                          ? 'border-amber-500/40 focus:border-amber-500/60'
                          : word
                            ? 'border-emerald-500/20 focus:border-emerald-500/40'
                            : 'border-white/10 focus:border-white/25'
                    } disabled:opacity-50`}
                  />
                </div>
              </label>
            )
          })}
        </div>
      </div>

      <div className="shrink-0 space-y-[clamp(0.375rem,0.9vh,0.5rem)] pt-[clamp(0.125rem,0.4vh,0.25rem)]">
        {!validation.hasAllWords ? (
          <p className="rounded-[clamp(0.75rem,1.8vw,0.875rem)] border border-white/5 bg-white/3 px-[clamp(0.625rem,1.4vw,0.75rem)] py-[clamp(0.5rem,1vh,0.625rem)] text-[clamp(0.625rem,1.25vw,0.6875rem)] text-zinc-400">
            Enter {wordsRemaining} more word{wordsRemaining === 1 ? '' : 's'} to continue.
          </p>
        ) : validation.invalidIndexes.length > 0 ? (
          <p className="rounded-[clamp(0.75rem,1.8vw,0.875rem)] border border-red-500/20 bg-red-500/10 px-[clamp(0.625rem,1.4vw,0.75rem)] py-[clamp(0.5rem,1vh,0.625rem)] text-[clamp(0.625rem,1.25vw,0.6875rem)] text-red-300">
            Each word must contain only letters a-z, without special or accented characters.
          </p>
        ) : validation.duplicateIndexes.length > 0 ? (
          <p className="rounded-[clamp(0.75rem,1.8vw,0.875rem)] border border-amber-500/20 bg-amber-500/10 px-[clamp(0.625rem,1.4vw,0.75rem)] py-[clamp(0.5rem,1vh,0.625rem)] text-[clamp(0.625rem,1.25vw,0.6875rem)] text-amber-300">
            All 24 words must be different from each other.
          </p>
        ) : validation.isPhraseValid ? (
          <p className="rounded-[clamp(0.75rem,1.8vw,0.875rem)] border border-emerald-500/20 bg-emerald-500/10 px-[clamp(0.625rem,1.4vw,0.75rem)] py-[clamp(0.5rem,1vh,0.625rem)] text-[clamp(0.625rem,1.25vw,0.6875rem)] text-emerald-300">
            Seed phrase is ready to use.
          </p>
        ) : (
          <p className="rounded-[clamp(0.75rem,1.8vw,0.875rem)] border border-red-500/20 bg-red-500/10 px-[clamp(0.625rem,1.4vw,0.75rem)] py-[clamp(0.5rem,1vh,0.625rem)] text-[clamp(0.625rem,1.25vw,0.6875rem)] text-red-300">
            Please check your 24 words again.
          </p>
        )}

        <div className="flex items-center gap-[clamp(0.5rem,1vw,0.75rem)]">
          <button
            type="button"
            onClick={onBack}
            disabled={disabled}
            className="flex h-[clamp(2.5rem,5.2vh,2.75rem)] w-[clamp(2.5rem,5.2vh,2.75rem)] shrink-0 items-center justify-center rounded-full border border-white/20 transition-colors hover:bg-white/5 disabled:opacity-50"
          >
            <ArrowLeft className="h-[clamp(0.875rem,1.6vw,1rem)] w-[clamp(0.875rem,1.6vw,1rem)] text-zinc-300" />
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={disabled || !validation.isPhraseValid}
            className="flex h-[clamp(2.5rem,5.2vh,2.75rem)] flex-1 items-center justify-center rounded-full border border-white/20 bg-white/5 text-[clamp(0.75rem,1.45vw,0.8125rem)] font-semibold tracking-wide text-zinc-200 transition-colors hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-50"
          >
            USE THIS SEED
          </button>
        </div>
      </div>
    </div>
  )
}

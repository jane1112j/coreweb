import { sendCommand } from '@metanodejs/system-core'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { activeWalletQueryKey } from './useGetActiveWallet'
import { allWalletsQueryKey } from './useGetAllWallets'

export function useDeleteWallet() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async ({ address }: { address: string }) => {
      return await sendCommand('deleteWallet', { address })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: allWalletsQueryKey })
      queryClient.invalidateQueries({ queryKey: activeWalletQueryKey })
      toast.success('Wallet deleted successfully')
    },
    onError: (error) => {
      console.error('Delete wallet error:', error)
      toast.error((error as Error)?.message || 'Failed to delete wallet')
    },
  })
}

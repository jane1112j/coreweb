import { createWalletFromPrivateKey } from '@metanodejs/system-core'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { activeWalletQueryKey } from './useGetActiveWallet'
import { allWalletsQueryKey } from './useGetAllWallets'

export function useImportPrivateKey() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async ({ privateKey, name }: { privateKey: string; name?: string }) => {
      const trimmedKey = privateKey.trim()
      const normalizedKey = trimmedKey.startsWith('0x') ? trimmedKey : `0x${trimmedKey}`

      return await createWalletFromPrivateKey({
        privateKey: normalizedKey,
        name: name?.trim() || `wallet_${Date.now()}`,
        backgroundImage: '',
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: allWalletsQueryKey })
      queryClient.invalidateQueries({ queryKey: activeWalletQueryKey })
      toast.success('Wallet imported successfully')
    },
    onError: (error) => {
      console.error('Import error:', error)
      toast.error((error as Error)?.message || 'Failed to import wallet')
    },
  })
}

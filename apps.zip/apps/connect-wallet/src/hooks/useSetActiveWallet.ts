import type { WalletData } from '@/hooks/useGetAllWallets'
import { activeWalletQueryKey } from '@/hooks/useGetActiveWallet'
import { sendCommand } from '@metanodejs/system-core'
import { useQueryClient } from '@tanstack/react-query'

export function useSetActiveWallet() {
  const queryClient = useQueryClient()

  return async (wallet: WalletData) => {
    await sendCommand('setActiveWallet', { address: wallet.address })

    queryClient.setQueryData<WalletData | null>(activeWalletQueryKey, wallet)
  }
}

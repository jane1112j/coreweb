import { sendCommand } from '@metanodejs/system-core'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { activeWalletQueryKey } from './useGetActiveWallet'
import { allWalletsQueryKey } from './useGetAllWallets'

export function useUpdateWalletInfo() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async ({ address, name }: { address: string; name?: string }) => {
      return await sendCommand('updateWalletInfo', { address, name })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: allWalletsQueryKey })
      queryClient.invalidateQueries({ queryKey: activeWalletQueryKey })
      toast.success('Wallet updated successfully')
    },
    onError: (error) => {
      console.error('Update wallet error:', error)
      toast.error((error as Error)?.message || 'Failed to update wallet')
    },
  })
}

import { getAllWallets, sendCommand } from '@metanodejs/system-core'
import { useQuery, useQueryClient } from '@tanstack/react-query'

export interface WalletData {
  address: string
  name?: string
}

export interface WalletState {
  wallets: WalletData[]
  activeWallet: WalletData | null
}

export const walletStateQueryKey = ['allWallets', 'activeWallet'] as const

export function useWalletState() {
  return useQuery({
    queryKey: walletStateQueryKey,
    queryFn: async (): Promise<WalletState> => {
      try {
        const wallets = (await getAllWallets()) || []
        const activeWallet = await sendCommand('getActiveWallet')
        console.log('activeWallet', activeWallet)
        return { wallets, activeWallet }
      } catch (error) {
        console.error('Failed to init wallet list:', error)
        throw error
      }
    },
    refetchOnWindowFocus: false,
  })
}

export function useSetActiveWallet() {
  const queryClient = useQueryClient()

  return async (wallet: WalletData) => {
    await sendCommand('setActiveWallet', { address: wallet.address })

    queryClient.setQueryData<WalletState>(walletStateQueryKey, (current) =>
      current ? { ...current, activeWallet: wallet } : current,
    )
  }
}

import { getSeed } from '@metanodejs/system-core'
import { useQuery } from '@tanstack/react-query'

export function useSeedPhrase() {
  return useQuery({
    queryKey: ['seedPhrase'],
    queryFn: async () => {
      const res = await getSeed()
      console.log('UI WALLET WEB CHAT - GET SEED ----- ', res)
      return res
    },
    staleTime: 0,
    gcTime: 0,
    refetchOnWindowFocus: false,
  })
}

import { createWallet } from '@metanodejs/system-core'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { activeWalletQueryKey } from './useGetActiveWallet'
import { allWalletsQueryKey } from './useGetAllWallets'

export function useCreateWallet() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async ({ seedPhrase, name }: { seedPhrase: string[]; name?: string }) => {
      return await createWallet({
        seed: seedPhrase,
        name: name || `wallet-${Date.now()}`,
        backgroundImage: '',
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: allWalletsQueryKey })
      queryClient.invalidateQueries({ queryKey: activeWalletQueryKey })
      toast.success('Wallet created successfully')
    },
    onError: (error) => {
      console.error('Create wallet error:', error)
      toast.error((error as Error)?.message || 'Failed to create wallet')
    },
  })
}

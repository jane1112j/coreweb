import { toast } from 'sonner'

const parsePixelValue = (value: string) => {
  const parsed = Number.parseFloat(value)
  return Number.isNaN(parsed) ? 0 : parsed
}

export function useSaveQrCode() {
  const saveQrCode = async (
    containerRef: React.RefObject<HTMLElement | null>,
    fileName = `seed-phrase-${Date.now()}.png`,
  ) => {
    const element = containerRef.current
    if (!element) {
      toast.error('QR code container not found')
      return
    }

    // If the element itself is an SVG, use it. Otherwise, look for an SVG inside it.
    const svgElement =
      element.tagName.toLowerCase() === 'svg'
        ? (element as unknown as SVGSVGElement)
        : element.querySelector('svg')

    if (!svgElement) {
      toast.error('QR code SVG element not found')
      return
    }

    try {
      const svgData = new XMLSerializer().serializeToString(svgElement)
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      const img = new Image()

      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' })
      const url = URL.createObjectURL(svgBlob)

      img.onload = () => {
        const containerRect = element.getBoundingClientRect()
        const rect = svgElement.getBoundingClientRect()
        const width = Math.round(containerRect.width) || Math.round(rect.width) || 256
        const height = Math.round(containerRect.height) || Math.round(rect.height) || 256
        const svgWidth =
          svgElement.clientWidth || rect.width || Number(svgElement.getAttribute('width')) || 256
        const svgHeight =
          svgElement.clientHeight || rect.height || Number(svgElement.getAttribute('height')) || 256
        const offsetX = rect.left - containerRect.left
        const offsetY = rect.top - containerRect.top
        const styles = window.getComputedStyle(element)
        const backgroundColor =
          styles.backgroundColor && styles.backgroundColor !== 'rgba(0, 0, 0, 0)'
            ? styles.backgroundColor
            : 'white'
        const borderRadius = parsePixelValue(styles.borderTopLeftRadius)
        const borderWidth = parsePixelValue(styles.borderTopWidth)
        const borderColor = styles.borderTopColor

        // Increase resolution for better quality
        const scale = 4
        canvas.width = width * scale
        canvas.height = height * scale

        if (ctx) {
          ctx.scale(scale, scale)

          if (borderRadius > 0) {
            ctx.beginPath()
            ctx.moveTo(borderRadius, 0)
            ctx.lineTo(width - borderRadius, 0)
            ctx.quadraticCurveTo(width, 0, width, borderRadius)
            ctx.lineTo(width, height - borderRadius)
            ctx.quadraticCurveTo(width, height, width - borderRadius, height)
            ctx.lineTo(borderRadius, height)
            ctx.quadraticCurveTo(0, height, 0, height - borderRadius)
            ctx.lineTo(0, borderRadius)
            ctx.quadraticCurveTo(0, 0, borderRadius, 0)
            ctx.closePath()
            ctx.fillStyle = backgroundColor
            ctx.fill()

            if (borderWidth > 0) {
              ctx.lineWidth = borderWidth
              ctx.strokeStyle = borderColor
              ctx.stroke()
            }
          } else {
            ctx.fillStyle = backgroundColor
            ctx.fillRect(0, 0, width, height)

            if (borderWidth > 0) {
              ctx.lineWidth = borderWidth
              ctx.strokeStyle = borderColor
              ctx.strokeRect(
                borderWidth / 2,
                borderWidth / 2,
                width - borderWidth,
                height - borderWidth,
              )
            }
          }

          ctx.drawImage(img, offsetX, offsetY, svgWidth, svgHeight)
        }

        const pngUrl = canvas.toDataURL('image/png')
        const downloadLink = document.createElement('a')
        downloadLink.href = pngUrl
        downloadLink.download = fileName
        document.body.appendChild(downloadLink)
        downloadLink.click()
        document.body.removeChild(downloadLink)
        URL.revokeObjectURL(url)

        toast.success('QR Code saved successfully')
      }

      img.onerror = () => {
        URL.revokeObjectURL(url)
        toast.error('Failed to render QR Code')
      }

      img.src = url
    } catch (error) {
      console.error('Save QR Code error:', error)
      toast.error('Failed to save QR Code')
    }
  }

  return { saveQrCode }
}

import { sendCommand } from '@metanodejs/system-core'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'

export interface BackupWalletResponse {
  address: string
  name: string
  privateKey: string
  seedPhrase: string
}

export function useBackupWallet() {
  return useMutation({
    mutationFn: async ({ address }: { address: string }) => {
      await sendCommand('lockVault')
      return (await sendCommand('backupWallet', { address })) as BackupWalletResponse
    },
    onError: (error) => {
      if (error instanceof Error && error.message === 'UNLOCK_CANCELLED') {
        return
      }

      console.error('Backup wallet error:', error)
      toast.error((error as Error)?.message || 'Failed to backup wallet')
    },
  })
}

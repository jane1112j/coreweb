import type { WalletData } from '@/hooks/useGetAllWallets'
import { sendCommand } from '@metanodejs/system-core'
import { useQuery } from '@tanstack/react-query'

interface UseGetActiveWalletOptions {
  enabled?: boolean
}

export const activeWalletQueryKey = ['activeWallet'] as const

export function useGetActiveWallet({ enabled = true }: UseGetActiveWalletOptions = {}) {
  return useQuery({
    queryKey: activeWalletQueryKey,
    queryFn: async (): Promise<WalletData | null> => {
      try {
        return await sendCommand('getActiveWallet')
      } catch (error) {
        console.error('Failed to load active wallet:', error)
        throw error
      }
    },
    enabled,
    refetchOnWindowFocus: false,
  })
}

import { getAllWallets } from '@metanodejs/system-core'
import { useQuery } from '@tanstack/react-query'

export interface WalletData {
  address: string
  name?: string
}

interface UseGetAllWalletsOptions {
  enabled?: boolean
}

export const allWalletsQueryKey = ['allWallets'] as const

export function useGetAllWallets({ enabled = true }: UseGetAllWalletsOptions = {}) {
  return useQuery({
    queryKey: allWalletsQueryKey,
    queryFn: async (): Promise<WalletData[]> => {
      try {
        return (await getAllWallets()) || []
      } catch (error) {
        console.error('Failed to load wallet list:', error)
        throw error
      }
    },
    enabled,
    refetchOnWindowFocus: false,
  })
}

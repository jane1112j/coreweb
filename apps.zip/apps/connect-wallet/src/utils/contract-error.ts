import { toast } from 'sonner'

/**
 * Known contract error patterns and their user-friendly messages.
 */
const CONTRACT_ERROR_MESSAGES: Record<string, string> = {
  // ... (keep existing messages)
  'not owner': 'Bạn không có quyền thực hiện thao tác này',
  'not agent': 'Tài khoản không phải Agent hợp lệ',
  'not manager': 'Tài khoản không phải Manager',
  unauthorized: 'Không có quyền truy cập',

  // Manager-specific
  'manager already exists': 'Manager đã tồn tại trong hệ thống',
  'manager not found': 'Không tìm thấy Manager',
  'invalid wallet': 'Địa chỉ ví không hợp lệ',

  // Branch-specific
  'branch not found': 'Không tìm thấy chi nhánh',
  'branch not active': 'Chi nhánh đã bị vô hiệu hóa',
  'invalid branch': 'Chi nhánh không hợp lệ',

  // Gas / transaction
  'insufficient funds': 'Số dư không đủ để thực hiện giao dịch',
  'gas required exceeds': 'Phí gas vượt quá giới hạn cho phép',
  'user rejected': 'Giao dịch đã bị từ chối',
  'execution reverted': 'Giao dịch bị từ chối bởi hợp đồng',
}

/**
 * Extracts a human-readable message from a contract/transaction error.
 * Falls back to the original error message if no pattern matches.
 */
export function parseContractError(error: unknown, fallbackMessage?: string): string {
  const err = error as Record<string, unknown>
  const raw = String(err?.message ?? err?.description ?? error)
  const lower = raw.toLowerCase()

  for (const [pattern, message] of Object.entries(CONTRACT_ERROR_MESSAGES)) {
    if (lower.includes(pattern)) return message
  }

  // Try to extract a revert reason from the raw message
  const revertMatch = raw.match(/revert(?:ed)?\s+(?:with reason\s+)?['"](.*?)['"]/i)
  if (revertMatch?.[1]) return revertMatch[1]

  return raw ?? fallbackMessage
}

/**
 * Shows a toast error with a title and a description parsed from the error.
 */
export function showContractError(title: string, error: unknown) {
  const description = parseContractError(error)
  toast.error(title, {
    description: description || 'Failed to perform action',
  })
}

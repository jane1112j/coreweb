export const CUSTOM_SEED_WORD_COUNT = 24

const ASCII_WORD_PATTERN = /^[a-z]+$/

export interface CustomSeedValidation {
  duplicateIndexes: number[]
  filledCount: number
  hasAllWords: boolean
  invalidIndexes: number[]
  isPhraseValid: boolean
}

export interface MergeCustomSeedWordsResult {
  nextFocusIndex: number
  nextWords: string[]
  parsedWords: string[]
  truncated: boolean
}

export const normalizeCustomSeedWord = (value: string) => value.trim().toLowerCase()

export const splitCustomSeedWords = (value: string) =>
  value
    .toLowerCase()
    .split(/[\s,]+/)
    .map((word) => normalizeCustomSeedWord(word))
    .filter(Boolean)

export const createCustomSeedWordsState = (initialWords: string[]) =>
  Array.from({ length: CUSTOM_SEED_WORD_COUNT }, (_, index) =>
    normalizeCustomSeedWord(initialWords[index] || ''),
  )

export const isValidCustomSeedWord = (word: string) => ASCII_WORD_PATTERN.test(word)

export const validateCustomSeedWords = (words: string[]): CustomSeedValidation => {
  const invalidIndexes: number[] = []
  const duplicateIndexes: number[] = []
  const seenWords = new Map<string, number[]>()

  let filledCount = 0

  words.forEach((word, index) => {
    if (!word) return

    filledCount += 1

    if (!isValidCustomSeedWord(word)) {
      invalidIndexes.push(index)
    }

    const existingIndexes = seenWords.get(word) || []
    existingIndexes.push(index)
    seenWords.set(word, existingIndexes)
  })

  seenWords.forEach((indexes) => {
    if (indexes.length > 1) {
      duplicateIndexes.push(...indexes)
    }
  })

  const hasAllWords = filledCount === CUSTOM_SEED_WORD_COUNT
  const isPhraseValid =
    hasAllWords && invalidIndexes.length === 0 && duplicateIndexes.length === 0

  return {
    duplicateIndexes,
    filledCount,
    hasAllWords,
    invalidIndexes,
    isPhraseValid,
  }
}

export const mergeCustomSeedWords = (
  words: string[],
  index: number,
  rawValue: string,
): MergeCustomSeedWordsResult => {
  const parsedWords = splitCustomSeedWords(rawValue)

  if (parsedWords.length === 0) {
    return {
      nextFocusIndex: index,
      nextWords: words,
      parsedWords,
      truncated: false,
    }
  }

  const nextWords = [...words]
  const availableSlots = CUSTOM_SEED_WORD_COUNT - index
  const mergedWords = parsedWords.slice(0, availableSlots)

  mergedWords.forEach((word, offset) => {
    nextWords[index + offset] = word
  })

  return {
    nextFocusIndex: Math.min(index + mergedWords.length, CUSTOM_SEED_WORD_COUNT - 1),
    nextWords,
    parsedWords,
    truncated: parsedWords.length > availableSlots,
  }
}

export function isCoreWeb(): boolean {
  return true
}

export {
  createCustomSeedWordsState,
  CUSTOM_SEED_WORD_COUNT,
  isValidCustomSeedWord,
  mergeCustomSeedWords,
  normalizeCustomSeedWord,
  splitCustomSeedWords,
  validateCustomSeedWords,
} from './custom-seed'
export type { CustomSeedValidation, MergeCustomSeedWordsResult } from './custom-seed'

const ALPHABET = ' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

export const seedPhraseToString = (list: string[]) => {
  const str = list
    .map((word) => {
      const len = word.length
      const char = ALPHABET[len] || '?'
      return `${char}${word}`
    })
    .join('')
  return `Mx3S5${str}`
}

export const convertStringToSeedPhrase = (str: string) => {
  const content = str.substring(5)
  const arr: string[] = []
  let start = 0

  while (arr.length < 24 && start < content.length) {
    const char = content.charAt(start)
    const len = ALPHABET.indexOf(char)

    if (len <= 0) break

    const word = content.substring(start + 1, start + 1 + len)
    arr.push(word)
    start += len + 1
  }
  return arr
}

export const formatBalance = (balanceString: string | number, decimals: number = 15) => {
  if (!balanceString) return '0'
  try {
    const valueStr = balanceString.toString()
    const isNegative = valueStr.startsWith('-')
    const absValueStr = isNegative ? valueStr.slice(1) : valueStr
    const paddedValueStr = absValueStr.padStart(decimals + 1, '0')
    const integerPart = paddedValueStr.slice(0, -decimals)
    const fractionalPart = paddedValueStr.slice(-decimals)
    const formattedInteger = BigInt(integerPart).toLocaleString('en-US')
    const trimmedFractional = fractionalPart.replace(/0+$/, '')

    // optionally limit to max 4-6 decimal places for better UI
    const finalFractional = trimmedFractional.slice(0, 4)

    const result =
      finalFractional.length > 0 ? `${formattedInteger}.${finalFractional}` : formattedInteger
    return isNegative && result !== '0' ? `-${result}` : result
  } catch {
    return '0'
  }
}

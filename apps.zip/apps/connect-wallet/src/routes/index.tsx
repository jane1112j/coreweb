import {
  ConnectWalletPageContent,
  ConnectWalletPageFooter,
  ConnectWalletPageHeader,
  ConnectWalletPageLoading,
  ConnectWalletPageSelectWallet,
  ConnectWalletPageShell,
  type ConnectWalletPageStep,
} from '@/components/wallet/connect-wallet-page'
import { Tabs } from '@/components/ui/tabs'
import { useGetActiveWallet } from '@/hooks/useGetActiveWallet'
import { type WalletData, useGetAllWallets } from '@/hooks/useGetAllWallets'
import { useSetActiveWallet } from '@/hooks/useSetActiveWallet'
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/')({
  component: ConnectWalletPage,
})

interface WalletMutationResult {
  address?: string
  name?: string
}

function ConnectWalletPage() {
  const setActiveWallet = useSetActiveWallet()
  const [step, setStep] = useState<ConnectWalletPageStep | null>(null)
  const isChooseWallet =
    new URLSearchParams(window.location.search).get('isChooseWallet') === 'true'
  const allWalletsQuery = useGetAllWallets()
  const activeWalletQuery = useGetActiveWallet()

  const wallets = allWalletsQuery.data ?? []
  const activeWallet = activeWalletQuery.data ?? null
  const currentStep: 'loading' | ConnectWalletPageStep =
    allWalletsQuery.isLoading || activeWalletQuery.isLoading
    ? 'loading'
    : (step ?? (isChooseWallet && wallets.length > 0 ? 'select-wallet' : 'initial'))

  const handleWalletSuccess = async (wallet?: WalletMutationResult) => {
    try {
      console.log('Wallet saved, refreshing wallet list...', wallet)
      const [{ data: refreshedWallets }] = await Promise.all([
        allWalletsQuery.refetch(),
        activeWalletQuery.refetch(),
      ])
      setStep((refreshedWallets?.length ?? 0) > 0 ? 'select-wallet' : 'initial')
      console.log('Wallet saved successfully:', wallet?.address)
    } catch (error) {
      console.error('Failed to refresh wallet list after wallet mutation:', error)
      setStep('initial')
    }
  }

  const handleSelectWallet = async (wallet: WalletData) => {
    try {
      await setActiveWallet(wallet)
      console.log('Wallet activated:', wallet.address)

      // Optionally notify host to close modal
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'wallet-selected', data: wallet }, '*')
      }
    } catch (error) {
      console.error('Failed to set active wallet:', error)
    }
  }

  return (
    <ConnectWalletPageShell>
      <Tabs
        defaultValue="create"
        className="flex flex-col flex-1 min-h-0 outline-none relative z-10"
      >
        {currentStep === 'loading' && <ConnectWalletPageLoading />}

        {currentStep === 'select-wallet' && (
          <ConnectWalletPageSelectWallet
            wallets={wallets}
            activeWalletAddress={activeWallet?.address || null}
            onSelect={handleSelectWallet}
            onAddNew={() => setStep('initial')}
          />
        )}

        {currentStep === 'initial' && <ConnectWalletPageHeader />}

        {currentStep !== 'loading' && currentStep !== 'select-wallet' && (
          <ConnectWalletPageContent
            currentStep={currentStep}
            onCreateSeed={() => setStep('create-seed')}
            onImportPrivateKey={() => setStep('import-private-key')}
            onImportSeed={() => setStep('import-seed')}
            onReset={() => setStep('initial')}
            onWalletSuccess={handleWalletSuccess}
          />
        )}

        {currentStep === 'initial' && (
          <ConnectWalletPageFooter
            hasWallets={wallets.length > 0}
            onSelectWallet={() => setStep('select-wallet')}
          />
        )}
      </Tabs>
    </ConnectWalletPageShell>
  )
}

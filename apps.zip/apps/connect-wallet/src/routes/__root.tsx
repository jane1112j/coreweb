import { QueryClient } from '@tanstack/react-query'
import { createRootRouteWithContext, Outlet } from '@tanstack/react-router'
import { Toaster } from 'sonner'

interface MyRouterContext {
  queryClient: QueryClient
}

export const Route = createRootRouteWithContext<MyRouterContext>()({
  component: RootComponent,
})

function RootComponent() {
  return (
    <div className="flex h-full min-h-0 w-full flex-col overflow-hidden bg-cyber-black">
      <div className="flex min-h-0 flex-1 flex-col">
        <Outlet />
      </div>
      <Toaster
        position="top-right"
        toastOptions={{
          classNames: {
            toast: window.isHasNotch ? 'mt-12' : 'mt-8',
          },
        }}
        richColors
      />
    </div>
  )
}

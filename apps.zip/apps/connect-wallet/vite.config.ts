import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { TanStackRouterVite } from '@tanstack/router-plugin/vite'
import tailwindcss from '@tailwindcss/vite'
import tsconfigPaths from 'vite-tsconfig-paths'

// https://vite.dev/config/
export default defineConfig({
  base: './',
  envDir: '../../',
  plugins: [TanStackRouterVite(), react(), tailwindcss(), tsconfigPaths()],
  optimizeDeps: {
    exclude: ['@metanodejs/fiai-sdk'],
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
  },
})

# Crypto Vault Module

The **Crypto Vault** is a high-security isolation module designed to manage sensitive cryptographic material within the Metanode ecosystem. It operates as an independent frame, ensuring that private keys and seeds are never exposed to the host application.

## Core Features

- **Zero-Exposure Architecture**: Private keys are stored and used exclusively within the Vault's isolated context.
- **Advanced Encryption**: All sensitive data is encrypted using **AES-256-GCM** with unique per-user keys.
- **Native Persistence**: Utilizes **OPFS (Origin Private File System)** for secure, high-performance local storage.
- **Multi-Factor Security**: Supports both Biometric unlock and master password protection.

## Supported API Actions

| Action            | Description                                                | Parameters                        |
| :---------------- | :--------------------------------------------------------- | :-------------------------------- |
| `getAllWallets`   | Retrieves a list of all non-sensitive wallet metadata.     | None                              |
| `createWallet`    | Generates a new wallet and stores it securely.             | `name`, `backgroundImage`, `seed` |
| `signTransaction` | Signs a transaction using a specific wallet.               | `address`, `txData`               |
| `getSeed`         | Retrieves the recovery seed (Requires biometric/password). | None                              |
| `createHash`      | Generates a Keccak-256 hash.                               | `message`, `isHex`                |

## Technical Implementation

### Communication Layer

Both incoming requests and outgoing events are managed via the [`@metanodejs/fiai-sdk`](https://www.npmjs.com/package/@metanodejs/fiai-sdk), which provides a secure postMessage-based bridge between the host and the frame.

### Storage Layer

The vault uses **Dexie.js** (IndexedDB wrapper) for metadata and **OPFS** for larger encrypted blobs. This ensures data integrity even in browser-intensive environments.

### Security Provider

Every sensitive action triggers a security challenge handled by the `SecurityProvider`. This UI is injected directly into the frame, preventing "Clickjacking" or DOM manipulation from the parent window.

---

_Crafted with 🖤 by **Yuu** & the Metanode Core Team_

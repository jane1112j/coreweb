# Crypto Vault Module

The **Crypto Vault** is a high-security isolation module designed to manage sensitive cryptographic material within the Metanode ecosystem. It operates as an independent frame, ensuring that private keys and seeds are never exposed to the host application.

---

## Core Features

- **Zero-Exposure Architecture**: Private keys are stored and used exclusively within the Vault's isolated context.
- **Advanced Encryption**: All sensitive data is encrypted using **AES-256-GCM** with unique per-user keys.
- **Native Persistence**: Utilizes **IndexedDB** (via Dexie) for secure local storage.
- **Multi-Factor Security**: Supports both Biometric unlock and master password protection.
- **Robust Storage Abstraction**: Dual-storage engine (OPFS + IndexedDB fallback) with automated path resolution.

---

## Clean Architecture Directory Layout

The frame follows strict **Clean Architecture** patterns to achieve modularity, testability, and high-security isolation:

```
frames/crypto-vault/src/
├── core/                         # Configuration and core actions constants
├── modules/                      # Domain-specific functional modules (Wallet, Crypto, System)
│   └── wallet/
│       ├── application/
│       │   ├── events/           # Application events interfaces
│       │   └── use-cases/        # Constructor-injected Use Cases (GetActiveWallet, SetActiveWallet, etc.)
│       ├── domain/               # Domain entities, value objects, and repository interface
│       └── infrastructure/       # Persistence (Dexie) and concrete Adapters
├── shared/                       # Shared Domain and Infrastructure resources
│   ├── domain/
│   │   └── services/             # DOMAIN PORTS: Abstract interfaces (IStorageService, ISeedService)
│   └── infrastructure/
│       ├── persistence/          # VFS Dexie database (file-database.ts)
│       ├── security/             # Security providers and lock UI challenges
│       └── services/             # INFRASTRUCTURE ADAPTERS: Concrete service implementations (StorageService, SeedService)
└── main.ts                       # Application composition root
```

---

## Supported API Actions

### Wallet Management

| Action                       | Description                                                 | Parameters                                 |
| :--------------------------- | :---------------------------------------------------------- | :----------------------------------------- |
| `getAllWallets`              | Retrieves a list of all non-sensitive wallet metadata.      | None                                       |
| `createWallet`               | Generates a new wallet and stores it securely.              | `name`, `backgroundImage`, `seed`          |
| `createWalletFromPrivateKey` | Generates a new wallet from an existing private key.        | `name`, `backgroundImage`, `privateKeyHex` |
| `deleteWallet`               | Removes a wallet from the vault.                            | `address`                                  |
| `updateWalletInfo`           | Updates wallet metadata (name, background image).           | `address`, `name`, `backgroundImage`       |
| `getSeed`                    | Retrieves the recovery seed (Requires biometric/password).  | `lang`                                     |
| `getHiddenWallet`            | Retrieves the hidden/system wallet metadata.                | None                                       |
| `createHiddenWallet`         | Creates a hidden/system wallet securely.                    | `name`, `backgroundImage`                  |
| `getPublicKey`               | Retrieves the public key of a specific wallet.              | `address`, `curve`                         |
| `getPublicWalletInfo`        | Retrieves the public wallet information by address.         | `address`                                  |
| `getPublicKeyFromDb`         | Retrieves a stored public key by address and curve.         | `address`, `curve`                         |
| `setActiveWallet`            | Persists the selected wallet address as active in the VFS.  | `address`                                  |
| `getActiveWallet`            | Returns the active wallet details, or `{ success: false }`. | None                                       |

### Cryptographic Operations

| Action                  | Description                                              | Parameters                              |
| :---------------------- | :------------------------------------------------------- | :-------------------------------------- |
| `signWithWallet`        | Signs data using a specific wallet's key.                | `address`, `data`, `curve`              |
| `createHash`            | Generates a single Keccak-256 hash.                      | `message`, `isHex`                      |
| `createHashes`          | Generates multiple Keccak-256 hashes.                    | `messages`, `isHex`                     |
| `encryptAesECDH`        | Encrypts data using AES-GCM and an ECDH shared secret.   | `publicKey`, `data`                     |
| `decryptAesECDH`        | Decrypts data using AES-GCM and an ECDH shared secret.   | `address`, `publicKey`, `encryptedData` |
| `getEncryptedPublicKey` | Retrieves the public key in an encrypted format.         | `address`                               |
| `createECDHPassword`    | Generates a secure shared password via ECDH.             | `publicKey`                             |
| `encryptAESGCM`         | Encrypts data with standard AES-GCM.                     | `key`, `data`                           |
| `decryptAESGCM`         | Decrypts data with standard AES-GCM.                     | `key`, `encryptedData`                  |
| `initHashSession`       | Initializes a streaming hash session.                    | None                                    |
| `updateHashChunk`       | Appends a chunk array of bytes to the hash session.      | `sessionId`, `chunk`                    |
| `finalizeHashSession`   | Concludes a streaming hash session and returns the hash. | `sessionId`                             |

### System Commands

| Action           | Description                                        | Response                           |
| :--------------- | :------------------------------------------------- | :--------------------------------- |
| `vault:ping`     | Checks connectivity and lock status.               | `{ pong: true, locked: boolean }`  |
| `getVaultStatus` | Gets detailed initialization and security status.  | `{ isLocked, isInitialized, ... }` |
| `lockVault`      | Manually locks the vault and clears keys from RAM. | `{ success: true }`                |

---

## Storage Architecture & Active Wallet Persistence

### The Storage Abstraction (`IStorageService`)

The frame manages local text and binary files (like private keys or configurations) using a specialized storage engine combining **Origin Private File System (OPFS)** and **IndexedDB**.

- **OPFS Engine**: High-performance, native sandbox file storage.
- **Graceful Fallback**: If OPFS is not available or encounters permission constraints (common in cross-origin iframes on Safari/Chrome), the engine automatically falls back to **IndexedDB VFS** (Dexie-powered VFS).
- **OPFS Timeout Isolation**: Features a `Promise.race` timeout handler (capped at 2000ms) to bypass browser hangs when OPFS is blocked, falling back instantly to IndexedDB to keep the UI fluid.

### Active Wallet Flow

The selected active wallet is saved and retrieved seamlessly via:

1. **`SetActiveWalletUseCase`**:
   - Compares the provided address with stored wallets.
   - Triggers `StorageService.writeFile('active_wallet.txt', formattedAddress)` to persist state securely.
   - Emits a broadcast event `setActiveWallet` to sync the main Host UI.
2. **`GetActiveWalletUseCase`**:
   - Calls `StorageService.readFile('active_wallet.txt')`.
   - Parses the content (accepting raw `string`, `Blob`, or `ArrayBuffer` outputs from OPFS/IndexedDB).
   - If not found or if the wallet was deleted, returns `{ success: false }`. Otherwise, returns the formatted, non-sensitive `WalletResponse`.

---

## Streaming Hash Flow

The **Streaming Hash** feature enables highly efficient hashing of large files without loading the entire file into memory. It leverages an isolated stateful session inside the Crypto Vault to process chunks of data sequentially.

### Sequence Flow

```mermaid
sequenceDiagram
    autonumber
    participant Host as Host Application (fiai-sdk)
    participant SDK as FiaiSDK (Bridge)
    participant Vault as Crypto Vault Frame

    Host->>SDK: createFileWithBuffer(file)
    SDK->>Vault: request('initHashSession')
    Note over Vault: Generates sessionId &<br/>allocates memory buffer
    Vault-->>SDK: return { sessionId }

    loop For each chunk (sequential)
        SDK->>SDK: file.slice() & read as ArrayBuffer
        SDK->>Vault: request('updateHashChunk', { sessionId, chunk })
        Note over Vault: Appends chunk to session buffer
        Vault-->>SDK: return void
    end

    SDK->>Vault: request('finalizeHashSession', { sessionId })
    Note over Vault: Performs Keccak-256 hash<br/>& deallocates session
    Vault-->>SDK: return { hash }
    SDK-->>Host: return { hash }
```

### Steps in the Stream Hashing Process

1. **`initHashSession`**: The client initializes a streaming hash session. The Vault assigns a unique, randomly-generated `sessionId` and allocates an empty buffer array for storing chunk bytes.
2. **`updateHashChunk`**: The client reads the target file in sequential chunks (e.g., $1\text{ MB}$ slices) as `ArrayBuffer`s, converts them into byte arrays, and streams them to the Vault using `updateHashChunk`. Each chunk is pushed into the active session's memory buffer.
3. **`finalizeHashSession`**: Once all chunks have been transmitted, the client requests finalization. The Vault aggregates the chunks, computes the ultimate **Keccak-256** hash, frees the session memory, and returns the resulting cryptographic hash to the host.

---

## Technical Implementation

### Communication Layer

Both incoming requests and outgoing events are managed via the [`@metanodejs/fiai-sdk`](https://www.npmjs.com/package/@metanodejs/fiai-sdk), which provides a secure postMessage-based bridge between the host and the frame.

### Security Provider

Every sensitive action triggers a security challenge handled by the `SecurityProvider`. This UI is injected directly into the frame, preventing "Clickjacking" or DOM manipulation from the parent window.

---

_Crafted with 🖤 by the Metanode Core Team_

/**
 * Crypto Vault Frame - Simple Clean Architecture Implementation
 */
import { getBLS, loadBLS } from '@metanodejs/bls-crypto'
import { FrameClient } from '@metanodejs/fiai-sdk'
import { registerSW } from 'virtual:pwa-register'
import englishWords from './assets/seed/en.txt?raw'
// Shared Infrastructure
import { SecurityProvider, SecurityUI } from '@shared/infrastructure/security'
import { seedService } from '@shared/infrastructure/services/seed.service'
// Modules
import { CryptoModule } from '@modules/crypto/crypto.module'
import { SystemModule } from '@modules/system/system.module'
import { WalletModule } from '@modules/wallet/wallet.module'
import { WalletEventProvider } from '@modules/wallet/application/events/wallet-event.provider'
import type { ApplicationActionHandler } from '@metanodejs/fiai-sdk'
// Nạp danh sách từ vựng
seedService.setWordList('en', englishWords)
// Khởi chạy ứng dụng một cách an toàn
async function bootstrap() {
  // 1. Nạp thư viện không đồng bộ BLS trước
  try {
    await loadBLS()
    const bls = getBLS()
    await bls.initBLS()
    bls.init_context()
  } catch (e) {
    console.error('[crypto-vault] Failed to load BLS library:', e)
  }

  // 2. Khởi tạo Shared Infrastructure Layer và các Modules trong môi trường an toàn (DOMContentLoaded)
  try {
    const client = new FrameClient('crypto-vault')
    const securityUI = new SecurityUI(client)
    const securityProvider = new SecurityProvider(securityUI)
    const walletEventProvider = new WalletEventProvider(client)

    // Khởi tạo Modules
    // 1. Module Wallet
    const walletModule = new WalletModule(securityProvider, client, walletEventProvider)
    const walletProvider = walletModule.getWalletProvider()
    // 2. Module Crypto
    const cryptoModule = new CryptoModule(walletProvider)
    // 3. Module System
    const systemModule = new SystemModule(securityProvider)

    // Gom danh sách Handlers từ các Modules
    const handlers: ApplicationActionHandler[] = [
      ...systemModule.getHandlers(),
      ...walletModule.getHandlers(),
      ...cryptoModule.getHandlers(),
    ]

    // 4. Đăng ký các action handlers với FrameClient
    handlers.forEach((handler) => {
      if (!handler || !handler.action) {
        console.warn('[crypto-vault] Found invalid handler:', handler)
        return
      }
      client.handle(handler.action, (params: ApplicationActionHandler) => handler.handle(params))
    })
    void client.ready()
  } catch (e) {
    console.error('[crypto-vault] Critical error during bootstrap:', e)
  }
}
// Lắng nghe sự kiện DOMContentLoaded để khởi chạy ứng dụng
if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', bootstrap)
} else {
  void bootstrap()
}
// Đăng ký Service Worker để hỗ trợ Offline
registerSW({
  onNeedRefresh() {
    console.warn('[crypto-vault] New version available, please refresh.')
  },
  onOfflineReady() {
    console.warn('[crypto-vault] Vault is ready to work offline.')
  },
})

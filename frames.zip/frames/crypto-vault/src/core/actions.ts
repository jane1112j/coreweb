/**
 * Định nghĩa tập trung các action names của Crypto Vault
 */
export const VaultActions = {
  // SYSTEM
  PING: 'vault:ping',
  GET_VAULT_STATUS: 'getVaultStatus',
  LOCK_VAULT: 'lockVault',
  // WALLET
  GET_ALL_WALLETS: 'getAllWallets',
  SET_SETTING_DAPP: 'setSettingDapp',
  GET_SETTING_DAPP: 'getSettingDapp',
  SET_DAPP_SETTINGS: 'setDappSettingsData',
  GET_DAPP_SETTINGS: 'getDappSettingsData',
  SET_ACTIVE_WALLET_DAPP: 'setActiveWalletDapp',
  GET_ACTIVE_WALLET_DAPP: 'getActiveWalletDapp',
  CREATE_WALLET: 'createWallet',
  DELETE_WALLET: 'deleteWallet',
  BACKUP_WALLET: 'backupWallet',
  UPDATE_WALLET_INFO: 'updateWalletInfo',
  GET_SEED: 'getSeed',
  GET_HIDDEN_WALLET: 'getHiddenWallet',
  CREATE_HIDDEN_WALLET: 'createHiddenWallet',
  CREATE_WALLET_FROM_PRIVATE_KEY: 'createWalletFromPrivateKey',
  GET_PUBLIC_KEY: 'getPublicKey',
  GET_PUBLIC_WALLET_INFO: 'getPublicWalletInfo',
  GET_PUBLIC_KEY_FROM_DB: 'getPublicKeyFromDb',
  GET_ENCRYPTED_PUBLIC_KEY: 'getEncryptedPublicKey',
  GET_PRIVATE_KEY: 'getPrivateKey',
  GET_WALLET_BY_ADDRESS: 'getWalletByAddress',

  // HASH
  CREATE_HASH: 'createHash',
  CREATE_HASHES: 'createHashes',
  SIGN_WITH_WALLET: 'signWithWallet',
  ENCRYPT_AES_ECDH: 'encryptAesECDH',
  DECRYPT_AES_ECDH: 'decryptAesECDH',
  CREATE_ECDH_PASSWORD: 'createECDHPassword',
  ENCRYPT_AES_GCM: 'encryptAESGCM',
  DECRYPT_AES_GCM: 'decryptAESGCM',
  INIT_HASH_SESSION: 'initHashSession',
  UPDATE_HASH_CHUNK: 'updateHashChunk',
  FINALIZE_HASH_SESSION: 'finalizeHashSession',
  HASH_FILE: 'hashFile',
  DECODE_ABI: 'decodeAbi',
  CREATE_SIGN: 'createSign',
} as const

export interface CreateSignParams {
  address: string
  message: string
  isHex: boolean
}

export function createSign(params: CreateSignParams) {
  return {
    action: VaultActions.CREATE_SIGN,
    payload: params,
  }
}


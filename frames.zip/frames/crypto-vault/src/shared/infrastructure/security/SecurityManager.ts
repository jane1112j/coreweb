import { cryptoUtils } from '@metanodejs/fiai-sdk'

/**
 * SecurityManager - Chuyên trách quản lý khóa Master và bảo mật phiên (Vault Version)
 * Hỗ trợ xác thực kép: Sinh trắc học (WebAuthn PRF) và Mật khẩu (PBKDF2)
 */

// ─── Interfaces ──────────────────────────────────────────────────────────────

export type SecurityEvent = 'lock' | 'unlock' | 'activity' | 'error'
export type AuthMode = 'biometric' | 'password' | 'none'

export interface SecurityAuditLog {
  timestamp: number
  event: SecurityEvent
  details?: string
}

// ─── Internal Implementation ──────────────────────────────────────────────────

/**
 * Mutex đơn giản để tránh race condition khi gọi WebAuthn hoặc UI
 */
class SimpleMutex {
  private promise: Promise<void> = Promise.resolve()

  async acquire(): Promise<() => void> {
    let release: () => void
    const nextPromise = new Promise<void>((resolve) => {
      release = resolve
    })
    const currentPromise = this.promise
    this.promise = currentPromise.then(() => nextPromise)
    await currentPromise
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return release!
  }
}

/**
 * Quản lý lưu trữ metadata an toàn bằng IndexedDB
 */
class SecureStorage {
  private readonly dbName = 'fiai_security_vault'
  private readonly storeName = 'metadata'

  private async getDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1)
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(this.storeName)) {
          request.result.createObjectStore(this.storeName)
        }
      }
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  }

  async getItem<T>(key: string): Promise<T | null> {
    const db = await this.getDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(this.storeName, 'readonly')
      const request = transaction.objectStore(this.storeName).get(key)
      request.onsuccess = () => resolve(request.result || null)
      request.onerror = () => reject(request.error)
    })
  }

  async setItem<T>(key: string, value: T): Promise<void> {
    const db = await this.getDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(this.storeName, 'readwrite')
      transaction.objectStore(this.storeName).put(value, key)
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => reject(transaction.error)
    })
  }

  async removeItem(key: string): Promise<void> {
    const db = await this.getDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(this.storeName, 'readwrite')
      transaction.objectStore(this.storeName).delete(key)
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => reject(transaction.error)
    })
  }
}

/**
 * Quản lý xác thực bằng Password sử dụng PBKDF2
 */
class PasswordProvider {
  private readonly CHECK_VALUE = 'METANODE_VAULT_AUTH_CHECK'

  constructor(private storage: SecureStorage) {}

  async setup(password: string): Promise<CryptoKey> {
    const salt = cryptoUtils.generateSalt()
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    const key = await cryptoUtils.deriveKeyFromPassword(password, salt as BufferSource)

    // Tạo Validation Tag để kiểm tra mật khẩu sau này
    const validationData = new TextEncoder().encode(this.CHECK_VALUE)
    const iv = crypto.getRandomValues(new Uint8Array(12))
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, validationData)

    await this.storage.setItem('password_salt', salt)
    await this.storage.setItem('password_check', { iv, data: new Uint8Array(encrypted) })

    return key
  }

  async authenticate(password: string): Promise<CryptoKey> {
    const salt = await this.storage.getItem<Uint8Array>('password_salt')
    const check = await this.storage.getItem<{ iv: Uint8Array; data: Uint8Array }>('password_check')

    if (!salt || !check) throw new Error('Chưa thiết lập mật khẩu')

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    const key = await cryptoUtils.deriveKeyFromPassword(password, salt as BufferSource)

    try {
      // Thử giải mã Validation Tag
      const decrypted = await crypto.subtle.decrypt(
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        { name: 'AES-GCM', iv: check.iv as any },
        key,
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        check.data as any,
      )

      const value = new TextDecoder().decode(decrypted)
      if (value !== this.CHECK_VALUE) throw new Error('Mật khẩu sai')

      return key
    } catch (err) {
      console.error('Xác thực thất bại:', err)
      throw new Error('Incorrect password', { cause: err })
    }
  }

  async hasPassword(): Promise<boolean> {
    const salt = await this.storage.getItem('password_salt')
    return !!salt
  }
}

/**
 * Quản lý WebAuthn & PRF Extension
 */
class WebAuthnProvider {
  private readonly RP_NAME = 'Metanode Vault'
  private readonly PRF_SALT = new Uint8Array(32).fill(0x42)

  async isAvailable(): Promise<boolean> {
    return (
      !!window.PublicKeyCredential &&
      (await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())
    )
  }

  async register(username: string): Promise<{ credentialId: Uint8Array; prfKey: CryptoKey }> {
    const challenge = crypto.getRandomValues(new Uint8Array(32))
    const userHandle = crypto.getRandomValues(new Uint8Array(32))

    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: this.RP_NAME, id: window.location.hostname },
        user: {
          id: userHandle,
          name: username,
          displayName: username,
        },
        pubKeyCredParams: [
          { alg: -7, type: 'public-key' }, // ES256 (ECDSA with SHA-256)
          { alg: -257, type: 'public-key' }, // RS256 (RSASSA-PKCS1-v1_5 with SHA-256)
        ],
        authenticatorSelection: {
          userVerification: 'required',
          residentKey: 'required',
        },
        extensions: {
          prf: { eval: { first: this.PRF_SALT } },
        },
      },
    })) as PublicKeyCredential

    if (!credential) throw new Error('WebAuthn Registration Failed')

    const results = credential.getClientExtensionResults()
    const seed = (results as any).prf?.results?.first

    if (!seed) throw new Error('Thiết bị không hỗ trợ PRF (Biometric Key Derivation)')

    const prfKey = await this.deriveMasterKey(seed)
    return { credentialId: new Uint8Array(credential.rawId), prfKey }
  }

  async authenticate(credentialId: Uint8Array): Promise<CryptoKey> {
    const challenge = crypto.getRandomValues(new Uint8Array(32))

    const credential = (await navigator.credentials.get({
      publicKey: {
        challenge,
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        allowCredentials: [{ id: credentialId as BufferSource, type: 'public-key' }],
        userVerification: 'required',
        extensions: {
          prf: { eval: { first: this.PRF_SALT } },
        },
      },
    })) as PublicKeyCredential

    if (!credential) throw new Error('WebAuthn Authentication Failed')

    const results = credential.getClientExtensionResults()
    const seed = (results as any).prf?.results?.first
    if (!seed) throw new Error('PRF output missing')

    return this.deriveMasterKey(seed)
  }

  private async deriveMasterKey(seed: ArrayBuffer): Promise<CryptoKey> {
    const baseKey = await crypto.subtle.importKey('raw', seed, 'HKDF', false, ['deriveKey'])

    return crypto.subtle.deriveKey(
      {
        name: 'HKDF',
        salt: new Uint8Array(16).fill(0),
        info: new TextEncoder().encode('metanode-vault-master-key-v1'),
        hash: 'SHA-256',
      },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      false, // non-extractable
      ['encrypt', 'decrypt'],
    )
  }
}

// ─── Main Class ──────────────────────────────────────────────────────────────

export class SecurityManager {
  private masterKey: CryptoKey | null = null
  private lastActivity: number = Date.now()
  private readonly mutex = new SimpleMutex()
  private readonly storage = new SecureStorage()
  private readonly webauthn = new WebAuthnProvider()
  private readonly password = new PasswordProvider(this.storage)

  private readonly SESSION_TIMEOUT = 15 * 60 * 1000 // 15 mins

  constructor() {
    this.updateActivity()
  }

  public getMasterKey(): CryptoKey | null {
    if (this.isLocked()) return null
    this.updateActivity()
    return this.masterKey
  }

  public setMasterKey(key: CryptoKey): void {
    this.masterKey = key
    this.updateActivity()
  }

  public isLocked(): boolean {
    if (!this.masterKey) return true
    const now = Date.now()
    if (now - this.lastActivity > this.SESSION_TIMEOUT) {
      this.lock()
      return true
    }
    return false
  }

  public updateActivity(): void {
    this.lastActivity = Date.now()
  }

  public lock(): void {
    this.masterKey = null
    this.lastActivity = 0
  }

  /**
   * Trả về phương thức bảo mật đã đăng ký
   */
  public async getAuthMode(): Promise<AuthMode> {
    return (await this.storage.getItem<AuthMode>('auth_mode')) || 'none'
  }

  /**
   * Đăng ký phương thức bảo mật lần đầu
   */
  public async setupSecurity(mode: AuthMode, secret?: string): Promise<CryptoKey> {
    const release = await this.mutex.acquire()
    try {
      let key: CryptoKey
      if (mode === 'biometric') {
        const { credentialId, prfKey } = await this.webauthn.register('user@metanode')
        await this.storage.setItem('credential_id', credentialId)
        key = prfKey
      } else if (mode === 'password') {
        if (!secret) throw new Error('Mật khẩu là bắt buộc')
        key = await this.password.setup(secret)
      } else {
        throw new Error('Chế độ bảo mật không hợp lệ')
      }

      await this.storage.setItem('auth_mode', mode)
      this.masterKey = key
      this.updateActivity()
      return key
    } finally {
      release()
    }
  }

  /**
   * Mở khóa bằng Password
   */
  public async unlockWithPassword(pwd: string): Promise<CryptoKey> {
    const key = await this.password.authenticate(pwd)
    this.masterKey = key
    this.updateActivity()
    return key
  }

  public async unlockWithBiometric(): Promise<CryptoKey> {
    const credentialId = await this.storage.getItem<Uint8Array>('credential_id')
    if (!credentialId) throw new Error('Chưa đăng ký vân tay')

    const key = await this.webauthn.authenticate(credentialId)
    this.masterKey = key
    this.updateActivity()
    await this.clearBiometricFailures()
    return key
  }

  /**
   * Kiểm tra xem thiết bị có hỗ trợ vân tay không
   */
  public async isBiometricAvailable(): Promise<boolean> {
    return await this.webauthn.isAvailable()
  }

  /**
   * Ghi nhận và đếm số lần quét vân tay lỗi trong vòng 5 phút
   */
  public async recordBiometricFailure(): Promise<number> {
    const now = Date.now()
    const fiveMinutes = 5 * 60 * 1000
    const history = (await this.storage.getItem<number[]>('biometric_failures')) || []

    // Lọc bỏ lỗi đã quá 5 phút
    const activeFailures = history.filter((t) => now - t <= fiveMinutes)
    activeFailures.push(now)

    await this.storage.setItem('biometric_failures', activeFailures)
    return activeFailures.length
  }

  /**
   * Xóa sạch lịch sử quét vân tay lỗi (Khi quét thành công)
   */
  public async clearBiometricFailures(): Promise<void> {
    await this.storage.removeItem('biometric_failures')
  }

  /**
   * Reset cấu hình bảo mật ví hoàn toàn (Khôi phục ví)
   */
  public async resetSecurity(): Promise<void> {
    await this.storage.removeItem('auth_mode')
    await this.storage.removeItem('credential_id')
    await this.storage.removeItem('password_salt')
    await this.storage.removeItem('password_check')
    await this.storage.removeItem('biometric_failures')
    this.lock()
  }
}

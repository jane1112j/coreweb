import './SecurityUI.css'
import { SECURITY_COPY, type SecurityDictionary, type SupportedLocale } from './security.i18n'

export class SecurityUI {
  private overlay: HTMLDivElement | null = null
  private pendingOverlay: HTMLDivElement | null = null
  private destroyTimer: ReturnType<typeof setTimeout> | null = null
  private locale: SupportedLocale = 'vi'

  constructor(private client?: any) {}

  private readonly UNLOCK_CANCELLED_ERROR = 'UNLOCK_CANCELLED'

  private async syncLocale(): Promise<SupportedLocale> {
    try {
      const response = (await this.client?.call?.('getDappSettings', {})) as
        | { language?: string }
        | undefined
      if (response?.language === 'vi' || response?.language === 'en') {
        this.locale = response.language
      }
    } catch (error) {
      console.warn('[SecurityUI] Failed to load language, fallback to current locale:', error)
    }

    return this.locale
  }

  private get copy(): SecurityDictionary {
    return SECURITY_COPY[this.locale]
  }

  private translateIncomingError(message?: string): string | undefined {
    if (!message) return undefined

    if (message === 'Incorrect password. Please try again.') {
      return this.copy.password.incorrectPassword
    }

    return message
  }

  public async showSetup(
    biometricAvailable: boolean,
  ): Promise<{ mode: 'password' | 'biometric'; password?: string }> {
    this.client?.showUI()
    return new Promise((resolve) => {
      this.createOverlay()

      const renderMenu = async () => {
        await this.syncLocale()
        const copy = this.copy
        const content = `
          <div class="security-modal">
            <div class="security-header">
              <div class="icon-wrapper">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
              </div>
              <h2>${copy.setup.title}</h2>
              <p>${copy.setup.subtitle}</p>
            </div>
            <div class="options-list">
              ${
                biometricAvailable
                  ? `
                <div class="option-item" id="btn-biometric">
                  <div class="option-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-fingerprint-pattern-icon lucide-fingerprint-pattern"><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/><path d="M2 12a10 10 0 0 1 18-6"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M9 6.8a6 6 0 0 1 9 5.2v2"/></svg>
                  </div>
                  <div class="option-info">
                    <h3>${copy.setup.biometricTitle}</h3>
                    <p>${copy.setup.biometricSubtitle}</p>
                  </div>
                </div>
              `
                  : ''
              }
              <div class="option-item" id="btn-password">
                <div class="option-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                </div>
                <div class="option-info">
                  <h3>${copy.setup.passwordTitle}</h3>
                  <p>${copy.setup.passwordSubtitle}</p>
                </div>
              </div>
            </div>
          </div>
        `
        this.render(content)

        if (biometricAvailable) {
          document.getElementById('btn-biometric')?.addEventListener('click', () => {
            this.destroy()
            resolve({ mode: 'biometric' })
          })
        }

        document.getElementById('btn-password')?.addEventListener('click', async () => {
          const result = await this.showPasswordForm(true)
          if (result.back) {
            void renderMenu()
          } else {
            this.destroy()
            resolve({ mode: 'password', password: result.password })
          }
        })
      }

      void renderMenu()
    })
  }

  public async showUnlockPassword(error?: string): Promise<string> {
    this.client?.showUI()
    return new Promise((resolve, reject) => {
      this.createOverlay()
      void this.showPasswordForm(false, error).then((res) => {
        if (res.cancelled) {
          reject(new Error(this.UNLOCK_CANCELLED_ERROR))
          return
        }

        if (typeof res.password === 'string') {
          resolve(res.password)
          return
        }

        reject(new Error(this.UNLOCK_CANCELLED_ERROR))
      })
    })
  }

  public showError(message: string) {
    const errorMsg = document.getElementById('error-msg')
    if (errorMsg) {
      errorMsg.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-fingerprint-pattern-icon lucide-fingerprint-pattern"><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/><path d="M2 12a10 10 0 0 1 18-6"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M9 6.8a6 6 0 0 1 9 5.2v2"/></svg>
        <span>${message}</span>
      `
      errorMsg.classList.remove('hidden')

      // Trigger macOS-style shake animation on the modal container
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
      const modal = errorMsg.closest('.security-modal') as HTMLElement | null
      if (modal) {
        modal.classList.remove('animate-shake')
        void modal.offsetWidth // Force reflow
        modal.classList.add('animate-shake')
      }

      const input = document.getElementById('pwd-input') as HTMLInputElement
      if (input) {
        input.value = ''
        input.focus()
      }
    }
  }

  private async showPasswordForm(
    isSetup: boolean,
    error?: string,
  ): Promise<{ password?: string; back?: boolean; cancelled?: boolean }> {
    return new Promise((resolve) => {
      void (async () => {
        await this.syncLocale()
        const copy = this.copy
        const translatedError = this.translateIncomingError(error)

        const content = `
        <div class="security-modal">
          <div class="security-header">
            <div class="icon-wrapper">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
            </div>
            <h2>${isSetup ? copy.password.createTitle : copy.password.accessTitle}</h2>
            <p>${isSetup ? copy.password.createSubtitle : copy.password.accessSubtitle}</p>
          </div>
          <form id="pwd-form" class="pwd-form">
            <div class="input-group">
              <input type="password" id="pwd-input" placeholder="${copy.password.passwordPlaceholder}" required autofocus />
            </div>
            ${
              isSetup
                ? `
              <div class="input-group">
                <input type="password" id="pwd-confirm" placeholder="${copy.password.confirmPlaceholder}" required />
              </div>
            `
                : ''
            }
            <div id="error-msg" class="error-msg ${translatedError ? '' : 'hidden'}">
              ${
                translatedError
                  ? `
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0;"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                <span>${translatedError}</span>
              `
                  : ''
              }
            </div>
            <button type="submit" class="submit-btn" id="submit-btn">
              ${isSetup ? copy.password.setupButton : copy.password.unlockButton}
            </button>
          </form>
          <button class="back-link" id="btn-back">${copy.password.backToHome}</button>
        </div>
      `
        this.render(content)

        const form = document.getElementById('pwd-form') as HTMLFormElement
        const input = document.getElementById('pwd-input') as HTMLInputElement
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
        const errorMsg = document.getElementById('error-msg')!

        if (translatedError) {
          input.classList.add('error')
          // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
          const modal = errorMsg.closest('.security-modal') as HTMLElement | null
          if (modal) {
            modal.classList.remove('animate-shake')
            void modal.offsetWidth // Force reflow
            modal.classList.add('animate-shake')
          }
        }

        document.getElementById('btn-back')?.addEventListener('click', () => {
          if (isSetup) {
            resolve({ back: true })
          } else {
            this.destroy()
            resolve({ cancelled: true })
          }
        })

        form.addEventListener('submit', (e) => {
          e.preventDefault()
          const pwd = input.value
          const confirmInput = document.getElementById('pwd-confirm') as HTMLInputElement | null
          const submitBtn = document.getElementById('submit-btn') as HTMLButtonElement | null

          // Reset previous errors
          input.classList.remove('error')
          if (confirmInput) {
            confirmInput.classList.remove('error')
          }
          errorMsg.classList.add('hidden')

          // Validate password confirmation (setup only)
          if (isSetup && pwd !== confirmInput?.value) {
            errorMsg.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0;"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
            <span>${copy.password.mismatchError}</span>
          `
            errorMsg.classList.remove('hidden')
            input.classList.add('error')
            if (confirmInput) {
              confirmInput.classList.add('error')
              confirmInput.value = ''
            }

            // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
            const modal = errorMsg.closest('.security-modal') as HTMLElement | null
            if (modal) {
              modal.classList.remove('animate-shake')
              void modal.offsetWidth // Force reflow
              modal.classList.add('animate-shake')
            }
            return
          }

          // Prevent double-submit while PBKDF2 / unlock is running
          if (submitBtn) {
            submitBtn.disabled = true
            submitBtn.style.opacity = '0.7'
            submitBtn.style.cursor = 'wait'
          }
          input.disabled = true
          if (confirmInput) confirmInput.disabled = true

          resolve({ password: pwd })
        })
      })()
    })
  }

  private createOverlay() {
    // Cancel pending destroy and remove the fading-out node immediately
    if (this.destroyTimer) {
      clearTimeout(this.destroyTimer)
      this.destroyTimer = null
    }
    if (this.pendingOverlay) {
      this.pendingOverlay.remove()
      this.pendingOverlay = null
    }

    document.body.classList.add('security-active')

    // Hide main app content if it exists
    const app = document.getElementById('app')
    if (app) {
      app.style.display = 'none'
    }

    if (this.overlay) {
      // Re-activate if destroy() removed `.active` but DOM node is still present
      if (!this.overlay.classList.contains('active')) {
        void this.overlay.offsetWidth
        this.overlay.classList.add('active')
      }
      return
    }

    this.overlay = document.createElement('div')
    this.overlay.className = 'security-overlay'
    document.body.appendChild(this.overlay)

    // Force reflow and add active class for smooth entry transition
    void this.overlay.offsetWidth
    this.overlay.classList.add('active')
  }

  private render(html: string) {
    if (this.overlay) this.overlay.innerHTML = html
  }

  public async showRescueUI(): Promise<'RESCUE_SINGLE' | 'RESET_ALL' | 'CANCEL'> {
    this.client?.showUI()
    return new Promise((resolve) => {
      this.createOverlay()

      void (async () => {
        await this.syncLocale()
        const copy = this.copy
        const content = `
        <div class="security-modal security-rescue-modal" style="max-width: 440px; padding: 40px 36px;">
          <div class="security-header" style="margin-bottom: 28px;">
            <div class="icon-wrapper alert-icon-wrapper animate-pulse">
              <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
            </div>
            <h2 style="color: rgb(239, 68, 68); font-size: 22px; font-weight: 700; margin-bottom: 12px; letter-spacing: -0.5px;">${copy.rescue.title}</h2>
            <p style="font-size: 14.5px; line-height: 1.5; color: var(--text-secondary); margin: 0;">
              ${copy.rescue.subtitle}
            </p>
          </div>

          <div style="border: 1px solid rgba(239, 68, 68, 0.25); background: rgba(239, 68, 68, 0.03); padding: 18px; border-radius: 18px; display: flex; flex-direction: column; gap: 14px; margin-bottom: 24px; position: relative; z-index: 1;">
            <p style="font-size: 13.5px; color: #f87171; text-align: left; margin: 0; line-height: 1.5; font-weight: 500;">
              ⚠️ ${copy.rescue.warning}
            </p>
            
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <label for="confirm-delete-input" style="font-size: 12px; color: var(--text-secondary); text-align: left; font-weight: 500;">
                ${copy.rescue.confirmLabel}
              </label>
              <input type="text" id="confirm-delete-input" placeholder="${copy.rescue.confirmPlaceholder}" autocomplete="off" style="width: 100%; padding: 12px 14px; background: rgba(0,0,0,0.25); border: 1px solid rgba(239, 68, 68, 0.35); border-radius: 12px; color: #ffffff; outline: none; font-size: 14px; font-weight: bold; text-align: center; transition: border-color 0.2s;" />
            </div>

            <button id="btn-confirm-destruction" disabled class="submit-btn" style="background: rgb(239, 68, 68); opacity: 0.5; cursor: not-allowed; margin-top: 4px; padding: 16px; font-size: 14.5px; box-shadow: 0 4px 16px rgba(239, 68, 68, 0.2); font-weight: 700;">
              ${copy.rescue.resetButton}
            </button>
          </div>

          <div class="action-buttons" style="display: flex; flex-direction: column; width: 100%;">
            <button class="back-link" id="btn-cancel-rescue" style="margin-top: 0; align-self: center;">${copy.rescue.cancel}</button>
          </div>
        </div>
      `
        this.render(content)

        const confirmInput = document.getElementById('confirm-delete-input') as HTMLInputElement
        const btnConfirmDestruction = document.getElementById(
          'btn-confirm-destruction',
        ) as HTMLButtonElement

        confirmInput?.focus()

        confirmInput?.addEventListener('input', (e: any) => {
          const text = e.target.value
          if (text === copy.rescue.confirmPhrase) {
            btnConfirmDestruction.disabled = false
            btnConfirmDestruction.style.opacity = '1'
            btnConfirmDestruction.style.cursor = 'pointer'
            confirmInput.style.borderColor = 'rgb(239, 68, 68)'
          } else {
            btnConfirmDestruction.disabled = true
            btnConfirmDestruction.style.opacity = '0.5'
            btnConfirmDestruction.style.cursor = 'not-allowed'
            confirmInput.style.borderColor = 'rgba(239, 68, 68, 0.35)'
          }
        })

        btnConfirmDestruction?.addEventListener('click', () => {
          if (confirmInput.value === copy.rescue.confirmPhrase) {
            this.destroy()
            resolve('RESET_ALL')
          }
        })

        document.getElementById('btn-cancel-rescue')?.addEventListener('click', () => {
          this.destroy()
          resolve('CANCEL')
        })
      })()
    })
  }

  public destroy() {
    if (this.destroyTimer) {
      clearTimeout(this.destroyTimer)
      this.destroyTimer = null
    }
    if (this.pendingOverlay) {
      this.pendingOverlay.remove()
      this.pendingOverlay = null
    }

    // Always hide host iframe — even if overlay was already cleared
    this.client?.hideUI()
    document.body.classList.remove('security-active')

    // Restore main app content if it exists
    const app = document.getElementById('app')
    if (app) {
      app.style.display = ''
    }

    if (!this.overlay) return

    const overlay = this.overlay
    overlay.classList.remove('active')
    // Null immediately so createOverlay() can recreate safely during the fade-out
    this.overlay = null
    this.pendingOverlay = overlay
    this.destroyTimer = setTimeout(() => {
      overlay.remove()
      if (this.pendingOverlay === overlay) {
        this.pendingOverlay = null
      }
      this.destroyTimer = null
    }, 300)
  }
}

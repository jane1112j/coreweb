import { SecurityManager } from './SecurityManager'
import type { SecurityUI } from './SecurityUI'

const UNLOCK_CANCELLED_ERROR = 'UNLOCK_CANCELLED'

export class SecurityProvider {
  private security = new SecurityManager()
  private activeUnlockPromise: Promise<CryptoKey> | null = null

  constructor(private readonly ui: SecurityUI) {}

  public getSecurity() {
    return this.security
  }

  /**
   * Đảm bảo có Master Key (từ session bộ nhớ Vault)
   */
  public ensureMasterKey(
    _params: {
      masterKey?: string | CryptoKey
    } = {},
  ): CryptoKey | null {
    // 1. Kiểm tra bộ nhớ tạm (Session)
    const masterKey = this.security.getMasterKey()
    if (masterKey) return masterKey

    // 2. Nếu không có, không còn chấp nhận key từ Host gửi qua (Zero Trust)
    // Trả về null để UseCase gọi unlock() nếu cần
    return null
  }

  /**
   * Mở khóa Vault bằng UI (Password hoặc Biometric)
   */
  public async unlock(): Promise<CryptoKey> {
    if (this.activeUnlockPromise) {
      return this.activeUnlockPromise
    }

    const masterKey = this.security.getMasterKey()
    if (masterKey) return masterKey

    this.activeUnlockPromise = (async () => {
      try {
        // 1. Kiểm tra mode hiện tại
        const mode = await this.security.getAuthMode()

        // 2. Nếu chưa thiết lập bảo mật (Lần đầu)
        if (mode === 'none') {
          const biometricAvailable = await this.security.isBiometricAvailable()
          const result = await this.ui.showSetup(biometricAvailable)

          return await this.security.setupSecurity(result.mode, result.password)
        }

        // 3. Nếu đã thiết lập: Xác thực
        if (mode === 'biometric') {
          try {
            return await this.security.unlockWithBiometric()
          } catch (err) {
            const failCount = await this.security.recordBiometricFailure()
            if (failCount >= 3) {
              console.warn('Biometric failed 3 times. Prompting Seed Phrase Rescue UI.')
              const rescueAction = await this.ui.showRescueUI()
              if (rescueAction === 'RESET_ALL') {
                await this.security.resetSecurity()
                throw new Error('RESCUE_BY_SEED_PHRASE_RESET_ALL', { cause: err })
              }
            }
            throw err
          }
        } else {
          // Password mode - Retry Loop
          let lastError: string | undefined = undefined
          while (true) {
            try {
              const password = await this.ui.showUnlockPassword(lastError)
              const key = await this.security.unlockWithPassword(password)

              // Thành công -> Đóng UI và trả về key
              this.ui.destroy()
              return key
            } catch (err: any) {
              if (err instanceof Error && err.message === UNLOCK_CANCELLED_ERROR) {
                throw err
              }

              console.error('Unlock failed:', err)
              lastError = 'Incorrect password. Please try again.'
              // Vòng lặp tiếp tục, showUnlockPassword sẽ nhận lastError và hiển thị
            }
          }
        }
      } finally {
        this.activeUnlockPromise = null
      }
    })()

    return this.activeUnlockPromise
  }

  /**
   * Bắt buộc xác thực bằng password, bỏ qua session unlock trước đó.
   */
  public async unlockWithPassword(): Promise<CryptoKey> {
    if (this.activeUnlockPromise) {
      return this.activeUnlockPromise
    }

    this.activeUnlockPromise = (async () => {
      try {
        const mode = await this.security.getAuthMode()

        if (mode === 'none') {
          throw new Error('Vault password is not configured')
        }

        if (mode !== 'password') {
          throw new Error('Backup wallet requires password authentication')
        }

        let lastError: string | undefined = undefined
        while (true) {
          try {
            const password = await this.ui.showUnlockPassword(lastError)
            const key = await this.security.unlockWithPassword(password)
            this.ui.destroy()
            return key
          } catch (err: any) {
            if (err instanceof Error && err.message === UNLOCK_CANCELLED_ERROR) {
              throw err
            }

            console.error('Password unlock failed:', err)
            lastError = 'Incorrect password. Please try again.'
          }
        }
      } finally {
        this.activeUnlockPromise = null
      }
    })()

    return this.activeUnlockPromise
  }

  /**
   * Bắt buộc người dùng xác thực lại (để làm tác vụ nhạy cảm như Backup),
   * tự động sử dụng Biometric hoặc Password tuỳ cấu hình hiện tại.
   */
  public async forceUnlock(): Promise<CryptoKey> {
    if (this.activeUnlockPromise) {
      return this.activeUnlockPromise
    }

    this.activeUnlockPromise = (async () => {
      try {
        const mode = await this.security.getAuthMode()

        if (mode === 'none') {
          throw new Error('Vault is not configured')
        }

        if (mode === 'biometric') {
          try {
            return await this.security.unlockWithBiometric()
          } catch (err) {
            const failCount = await this.security.recordBiometricFailure()
            if (failCount >= 3) {
              console.warn('Biometric failed 3 times. Prompting Seed Phrase Rescue UI.')
              const rescueAction = await this.ui.showRescueUI()
              if (rescueAction === 'RESET_ALL') {
                await this.security.resetSecurity()
                throw new Error('RESCUE_BY_SEED_PHRASE_RESET_ALL', { cause: err })
              }
            }
            throw err
          }
        } else {
          // Password mode - Yêu cầu nhập mật khẩu
          let lastError: string | undefined = undefined
          while (true) {
            try {
              const password = await this.ui.showUnlockPassword(lastError)
              const key = await this.security.unlockWithPassword(password)
              this.ui.destroy()
              return key
            } catch (err: any) {
              if (err instanceof Error && err.message === UNLOCK_CANCELLED_ERROR) {
                throw err
              }

              console.error('Password unlock failed:', err)
              lastError = 'Incorrect password. Please try again.'
            }
          }
        }
      } finally {
        this.activeUnlockPromise = null
      }
    })()

    return this.activeUnlockPromise
  }

  public isLocked(): boolean {
    return this.security.isLocked()
  }
}

export type SupportedLocale = 'vi' | 'en'

export type SecurityDictionary = {
  setup: {
    title: string
    subtitle: string
    biometricTitle: string
    biometricSubtitle: string
    passwordTitle: string
    passwordSubtitle: string
  }
  password: {
    createTitle: string
    createSubtitle: string
    accessTitle: string
    accessSubtitle: string
    passwordPlaceholder: string
    confirmPlaceholder: string
    setupButton: string
    unlockButton: string
    backToHome: string
    minLengthError: string
    mismatchError: string
    incorrectPassword: string
  }
  rescue: {
    title: string
    subtitle: string
    warning: string
    confirmLabel: string
    confirmPlaceholder: string
    resetButton: string
    cancel: string
    confirmPhrase: string
  }
}

export const SECURITY_COPY: Record<SupportedLocale, SecurityDictionary> = {
  en: {
    setup: {
      title: 'Security Setup',
      subtitle: 'Select a method to secure your vault enclave.',
      biometricTitle: 'Biometric',
      biometricSubtitle: 'Fingerprint or Face Recognition',
      passwordTitle: 'Password',
      passwordSubtitle: 'Traditional encrypted passphrase',
    },
    password: {
      createTitle: 'Create Password',
      createSubtitle: 'Define a strong password for your enclave.',
      accessTitle: 'Vault Access',
      accessSubtitle: 'Enter your password to unlock assets.',
      passwordPlaceholder: 'Password',
      confirmPlaceholder: 'Confirm Password',
      setupButton: 'Setup Enclave',
      unlockButton: 'Unlock Vault',
      backToHome: 'Return to Home',
      minLengthError: 'Password must be at least 8 characters long',
      mismatchError: 'Passwords do not match',
      incorrectPassword: 'Incorrect password. Please try again.',
    },
    rescue: {
      title: 'Security Alert',
      subtitle: 'Biometric verification failed 3 consecutive times in the last 5 minutes.',
      warning:
        'CRITICAL WARNING: A Hard Reset is required to unlock the enclave. This will permanently erase all wallets stored on this device. Make sure you have your Seed Phrases backed up.',
      confirmLabel: 'Type DELETE ALL below to confirm destruction:',
      confirmPlaceholder: 'DELETE ALL',
      resetButton: 'Hard Reset & Clear All Wallets',
      cancel: 'Cancel',
      confirmPhrase: 'DELETE ALL',
    },
  },
  vi: {
    setup: {
      title: 'Thiết lập bảo mật',
      subtitle: 'Chọn phương thức để bảo vệ khoá bảo mật của bạn.',
      biometricTitle: 'Sinh trắc học',
      biometricSubtitle: 'Vân tay hoặc nhận diện khuôn mặt',
      passwordTitle: 'Mật khẩu',
      passwordSubtitle: 'Cụm mật khẩu mã hoá truyền thống',
    },
    password: {
      createTitle: 'Tạo mật khẩu',
      createSubtitle: 'Đặt một mật khẩu mạnh cho vùng bảo mật của bạn.',
      accessTitle: 'Truy cập khoá',
      accessSubtitle: 'Nhập mật khẩu để mở khoá tài sản.',
      passwordPlaceholder: 'Mật khẩu',
      confirmPlaceholder: 'Xác nhận mật khẩu',
      setupButton: 'Thiết lập vùng bảo mật',
      unlockButton: 'Mở khoá',
      backToHome: 'Quay lại trang chủ',
      minLengthError: 'Mật khẩu phải có ít nhất 8 ký tự',
      mismatchError: 'Mật khẩu xác nhận không khớp',
      incorrectPassword: 'Mật khẩu không chính xác. Vui lòng thử lại.',
    },
    rescue: {
      title: 'Cảnh báo bảo mật',
      subtitle: 'Xác thực sinh trắc học đã thất bại 3 lần liên tiếp trong 5 phút gần nhất.',
      warning:
        'CẢNH BÁO NGHIÊM TRỌNG: Cần Hard Reset để mở khoá vùng bảo mật. Việc này sẽ xoá vĩnh viễn toàn bộ ví đang lưu trên thiết bị. Hãy chắc chắn bạn đã sao lưu Seed Phrase.',
      confirmLabel: 'Nhập DELETE ALL bên dưới để xác nhận xoá:',
      confirmPlaceholder: 'DELETE ALL',
      resetButton: 'Hard Reset & Xoá toàn bộ ví',
      cancel: 'Huỷ',
      confirmPhrase: 'DELETE ALL',
    },
  },
}

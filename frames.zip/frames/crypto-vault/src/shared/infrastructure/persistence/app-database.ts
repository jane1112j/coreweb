import Dexie, { type Table } from 'dexie'
import type { Wallet } from '@modules/wallet/domain/types'
import type { Token } from '@modules/token/types'

export class AppDatabase extends Dexie {
  wallets!: Table<Wallet, string>
  tokens!: Table<Token, number>

  constructor() {
    super('metanode_vault_v2') // Sử dụng v2 để tránh xung đột với DB cũ nếu có
    this.version(1).stores({
      wallets: 'address, name, type, isHidden',
      tokens: '++id, address, symbol, walletAddress',
    })
    this.version(2).stores({
      wallets: 'address, name, isHidden',
    })
  }
}

export const db = new AppDatabase()

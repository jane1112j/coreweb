import Dexie, { type Table } from 'dexie'

export interface StoredFile {
  path: string
  content: Blob | ArrayBuffer | string
  contentType: string
  updatedAt: number
}

export class FileDatabase extends Dexie {
  files!: Table<StoredFile, string>

  constructor() {
    super('storage_fallback_db')
    this.version(1).stores({
      files: 'path, contentType, updatedAt',
    })
  }
}

export const fileDb = new FileDatabase()

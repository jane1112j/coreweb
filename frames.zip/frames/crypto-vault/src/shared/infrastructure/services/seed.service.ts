import type { ISeedService } from '../../domain/services/seed-service.interface'

export class SeedService implements ISeedService {
  private wordLists: Map<string, string[]> = new Map()

  /**
   * Load danh sách từ từ một file text hoặc string
   * @param lang Mã ngôn ngữ (ví dụ: 'en', 'vi')
   * @param content Nội dung file (dòng cách dòng)
   */
  setWordList(lang: string, content: string): void {
    const words = content
      .split('\n')
      .map((w) => w.trim())
      .filter((w) => w.length > 0)
    this.wordLists.set(lang, words)
  }

  /**
   * Lấy một từ ngẫu nhiên không trùng lặp trong danh sách hiện tại
   */
  private getRandomUniqueWord(data: string[], valueList: string[]): string {
    const random = Math.floor(Math.random() * data.length)
    const randomValue = data[random]

    if (!valueList.includes(randomValue)) {
      return randomValue
    }

    return this.getRandomUniqueWord(data, valueList)
  }

  /**
   * Tạo chuỗi seed ngẫu nhiên với độ dài chỉ định
   * @param lang Ngôn ngữ sử dụng
   * @param length Độ dài chuỗi (mặc định 24 từ)
   */
  generateSeed(lang: string = 'en', length: number = 24): string[] {
    const data = this.wordLists.get(lang)
    if (!data) {
      throw new Error(`Word list for language '${lang}' not found. Please load it first.`)
    }

    if (data.length < length) {
      throw new Error(`Word list is too short to generate ${length} unique words.`)
    }

    const valueList: string[] = []
    while (valueList.length < length) {
      const value = this.getRandomUniqueWord(data, valueList)
      valueList.push(value)
    }

    return valueList
  }

  /**
   * Kiểm tra tính hợp lệ của một seed phrase (tùy chọn mở rộng)
   */
  isValidSeed(lang: string, seed: string[]): boolean {
    const data = this.wordLists.get(lang)
    if (!data) return false
    return seed.every((word) => data.includes(word))
  }
}

export const seedService = new SeedService()

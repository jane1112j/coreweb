import { fileDb } from '../persistence/file-database'
import type { IStorageService } from '../../domain/services/storage-service.interface'

export enum StorageErrorType {
  NETWORK = 'NETWORK_ERROR',
  PERMISSION = 'PERMISSION_ERROR',
  STORAGE_FULL = 'STORAGE_FULL',
  NOT_FOUND = 'NOT_FOUND',
  UNKNOWN = 'UNKNOWN_ERROR',
}

export class StorageError extends Error {
  constructor(
    public type: StorageErrorType,
    message: string,
  ) {
    super(message)
    this.name = 'StorageError'
  }
}

export type DownloadProgressCallback = (loaded: number, total: number) => void

export enum ResponseType {
  BLOB = 'blob',
  ARRAY_BUFFER = 'arraybuffer',
  JSON = 'json',
  TEXT = 'text',
}

export class StorageService implements IStorageService {
  #directoryHandle: FileSystemDirectoryHandle | null = null

  constructor() {
    this.#initOPFS().catch((err) => console.warn('[StorageService] OPFS init failed:', err))
  }

  async #initOPFS() {
    try {
      if (navigator.storage && navigator.storage.getDirectory) {
        this.#directoryHandle = await navigator.storage.getDirectory()
      }
    } catch (error) {
      console.warn('[StorageService] OPFS is not supported or accessible.', error)
    }
  }

  /**
   * Tải dữ liệu bằng Fetch API và theo dõi tiến trình
   */
  async download(
    url: string,
    responseType: ResponseType = ResponseType.BLOB,
    onProgress?: DownloadProgressCallback,
  ): Promise<any> {
    try {
      const response = await fetch(url)
      if (!response.ok) {
        throw new StorageError(StorageErrorType.NETWORK, `HTTP error! status: ${response.status}`)
      }

      const contentLength = response.headers.get('content-length')
      const total = contentLength ? parseInt(contentLength, 10) : 0
      let loaded = 0

      const reader = response.body?.getReader()
      if (!reader) throw new StorageError(StorageErrorType.UNKNOWN, 'Response body is null')

      const chunks: BlobPart[] = []
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        if (value) {
          chunks.push(value)
          loaded += value.length
          onProgress?.(loaded, total)
        }
      }

      const blob = new Blob(chunks)

      switch (responseType) {
        case ResponseType.JSON:
          return JSON.parse(await blob.text())
        case ResponseType.ARRAY_BUFFER:
          return await blob.arrayBuffer()
        case ResponseType.TEXT:
          return await blob.text()
        default:
          return blob
      }
    } catch (error) {
      this.#handleError(error)
    }
  }

  /**
   * Truy cập tệp tin theo đường dẫn phân cấp (ví dụ: a/b/c.txt)
   * Tự động tạo thư mục trung gian nếu chưa có.
   */
  async getFileHandle(path: string, create = true): Promise<FileSystemFileHandle> {
    const parts = path.split('/').filter((p) => p.length > 0)
    const fileName = parts.pop()
    if (!fileName) throw new Error('Invalid file path')

    let currentDir = this.#directoryHandle || (await navigator.storage.getDirectory())

    for (const part of parts) {
      currentDir = await currentDir.getDirectoryHandle(part, { create })
    }

    return await currentDir.getFileHandle(fileName, { create })
  }

  /**
   * Ghi dữ liệu vào OPFS, nếu không hỗ trợ sẽ tự động chuyển sang IndexedDB
   */
  async writeFile(path: string, content: Blob | ArrayBuffer | string): Promise<void> {
    try {
      console.warn('[StorageService] writeFile: attempt OPFS for', path)
      // 1. Thử ghi vào OPFS
      const root = await Promise.race([
        this.#directoryHandle || navigator.storage.getDirectory(),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('OPFS timeout getDirectory')), 2000),
        ),
      ])

      if (root) {
        const fileHandle = await Promise.race([
          this.getFileHandle(path, true),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('OPFS timeout getFileHandle')), 2000),
          ),
        ])

        if ('createWritable' in fileHandle) {
          const writable = await fileHandle.createWritable()
          await writable.write(content)
          await writable.close()
          console.warn('[StorageService] writeFile: OPFS success for', path)
          return
        }
      }

      // 2. Fallback sang IndexedDB
      console.warn('[StorageService] writeFile: OPFS skipped, attempting IndexedDB fallback...')
      await this.#saveToIndexedDB(path, content)
    } catch (error) {
      // Nếu lỗi OPFS, thử lại với IndexedDB một lần nữa
      console.warn(
        '[StorageService] OPFS write failed or timeout, attempting IndexedDB fallback...',
        error,
      )
      try {
        await Promise.race([
          this.#saveToIndexedDB(path, content),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('IndexedDB timeout')), 2000),
          ),
        ])
        console.warn('[StorageService] writeFile: IndexedDB success for', path)
      } catch (idbErr) {
        console.error('[StorageService] writeFile: IndexedDB failed or timeout for', path, idbErr)
      }
    }
  }

  /**
   * Đọc tệp tin (Ưu tiên OPFS, sau đó là IndexedDB)
   */
  async readFile(path: string): Promise<Blob | ArrayBuffer | string | null> {
    try {
      console.warn('[StorageService] readFile: attempt OPFS for', path)
      const fileHandle = await Promise.race([
        this.getFileHandle(path, false),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('OPFS timeout')), 2000),
        ),
      ])
      const file = await fileHandle.getFile()
      console.warn('[StorageService] readFile: OPFS success for', path)
      return file
    } catch (err) {
      console.warn(
        '[StorageService] readFile: OPFS failed or timeout, fallback to IndexedDB for',
        path,
        err,
      )
      // Thử tìm trong IndexedDB
      try {
        const stored = await Promise.race([
          fileDb.files.get(path),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('IndexedDB timeout')), 2000),
          ),
        ])
        console.warn(
          '[StorageService] readFile: IndexedDB success for',
          path,
          stored ? 'found' : 'not found',
        )
        return stored ? stored.content : null
      } catch (idbErr) {
        console.error('[StorageService] readFile: IndexedDB failed or timeout for', path, idbErr)
        return null
      }
    }
  }

  /**
   * Xóa tệp hoặc thư mục đệ quy
   */
  async remove(path: string): Promise<void> {
    try {
      const parts = path.split('/').filter((p) => p.length > 0)
      const target = parts.pop()
      if (!target) return

      let parentDir = this.#directoryHandle || (await navigator.storage.getDirectory())
      for (const part of parts) {
        parentDir = await parentDir.getDirectoryHandle(part)
      }

      await parentDir.removeEntry(target, { recursive: true })
    } catch (_error) {
      // Đồng thời xóa cả trong IndexedDB nếu có
      await fileDb.files.delete(path)
    }
  }

  /**
   * Kiểm tra sự tồn tại của tệp tin
   */
  async exists(path: string): Promise<boolean> {
    try {
      await this.getFileHandle(path, false)
      return true
    } catch {
      try {
        const file = await fileDb.files.get(path)
        return !!file
      } catch {
        return false
      }
    }
  }

  /**
   * Dọn dẹp toàn bộ bộ nhớ (OPFS + IndexedDB) với danh sách loại trừ
   */
  async cleanUp(whitelist: string[] = []): Promise<void> {
    try {
      // 1. Dọn dẹp OPFS
      const root = await navigator.storage.getDirectory()
      for await (const [name] of (root as any).entries()) {
        if (!whitelist.includes(name)) {
          await root.removeEntry(name, { recursive: true })
        }
      }

      // 2. Dọn dẹp các Database (IndexedDB)
      const databases = await indexedDB.databases()
      for (const dbInfo of databases) {
        if (dbInfo.name && !whitelist.includes(dbInfo.name)) {
          indexedDB.deleteDatabase(dbInfo.name)
        }
      }
    } catch (_error) {
      console.error('[StorageService] Cleanup failed:', _error)
    }
  }

  /**
   * Kiểm tra mạng (True nếu Mất kết nối)
   */
  isOffline(): boolean {
    return !navigator.onLine
  }

  #handleError(error: any): never {
    if (error instanceof StorageError) throw error

    let type = StorageErrorType.UNKNOWN
    const name = error.name || ''
    const msg = error.message || ''

    if (name === 'NotAllowedError') type = StorageErrorType.PERMISSION
    if (name === 'QuotaExceededError') type = StorageErrorType.STORAGE_FULL
    if (name === 'NotFoundError') type = StorageErrorType.NOT_FOUND
    if (msg.toLowerCase().includes('fetch') || msg.toLowerCase().includes('network')) {
      type = StorageErrorType.NETWORK
    }

    throw new StorageError(type, msg)
  }

  async #saveToIndexedDB(path: string, content: Blob | ArrayBuffer | string) {
    const contentType = content instanceof Blob ? content.type : 'application/octet-stream'
    await fileDb.files.put({
      path,
      content,
      contentType,
      updatedAt: Date.now(),
    })
  }
}

export const storageService = new StorageService()

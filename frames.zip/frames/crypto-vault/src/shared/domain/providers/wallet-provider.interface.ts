import type { DecryptedWalletResponse } from '@modules/wallet/domain/types'

export interface IWalletProvider {
  getDecryptedWallet(address: string): Promise<DecryptedWalletResponse>
  getPrivateKey(address: string): Promise<string>
  getSeedPhrase(address: string): Promise<string>
}

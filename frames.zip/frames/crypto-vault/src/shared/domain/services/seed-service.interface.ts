export interface ISeedService {
  setWordList(lang: string, content: string): void
  generateSeed(lang?: string, length?: number): string[]
  isValidSeed(lang: string, seed: string[]): boolean
}

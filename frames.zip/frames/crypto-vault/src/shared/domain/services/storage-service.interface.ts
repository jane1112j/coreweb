import type {
  ResponseType,
  DownloadProgressCallback,
} from '../../infrastructure/services/storage.service'

export interface IStorageService {
  download(
    url: string,
    responseType?: ResponseType,
    onProgress?: DownloadProgressCallback,
  ): Promise<any>
  writeFile(path: string, content: string | Blob | ArrayBuffer): Promise<void>
  readFile(path: string): Promise<string | Blob | ArrayBuffer | null>
  remove(path: string): Promise<void>
  exists(path: string): Promise<boolean>
}

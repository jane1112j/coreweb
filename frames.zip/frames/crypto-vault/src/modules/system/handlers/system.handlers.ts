import type { ApplicationActionHandler } from '@metanodejs/fiai-sdk'
import { VaultActions } from '@/core/actions'
import type { SecurityProvider } from '@/shared/infrastructure/security'

/**
 * Handler cho lệnh Ping hệ thống
 */
export class PingHandler implements ApplicationActionHandler {
  readonly action = VaultActions.PING
  constructor(private securityProvider: SecurityProvider) {}
  handle() {
    return {
      pong: true,
      timestamp: Date.now(),
      locked: this.securityProvider.isLocked(),
    }
  }
}

/**
 * Handler lấy trạng thái Vault (mở/khóa/setup)
 */
export class GetVaultStatusHandler implements ApplicationActionHandler {
  readonly action = VaultActions.GET_VAULT_STATUS
  constructor(private securityProvider: SecurityProvider) {}

  async handle() {
    const security = this.securityProvider.getSecurity()
    const mode = await security.getAuthMode()

    return {
      isLocked: this.securityProvider.isLocked(),
      isInitialized: mode !== 'none',
      authMode: mode,
      version: '1.0.0', // Có thể lấy từ package.json nếu cần
    }
  }
}

/**
 * Handler khóa Vault thủ công
 */
export class LockVaultHandler implements ApplicationActionHandler {
  readonly action = VaultActions.LOCK_VAULT
  constructor(private securityProvider: SecurityProvider) {}

  handle() {
    this.securityProvider.getSecurity().lock()
    return { success: true }
  }
}

import type { ApplicationActionHandler } from '@metanodejs/fiai-sdk'
import type { SecurityProvider } from '@shared/infrastructure/security'
import * as Handlers from './handlers/system.handlers'

export interface SystemModuleDeps {
  securityProvider: SecurityProvider
}

export class SystemModule {
  constructor(private readonly securityProvider: SecurityProvider) {}

  public getHandlers(): ApplicationActionHandler[] {
    return [
      new Handlers.PingHandler(this.securityProvider),
      new Handlers.GetVaultStatusHandler(this.securityProvider),
      new Handlers.LockVaultHandler(this.securityProvider),
    ]
  }
}

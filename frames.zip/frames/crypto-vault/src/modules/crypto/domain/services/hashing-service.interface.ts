export interface IHashingSession {
  update(data: Uint8Array): void
  digest(): string
}

export interface IHashingService {
  keccak256(message: string, isHex?: boolean): string
  createStreamingHash(): IHashingSession
  keccak256File: (input: Blob, chunkSize?: number) => Promise<string>
}

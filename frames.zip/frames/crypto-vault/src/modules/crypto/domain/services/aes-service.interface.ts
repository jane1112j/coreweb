export interface IAesService {
  encryptGcm(keyHex: string, plainHexOrString: string): Promise<string>
  decryptGcm(
    keyHex: string,
    encryptedHex: string,
  ): Promise<{
    result: string
    resultUtf8: string
  }>
  encryptCbc(keyHex: string, plainString: string, ivHex?: string): Promise<string>
  decryptCbc(keyHex: string, encryptedHex: string): Promise<string>
}

export interface IStreamingHashService {
  createSession(): string
  updateChunk(
    sessionId: string,
    chunk: string | number[] | Uint8Array | ArrayBuffer | ArrayBufferView,
    isHex?: boolean,
    chunkIndex?: number,
  ): void
  finalize(sessionId: string): string
}

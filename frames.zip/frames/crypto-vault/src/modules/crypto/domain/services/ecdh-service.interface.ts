export interface IEcdhService {
  getSharedKey(address: string, publicKey: string): Promise<string>
}

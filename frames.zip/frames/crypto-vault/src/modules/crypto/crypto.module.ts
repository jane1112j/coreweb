import { VaultActions } from '@/core/actions'
import { GenericActionHandler, type ApplicationActionHandler } from '@metanodejs/fiai-sdk'
import {
  CreateECDHPasswordUseCase,
  CreateHashesUseCase,
  CreateHashUseCase,
  CreateSignUseCase,
  DecodeAbiUseCase,
  DecryptAesECDHUseCase,
  DecryptAesGCMUseCase,
  EncryptAesECDHUseCase,
  EncryptAesGCMUseCase,
  FinalizeHashSessionUseCase,
  GetEncryptedPublicKeyUseCase,
  InitHashSessionUseCase,
  SignWithWalletUseCase,
  UpdateHashChunkUseCase,
  type CreateECDHPasswordRequest,
  type CreateECDHPasswordResponse,
  type CreateHashesRequest,
  type CreateHashesResponse,
  type CreateHashRequest,
  type CreateHashResponse,
  type CreateSignRequest,
  type CreateSignResponse,
  type DecodeAbiRequest,
  type DecodeAbiResponse,
  type DecryptAesECDHRequest,
  type DecryptAesECDHResponse,
  type DecryptAesGCMRequest,
  type DecryptAesGCMResponse,
  type EncryptAesECDHRequest,
  type EncryptAesECDHResponse,
  type EncryptAesGCMRequest,
  type EncryptGCMResponse,
  type FinalizeHashSessionRequest,
  type FinalizeHashSessionResponse,
  type GetEncryptedPublicKeyRequest,
  type GetEncryptedPublicKeyResponse,
  type InitHashSessionResponse,
  type SignWithWalletRequest,
  type SignWithWalletResponse,
  type UpdateHashChunkRequest,
  type UpdateHashChunkResponse,
  type GetPrivateKeyRequest,
  type GetPrivateKeyResponse,
  GetPrivateKeyUseCase,
} from './application/use-cases'

import type { IWalletProvider } from '@/shared/domain/providers'
import {
  HashFileUseCase,
  type HashFileRequest,
  type HashFileResponse,
} from './application/use-cases/hash-file.usecase'
import type { IAesService, IEcdhService, IHashingService } from './domain/services'
import type { IStreamingHashService } from './domain/services/streaming-hash-service.interface'
import { AesServiceAdapter } from './infrastructure/services/aes-service.adapter'
import { EcdhServiceAdapter } from './infrastructure/services/ecdh-service.adapter'
import { HashingService } from './infrastructure/services/hashing-service.adapter'
import { StreamingHashService } from './infrastructure/services/streaming-hash.service'

export class CryptoModule {
  private hashingService!: IHashingService
  private ecdhService!: IEcdhService
  private aesService!: IAesService
  private streamingHashService!: IStreamingHashService

  constructor(private readonly walletProvider: IWalletProvider) {
    this.hashingService = new HashingService()
    this.ecdhService = new EcdhServiceAdapter(this.walletProvider)
    this.aesService = new AesServiceAdapter()
    this.streamingHashService = new StreamingHashService(this.hashingService)
  }

  public getHandlers(): ApplicationActionHandler[] {
    return [
      // SIGN_WITH_WALLET
      new GenericActionHandler<SignWithWalletRequest, SignWithWalletResponse>(
        VaultActions.SIGN_WITH_WALLET,
        new SignWithWalletUseCase(this.walletProvider),
      ),
      // CREATE_HASH
      new GenericActionHandler<CreateHashRequest, CreateHashResponse>(
        VaultActions.CREATE_HASH,
        new CreateHashUseCase(this.hashingService),
      ),
      // CREATE_HASHES
      new GenericActionHandler<CreateHashesRequest, CreateHashesResponse>(
        VaultActions.CREATE_HASHES,
        new CreateHashesUseCase(this.hashingService),
      ),
      // ENCRYPT_AES_ECDH
      new GenericActionHandler<EncryptAesECDHRequest, EncryptAesECDHResponse>(
        VaultActions.ENCRYPT_AES_ECDH,
        new EncryptAesECDHUseCase(this.ecdhService, this.aesService),
      ),
      // DECRYPT_AES_ECDH
      new GenericActionHandler<DecryptAesECDHRequest, DecryptAesECDHResponse>(
        VaultActions.DECRYPT_AES_ECDH,
        new DecryptAesECDHUseCase(this.ecdhService, this.aesService),
      ),
      // GET_ENCRYPTED_PUBLIC_KEY
      new GenericActionHandler<GetEncryptedPublicKeyRequest, GetEncryptedPublicKeyResponse>(
        VaultActions.GET_ENCRYPTED_PUBLIC_KEY,
        new GetEncryptedPublicKeyUseCase(this.walletProvider),
      ),
      // CREATE_ECDH_PASSWORD
      new GenericActionHandler<CreateECDHPasswordRequest, CreateECDHPasswordResponse>(
        VaultActions.CREATE_ECDH_PASSWORD,
        new CreateECDHPasswordUseCase(this.ecdhService),
      ),
      // ENCRYPT_AES_GCM
      new GenericActionHandler<EncryptAesGCMRequest, EncryptGCMResponse>(
        VaultActions.ENCRYPT_AES_GCM,
        new EncryptAesGCMUseCase(this.aesService),
      ),
      // DECRYPT_AES_GCM
      new GenericActionHandler<DecryptAesGCMRequest, DecryptAesGCMResponse>(
        VaultActions.DECRYPT_AES_GCM,
        new DecryptAesGCMUseCase(this.aesService),
      ),
      // INIT_HASH_SESSION
      new GenericActionHandler<unknown, InitHashSessionResponse>(
        VaultActions.INIT_HASH_SESSION,
        new InitHashSessionUseCase(this.streamingHashService),
      ),
      // UPDATE_HASH_CHUNK
      new GenericActionHandler<UpdateHashChunkRequest, UpdateHashChunkResponse>(
        VaultActions.UPDATE_HASH_CHUNK,
        new UpdateHashChunkUseCase(this.streamingHashService),
      ),
      // FINALIZE_HASH_SESSION
      new GenericActionHandler<FinalizeHashSessionRequest, FinalizeHashSessionResponse>(
        VaultActions.FINALIZE_HASH_SESSION,
        new FinalizeHashSessionUseCase(this.streamingHashService),
      ),
      // HASH_FILE
      new GenericActionHandler<HashFileRequest, HashFileResponse>(
        VaultActions.HASH_FILE,
        new HashFileUseCase(this.hashingService),
      ),
      // decode abi
      new GenericActionHandler<DecodeAbiRequest, DecodeAbiResponse>(
        VaultActions.DECODE_ABI,
        new DecodeAbiUseCase(),
      ),
      // GET PRIVATE KEY
      new GenericActionHandler<GetPrivateKeyRequest, GetPrivateKeyResponse>(
        VaultActions.GET_PRIVATE_KEY,
        new GetPrivateKeyUseCase(this.walletProvider),
      ),
      // CREATE SIGN
      new GenericActionHandler<CreateSignRequest, CreateSignResponse>(
        VaultActions.CREATE_SIGN,
        new CreateSignUseCase(this.walletProvider),
      ),
    ]
  }
}

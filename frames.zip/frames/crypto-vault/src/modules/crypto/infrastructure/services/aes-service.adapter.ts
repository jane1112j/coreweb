import type { IAesService } from '../../domain/services'

export class AesServiceAdapter implements IAesService {
  private hexToBytes(hex: string): Uint8Array {
    const bytes = new Uint8Array(hex.length / 2)
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16)
    }
    return bytes
  }

  private bytesToHex(bytes: Uint8Array): string {
    return Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('')
  }

  async encryptGcm(keyHex: string, plainHexOrString: string): Promise<string> {
    const cryptoSubtle = globalThis.crypto.subtle
    const keyData = this.hexToBytes(keyHex)

    const cryptoKey = await cryptoSubtle.importKey(
      'raw',
      keyData as unknown as ArrayBuffer,
      { name: 'AES-GCM' },
      false,
      ['encrypt'],
    )

    const iv = globalThis.crypto.getRandomValues(new Uint8Array(12))

    let dataToEncrypt: Uint8Array
    if (/^[0-9a-fA-F]{64}$/.test(plainHexOrString)) {
      dataToEncrypt = this.hexToBytes(plainHexOrString)
    } else {
      const encoder = new TextEncoder()
      dataToEncrypt = encoder.encode(plainHexOrString)
    }

    const ciphertextBuffer = await cryptoSubtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv as unknown as ArrayBuffer,
        tagLength: 128,
      },
      cryptoKey,
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
      dataToEncrypt as unknown as ArrayBuffer,
    )

    const ciphertextHex = this.bytesToHex(new Uint8Array(ciphertextBuffer))
    const ivHex = this.bytesToHex(iv)
    return ivHex + ciphertextHex
  }

  async decryptGcm(
    keyHex: string,
    encryptedHex: string,
  ): Promise<{ result: string; resultUtf8: string }> {
    if (encryptedHex.length < 24) {
      throw new Error('Invalid message format: too short')
    }

    const ivHex = encryptedHex.substring(0, 24)
    const cipherHex = encryptedHex.substring(24)

    const ivBytes = this.hexToBytes(ivHex)
    const cipherBytes = this.hexToBytes(cipherHex)

    const cryptoSubtle = globalThis.crypto.subtle
    const keyData = this.hexToBytes(keyHex)

    const cryptoKey = await cryptoSubtle.importKey(
      'raw',
      keyData as unknown as ArrayBuffer,
      { name: 'AES-GCM' },
      false,
      ['decrypt'],
    )

    const decryptedBuffer = await cryptoSubtle.decrypt(
      {
        name: 'AES-GCM',
        iv: ivBytes as unknown as BufferSource,
        tagLength: 128,
      },
      cryptoKey,
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
      cipherBytes as unknown as ArrayBuffer,
    )

    return {
      result: this.bytesToHex(new Uint8Array(decryptedBuffer)),
      resultUtf8: new TextDecoder().decode(decryptedBuffer),
    }
  }

  async encryptCbc(keyHex: string, plainString: string, ivHex?: string): Promise<string> {
    const cryptoSubtle = globalThis.crypto.subtle
    const keyData = this.hexToBytes(keyHex)

    const cryptoKey = await cryptoSubtle.importKey(
      'raw',
      keyData as unknown as ArrayBuffer,
      { name: 'AES-CBC' },
      false,
      ['encrypt'],
    )

    const iv = ivHex
      ? this.hexToBytes(ivHex)
      : globalThis.crypto.getRandomValues(new Uint8Array(16))
    const encoder = new TextEncoder()

    const ciphertextBuffer = await cryptoSubtle.encrypt(
      {
        name: 'AES-CBC',
        iv: iv as unknown as ArrayBuffer,
      },
      cryptoKey,
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
      encoder.encode(plainString) as unknown as ArrayBuffer,
    )

    const ciphertextHex = this.bytesToHex(new Uint8Array(ciphertextBuffer))
    const resultIvHex = this.bytesToHex(iv)
    return resultIvHex + ciphertextHex
  }

  async decryptCbc(keyHex: string, encryptedHex: string): Promise<string> {
    if (encryptedHex.length < 32) {
      throw new Error('Invalid message format: too short')
    }

    const ivHex = encryptedHex.substring(0, 32)
    const cipherHex = encryptedHex.substring(32)

    const ivBytes = this.hexToBytes(ivHex)
    const cipherBytes = this.hexToBytes(cipherHex)

    const cryptoSubtle = globalThis.crypto.subtle
    const keyData = this.hexToBytes(keyHex)

    const cryptoKey = await cryptoSubtle.importKey(
      'raw',
      keyData as unknown as ArrayBuffer,
      { name: 'AES-CBC' },
      false,
      ['decrypt'],
    )

    const decryptedBuffer = await cryptoSubtle.decrypt(
      {
        name: 'AES-CBC',
        iv: ivBytes as unknown as BufferSource,
      },
      cryptoKey,
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
      cipherBytes as unknown as ArrayBuffer,
    )

    const decoder = new TextDecoder()
    return decoder.decode(decryptedBuffer)
  }
}

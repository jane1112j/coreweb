import { getBLS } from '@metanodejs/bls-crypto'
import type { IHashingService, IHashingSession } from '../../domain/services'

export class HashingService implements IHashingService {
  public async keccak256File(input: Blob, chunkSize = 1024 * 250): Promise<string> {
    if (!input) {
      throw new Error('Message is required')
    }
    const bls = getBLS()
    const rs = await bls.keccak256File(input, chunkSize)
    const { hash } = rs
    if (!hash) {
      throw new Error('Hash not generated')
    }
    return hash.toLocaleLowerCase()
  }

  public keccak256(message: string, isHex = false): string {
    if (!message) {
      throw new Error('Message is required')
    }
    const bls = getBLS()
    const isHexInt = isHex ? 1 : 0
    const { hash } = bls.keccak256(message, isHexInt)
    if (!hash) {
      throw new Error('Hash not generated')
    }
    return hash.toLocaleLowerCase()
  }

  public createStreamingHash(): IHashingSession {
    const bls = getBLS()
    const ctx = new bls.Keccak256Context()
    return {
      update(data: Uint8Array): void {
        ctx.update(data)
      },
      digest(): string {
        const { hash } = ctx.final()
        return hash.startsWith('0x') ? hash : '0x' + hash
      },
    }
  }
}

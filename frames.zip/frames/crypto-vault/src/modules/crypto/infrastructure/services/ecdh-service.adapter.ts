import type { IWalletProvider } from '@shared/domain/providers/wallet-provider.interface'
import { getBLS } from '@metanodejs/bls-crypto'
import { utils } from '@metanodejs/fiai-sdk'
import type { IEcdhService } from '../../domain/services'

export class EcdhServiceAdapter implements IEcdhService {
  constructor(private readonly walletProvider: IWalletProvider) {}

  public async getSharedKey(address: string, publicKey: string): Promise<string> {
    if (!address) throw new Error('Address is required')
    if (!publicKey) throw new Error('Public key is required')

    const privateKey = await this.walletProvider.getPrivateKey(utils.formatAddress(address))
    if (!privateKey) throw new Error(`Not found info of wallet: ${address} in this session.`)

    const blsLib = getBLS()
    const { key: sharedKey } = blsLib.ecdh(privateKey, publicKey)
    return sharedKey
  }
}

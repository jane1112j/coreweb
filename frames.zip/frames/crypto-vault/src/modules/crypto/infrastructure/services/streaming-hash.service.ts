import { utils } from '@metanodejs/fiai-sdk'
import type { IHashingService, IStreamingHashService } from '../../domain/services'

export class StreamingHashService implements IStreamingHashService {
  private activeSessions = new Map<string, (Uint8Array | undefined)[]>()

  constructor(public readonly hashingProvider: IHashingService) {}

  public createSession(): string {
    const sessionId = 'hash-session-' + Math.random().toString(36).substring(2, 15)
    this.activeSessions.set(sessionId, [])
    return sessionId
  }

  public updateChunk(
    sessionId: string,
    chunk: string | number[] | Uint8Array | ArrayBuffer | ArrayBufferView,
    isHex?: boolean,
    chunkIndex?: number,
  ): void {
    const sessionChunks = this.activeSessions.get(sessionId)
    if (!sessionChunks) {
      throw new Error(`Hash session ${sessionId} not found or has been finalized`)
    }

    let binaryData: Uint8Array

    if (chunk instanceof ArrayBuffer) {
      binaryData = new Uint8Array(chunk)
    } else if (chunk instanceof Uint8Array) {
      binaryData = chunk
    } else if (ArrayBuffer.isView(chunk)) {
      binaryData = new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength)
    } else if (
      chunk &&
      typeof chunk === 'object' &&
      'buffer' in chunk &&
      chunk.buffer instanceof ArrayBuffer
    ) {
      // Dự phòng trường hợp đối tượng Uint8Array từ realm/iframe khác
      binaryData = new Uint8Array(
        chunk.buffer,
        (chunk as unknown as ArrayBufferView).byteOffset,
        (chunk as unknown as ArrayBufferView).byteLength,
      )
    } else if (Array.isArray(chunk)) {
      binaryData = new Uint8Array(chunk)
    } else if (typeof chunk === 'string') {
      if (isHex || /^[0-9a-fA-F]+$/.test(chunk)) {
        const cleanHex = chunk.startsWith('0x') ? chunk.slice(2) : chunk
        const view = new Uint8Array(cleanHex.length / 2)
        for (let i = 0; i < view.length; i++) {
          view[i] = parseInt(cleanHex.substring(i * 2, i * 2 + 2), 16)
        }
        binaryData = view
      } else {
        try {
          const binaryStr = atob(chunk)
          const bytes = new Uint8Array(binaryStr.length)
          for (let i = 0; i < binaryStr.length; i++) {
            bytes[i] = binaryStr.charCodeAt(i)
          }
          binaryData = bytes
        } catch {
          binaryData = new TextEncoder().encode(chunk)
        }
      }
    } else {
      throw new Error('Unsupported chunk format')
    }

    if (typeof chunkIndex === 'number') {
      sessionChunks[chunkIndex] = binaryData
    } else {
      sessionChunks.push(binaryData)
    }
  }

  public finalize(sessionId: string): string {
    const sessionChunks = this.activeSessions.get(sessionId)

    if (!sessionChunks) {
      throw new Error(`Hash session ${sessionId} not found or already finalized`)
    }
    try {
      const session = this.hashingProvider.createStreamingHash()

      for (const chunk of sessionChunks) {
        if (chunk) {
          session.update(chunk)
        }
      }
      const hash = session.digest()
      return utils.formatHex(hash)
    } finally {
      this.activeSessions.delete(sessionId)
    }
  }
}

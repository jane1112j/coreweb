import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IHashingService } from '../../domain/services'

export interface HashFileRequest {
  data: Blob
}

export type HashFileResponse = Promise<{
  hash: string
}>

export class HashFileUseCase implements IUseCase<HashFileRequest, HashFileResponse> {
  constructor(private readonly hashingProvider: IHashingService) {}

  async execute(params: HashFileRequest): HashFileResponse {
    const { data } = params
    const hash = await this.hashingProvider.keccak256File(data)
    return {
      hash,
    }
  }
}

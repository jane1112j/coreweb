import type { IWalletProvider } from '@/shared/domain/providers'
import { getBLS } from '@metanodejs/bls-crypto'
import type { IUseCase } from '@metanodejs/fiai-sdk'

export type Algorithm = 'bls' | 'secp256k1'

export interface SignWithWalletRequest {
  algorithm?: Algorithm
  address: string
  payload: string
  txtContext?: Record<string, unknown>
}

export interface SignWithWalletResponse {
  signature: string
}

export class SignWithWalletUseCase implements IUseCase<
  SignWithWalletRequest,
  SignWithWalletResponse
> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(params: SignWithWalletRequest): Promise<SignWithWalletResponse> {
    const { address, algorithm = 'bls', payload } = params
    if (!address) {
      throw new Error('Address is required')
    }
    if (!payload) {
      throw new Error('Payload is required')
    }

    // 1. Lấy private key thông qua Provider (Đã được decouple khỏi module Wallet)
    const privateKey = await this.walletProvider.getPrivateKey(address)
    const blsLib = getBLS()
    // 2. Ký giao dịch/thông điệp
    if (algorithm === 'secp256k1') {
      const { sign } = blsLib.ecdsa_sign(privateKey, payload, true)
      // blsLib.ecdsa_verify(payload, sign, )

      return {
        signature: sign.toLocaleLowerCase(),
      }
    }
    if (algorithm === 'bls') {
      const { sign } = blsLib.sign(privateKey, payload, true)
      return {
        signature: sign.toLocaleLowerCase(),
      }
    }
    // eslint-disable-next-line @typescript-eslint/restrict-template-expressions
    throw new Error(`Algorithm ${algorithm} not supported yet`)
  }
}

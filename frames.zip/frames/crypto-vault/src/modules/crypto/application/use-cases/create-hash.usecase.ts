import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IHashingService } from '../../domain/services'

export interface CreateHashRequest {
  message: string
  isHex?: boolean
}

export interface CreateHashResponse {
  hash: string
}

export class CreateHashUseCase implements IUseCase<CreateHashRequest, CreateHashResponse> {
  constructor(private readonly hashingProvider: IHashingService) {}

  execute(params: CreateHashRequest): CreateHashResponse {
    const { message, isHex = false } = params
    const hash = this.hashingProvider.keccak256(message, isHex)
    return {
      hash,
    }
  }
}

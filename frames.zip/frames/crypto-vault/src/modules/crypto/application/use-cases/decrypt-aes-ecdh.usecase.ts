import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IAesService, IEcdhService } from '../../domain/services'

export interface DecryptAesECDHRequest {
  address: string
  message: string
  publicKey: string
}

export interface DecryptAesECDHResponse {
  value: string
}

export class DecryptAesECDHUseCase implements IUseCase<
  DecryptAesECDHRequest,
  DecryptAesECDHResponse
> {
  constructor(
    private readonly ecdhService: IEcdhService,
    private readonly aesService: IAesService,
  ) {}

  async execute(params: DecryptAesECDHRequest): Promise<DecryptAesECDHResponse> {
    const { address, message, publicKey } = params

    if (!address) throw new Error('Address is required')
    if (!message) throw new Error('Message is required')
    if (!publicKey) throw new Error('Public key is required')

    const sharedKey = await this.ecdhService.getSharedKey(address, publicKey)
    console.log('sharedKey', sharedKey)
    const decryptedValue = await this.aesService.decryptCbc(sharedKey, message)

    return {
      value: decryptedValue,
    }
  }
}

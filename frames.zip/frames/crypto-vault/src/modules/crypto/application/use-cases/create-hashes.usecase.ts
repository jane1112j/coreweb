import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IHashingService } from '../../domain/services'

export interface CreateHashesRequest {
  messages: string[]
  isHex?: boolean
}

export interface CreateHashesResponse {
  hashes: string[]
}

export class CreateHashesUseCase implements IUseCase<CreateHashesRequest, CreateHashesResponse> {
  constructor(private readonly hashingProvider: IHashingService) {}

  execute(params: CreateHashesRequest): CreateHashesResponse {
    const { messages, isHex = false } = params
    if (!messages || !Array.isArray(messages)) {
      throw new Error('messages must be an array')
    }

    const hashes: string[] = []

    for (const message of messages) {
      const hash = this.hashingProvider.keccak256(message, isHex)
      hashes.push(hash)
    }

    return {
      hashes,
    }
  }
}

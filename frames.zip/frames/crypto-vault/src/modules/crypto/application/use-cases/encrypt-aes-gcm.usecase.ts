import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IAesService } from '../../domain/services'

export interface EncryptAesGCMRequest {
  sharedSecret: string
  plainText: string
}

export interface EncryptGCMResponse {
  result: string
}

export class EncryptAesGCMUseCase implements IUseCase<EncryptAesGCMRequest, EncryptGCMResponse> {
  constructor(private readonly aesService: IAesService) {}

  async execute(payload: EncryptAesGCMRequest): Promise<EncryptGCMResponse> {
    const { sharedSecret, plainText } = payload
    if (!sharedSecret) throw new Error('sharedHex is required')
    if (!plainText) throw new Error('plainHex is required')

    const resultHex = await this.aesService.encryptGcm(sharedSecret, plainText)

    return {
      result: resultHex,
    }
  }
}

import type { IWalletProvider } from '@/shared/domain/providers'
import { getBLS } from '@metanodejs/bls-crypto'
import type { IUseCase } from '@metanodejs/fiai-sdk'

export interface GetEncryptedPublicKeyRequest {
  address: string
}

export interface GetEncryptedPublicKeyResponse {
  encryptedPublicKey: string
}

export class GetEncryptedPublicKeyUseCase implements IUseCase<
  GetEncryptedPublicKeyRequest,
  GetEncryptedPublicKeyResponse
> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(payload: GetEncryptedPublicKeyRequest): Promise<GetEncryptedPublicKeyResponse> {
    const { address } = payload
    if (!address) throw new Error('Address is required')

    const privateKey = await this.walletProvider.getPrivateKey(address)
    if (!privateKey) throw new Error(`Not found info of wallet: ${address} in this session.`)

    const blsLib = getBLS()
    const ecdhKey = blsLib.ec_pubkey_create(privateKey, true)
    return {
      encryptedPublicKey: ecdhKey.public_key.toLowerCase(),
    }
  }
}

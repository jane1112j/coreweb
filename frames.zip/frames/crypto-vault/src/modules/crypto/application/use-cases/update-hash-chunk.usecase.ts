import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IStreamingHashService } from '../../domain/services'

export interface UpdateHashChunkRequest {
  sessionId: string
  chunk: string | number[] | Uint8Array
  isHex?: boolean
  chunkIndex?: number
}

export interface UpdateHashChunkResponse {
  success: boolean
}

export class UpdateHashChunkUseCase implements IUseCase<
  UpdateHashChunkRequest,
  UpdateHashChunkResponse
> {
  constructor(private readonly streamingHashService: IStreamingHashService) {}

  execute(params: UpdateHashChunkRequest): UpdateHashChunkResponse {
    const { sessionId, chunk, isHex, chunkIndex } = params
    this.streamingHashService.updateChunk(sessionId, chunk, isHex, chunkIndex)
    return { success: true }
  }
}

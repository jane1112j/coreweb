import { getBLS } from '@metanodejs/bls-crypto'
import type { IUseCase } from '@metanodejs/fiai-sdk'

export interface DecodeAbiRequest {
  rawInput: string
  outputs: unknown[]
  functionName: string
}

export type DecodeAbiResponse = unknown

export class DecodeAbiUseCase implements IUseCase<DecodeAbiRequest, DecodeAbiResponse> {
  constructor() {}

  execute(params: DecodeAbiRequest): DecodeAbiResponse {
    const bls = getBLS()
    const rs: any = bls.abi_decode(params.rawInput, params.outputs)
    let data: unknown
    try {
      data = JSON.parse(rs.decode)
    } catch (_) {
      data = rs.decode
    }

    return data
  }
}

import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IAesService, IEcdhService } from '../../domain/services'

export interface EncryptAesECDHRequest {
  address: string
  publicKey: string
  message: string
}

export interface EncryptAesECDHResponse {
  publicKeyLocal: string
  value: string
}

export class EncryptAesECDHUseCase implements IUseCase<
  EncryptAesECDHRequest,
  EncryptAesECDHResponse
> {
  constructor(
    private readonly ecdhService: IEcdhService,
    private readonly aesService: IAesService,
  ) {}

  async execute(payload: EncryptAesECDHRequest): Promise<EncryptAesECDHResponse> {
    const { address, message, publicKey } = payload
    if (!address) throw new Error('Address is required')
    if (!message) throw new Error('Message is required')
    if (!publicKey) throw new Error('Public key is required')

    const sharedKey = await this.ecdhService.getSharedKey(address, publicKey)

    // Mã hoá AES-CBC với IV cố định 16 byte 0x00 để tương thích với code cũ
    const fixedIvHex = '00000000000000000000000000000000'
    const resultHex = await this.aesService.encryptCbc(sharedKey, message, fixedIvHex)

    return {
      value: resultHex,
      publicKeyLocal: publicKey,
    }
  }
}

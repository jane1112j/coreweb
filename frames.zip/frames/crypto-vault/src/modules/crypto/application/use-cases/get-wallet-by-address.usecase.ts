import type { Wallet } from '@/modules/wallet/domain/types'
import type { IWalletProvider } from '@/shared/domain/providers'
import type { IUseCase } from '@metanodejs/fiai-sdk'

export interface GetWalletByAddressRequest {
  address: string
}

export type GetWalletByAddressResponse = Wallet

export class GetWalletByAddressUseCase implements IUseCase<
  GetWalletByAddressRequest,
  GetWalletByAddressResponse
> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(params: GetWalletByAddressRequest): Promise<GetWalletByAddressResponse> {
    const { address } = params
    if (!address) {
      throw new Error('Address is required')
    }

    // 1. Lấy private key thông qua Provider (Đã được decouple khỏi module Wallet)
    const wallet = await this.walletProvider.getDecryptedWallet(address)
    return {
      name: wallet.name,
      address: wallet.address,
      backgroundImage: '',
      totalBalanceString: wallet.totalBalanceString,
    } as Wallet
  }
}

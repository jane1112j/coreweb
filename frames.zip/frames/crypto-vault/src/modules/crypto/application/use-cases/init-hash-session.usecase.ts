import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IStreamingHashService } from '../../domain/services'

export interface InitHashSessionResponse {
  sessionId: string
}

export class InitHashSessionUseCase implements IUseCase<unknown, InitHashSessionResponse> {
  constructor(private readonly streamingHashService: IStreamingHashService) {}

  execute(): InitHashSessionResponse {
    const sessionId = this.streamingHashService.createSession()
    return { sessionId }
  }
}

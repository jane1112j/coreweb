import type { IWalletProvider } from '@/shared/domain/providers'
import { getBLS } from '@metanodejs/bls-crypto'
import type { IUseCase } from '@metanodejs/fiai-sdk'

export interface CreateSignRequest {
  address: string
  message: string
  isHex: boolean
}

export interface CreateSignResponse {
  sign: string
}

export class CreateSignUseCase implements IUseCase<CreateSignRequest, CreateSignResponse> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(params: CreateSignRequest): Promise<CreateSignResponse> {
    const { address, message, isHex } = params
    if (!address) {
      throw new Error('Address is required')
    }
    if (!message) {
      throw new Error('Message is required')
    }

    const privateKey = await this.walletProvider.getPrivateKey(address)
    const blsLib = getBLS()
    const { sign } = blsLib.sign(privateKey, message, isHex)

    return {
      sign: sign.toLowerCase(),
    }
  }
}

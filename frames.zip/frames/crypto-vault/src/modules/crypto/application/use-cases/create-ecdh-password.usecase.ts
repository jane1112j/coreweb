import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IEcdhService } from '../../domain/services'

export interface CreateECDHPasswordRequest {
  address: string
  publicKey: string
}

export interface CreateECDHPasswordResponse {
  password: string
}

export class CreateECDHPasswordUseCase implements IUseCase<
  CreateECDHPasswordRequest,
  CreateECDHPasswordResponse
> {
  constructor(private readonly ecdhService: IEcdhService) {}

  async execute(params: CreateECDHPasswordRequest): Promise<CreateECDHPasswordResponse> {
    const { address, publicKey } = params
    const sharedKey = await this.ecdhService.getSharedKey(address, publicKey)
    return {
      password: sharedKey,
    }
  }
}

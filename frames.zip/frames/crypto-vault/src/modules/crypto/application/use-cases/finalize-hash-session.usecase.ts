import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IStreamingHashService } from '../../domain/services'

export interface FinalizeHashSessionRequest {
  sessionId: string
}

export interface FinalizeHashSessionResponse {
  hash: string
}

export class FinalizeHashSessionUseCase implements IUseCase<
  FinalizeHashSessionRequest,
  FinalizeHashSessionResponse
> {
  constructor(private readonly streamingHashService: IStreamingHashService) {}

  execute(params: FinalizeHashSessionRequest): FinalizeHashSessionResponse {
    const { sessionId } = params
    const hash = this.streamingHashService.finalize(sessionId)
    return { hash }
  }
}

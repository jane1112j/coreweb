import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IAesService } from '../../domain/services'

export interface DecryptAesGCMRequest {
  sharedSecret: string
  encrypted: string
}

export interface DecryptAesGCMResponse {
  result: string
  resultUtf8: string
}

export class DecryptAesGCMUseCase implements IUseCase<DecryptAesGCMRequest, DecryptAesGCMResponse> {
  constructor(private readonly aesService: IAesService) {}

  async execute(params: DecryptAesGCMRequest): Promise<DecryptAesGCMResponse> {
    const { sharedSecret, encrypted } = params

    if (!sharedSecret) throw new Error('sharedSecret is required')
    if (!encrypted) throw new Error('encrypted is required')

    const decryptedResult = await this.aesService.decryptGcm(sharedSecret, encrypted)

    return decryptedResult
  }
}

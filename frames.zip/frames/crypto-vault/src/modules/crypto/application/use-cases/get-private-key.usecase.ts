import type { IWalletProvider } from '@/shared/domain/providers'
import type { IUseCase } from '@metanodejs/fiai-sdk'

export interface GetPrivateKeyRequest {
  address: string
}

export interface GetPrivateKeyResponse {
  privateKey: string
}

export class GetPrivateKeyUseCase implements IUseCase<GetPrivateKeyRequest, GetPrivateKeyResponse> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(params: GetPrivateKeyRequest): Promise<GetPrivateKeyResponse> {
    const { address } = params
    if (!address) {
      throw new Error('Address is required')
    }

    // 1. Lấy private key thông qua Provider (Đã được decouple khỏi module Wallet)
    const privateKey = await this.walletProvider.getPrivateKey(address)
    return { privateKey }
  }
}

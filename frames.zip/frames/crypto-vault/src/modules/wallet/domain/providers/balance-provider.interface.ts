export interface BalanceInfo {
  address: string
  balance: string
  pendingBalance: string
}

export interface IBalanceProvider {
  getBalance(address: string): Promise<string>
  getBalanceByAddress(addresses: string[]): Promise<BalanceInfo[]>
}

import type { Wallet } from '../types'

export interface IWalletRepository {
  save(wallet: Wallet): Promise<void>
  findById(address: string): Promise<Wallet | undefined>
  findAll(): Promise<Wallet[]>
  findHidden(): Promise<Wallet | undefined>
  delete(address: string): Promise<void>
  update(address: string, updates: Partial<Wallet>): Promise<void>
}

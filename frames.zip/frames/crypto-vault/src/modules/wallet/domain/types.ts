export interface WalletSecret {
  privateKey: string
  seed: string
  publicKey: string
}

export interface Wallet {
  address: string
  name: string
  type: string
  encryptedSecret: ArrayBuffer
  iv: Uint8Array
  backgroundImage: string
  isHidden: number // 0: public, 1: hidden (Dùng number để IndexedDB index hoạt động ổn định)
  lastDeviceKey: string
  lastHash: string
  totalBalanceString: string
  createdAt: number
}

/**
 * Kiểu dữ liệu trả về cho Host (không chứa khóa bí mật)
 */
export interface WalletResponse {
  address: string
  name: string
  type: string
  totalBalanceString: string
  createdAt: number
  lastDeviceKey: string
  lastHash: string
}

export interface DecryptedWalletResponse extends WalletResponse {
  secret: WalletSecret
}

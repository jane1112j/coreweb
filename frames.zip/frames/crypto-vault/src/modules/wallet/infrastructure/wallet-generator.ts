import type { ISeedService } from '@/shared/domain/services/seed-service.interface'
import { getBLS } from '@metanodejs/bls-crypto'
import { utils } from '@metanodejs/fiai-sdk'

export interface GeneratedWallet {
  address: string
  privateKey: string
  publicKey: string
  seed: string
  type: string
}

export class WalletGenerator {
  constructor(private readonly seedService: ISeedService) {}

  /**
   * Tạo ví sử dụng keccak256 từ chuỗi seed phrase
   */
  public generate(seed?: string[]): GeneratedWallet {
    const finalMnemonic = (seed ?? this.seedService.generateSeed()).join('-')
    let { hash: privateKey } = getBLS().keccak256(finalMnemonic)

    const firstByteValue = parseInt(privateKey.slice(0, 2), 16)
    if (firstByteValue >= 114) {
      privateKey = `72${privateKey.slice(2)}`
    }

    return this.buildWallet(privateKey, finalMnemonic)
  }

  /**
   * Tạo ví từ Private Key có sẵn
   */
  public fromPrivateKey(privateKey: string): GeneratedWallet {
    const normalizedKey = privateKey.toLowerCase().replace(/^0x/, '')
    return this.buildWallet(normalizedKey, '')
  }

  /**
   * Hàm hỗ trợ tạo payload wallet từ private key
   */
  private buildWallet(privateKey: string, seed: string): GeneratedWallet {
    const bls = getBLS()
    const objKey = bls.getKeyPair(privateKey)

    // CRITICAL: Dùng BLS keypair (objKey) để ký, KHÔNG dùng ECDH keypair
    // ECDH key chỉ dùng để derive address từ public key
    const ecdhKey = bls.ec_pubkey_create(objKey.private_key, true)
    const publicKeyECDH = ecdhKey.public_key

    const xCoordinate = publicKeyECDH.substring(2)
    const { hash: hashPk } = bls.keccak256(xCoordinate, 1)
    const address = hashPk.slice(-40)

    return {
      address: utils.formatAddress(address.toLowerCase()),
      privateKey: objKey.private_key.toLowerCase(),
      publicKey: objKey.public_key.toLowerCase(),
      seed,
      type: 'bls',
    }
  }
}

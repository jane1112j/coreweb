import { decryptPayload, utils } from '@metanodejs/fiai-sdk'
import type { IWalletProvider } from '@shared/domain/providers/wallet-provider.interface'
import type { SecurityProvider } from '@shared/infrastructure/security'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { DecryptedWalletResponse, WalletSecret } from '../../domain/types'
import { getHiddenWalletMasterKey } from '../helpers'

/**
 * Adapter giúp module Crypto có thể lấy Private Key mà không cần phụ thuộc trực tiếp
 * vào cấu trúc UseCase của module Wallet.
 */
export class WalletProviderAdapter implements IWalletProvider {
  private decryptedCache = new Map<string, { wallet: DecryptedWalletResponse; expiresAt: number }>()
  private readonly CACHE_TTL_MS = 60000 // Cache for 1 minute

  constructor(
    private readonly walletRepo: IWalletRepository,
    private readonly securityProvider: SecurityProvider,
  ) {}

  async getDecryptedWallet(address: string): Promise<DecryptedWalletResponse> {
    if (!address) {
      throw new Error('Address is required')
    }

    const formattedAddress = utils.formatAddress(address)
    const now = Date.now()

    const cached = this.decryptedCache.get(formattedAddress)
    if (cached && cached.expiresAt > now) {
      return cached.wallet
    }

    const wallet = await this.walletRepo.findById(formattedAddress)
    if (!wallet) {
      throw new Error('Wallet not found')
    }

    let currentMasterKey: CryptoKey
    if (wallet.isHidden === 1) {
      currentMasterKey = await getHiddenWalletMasterKey()
    } else {
      let master = this.securityProvider.ensureMasterKey({})
      if (!master) {
        master = await this.securityProvider.unlock()
      }
      currentMasterKey = master
    }

    const secret = await decryptPayload<WalletSecret>(
      currentMasterKey,
      wallet.encryptedSecret,
      wallet.iv,
    )

    const decryptedWallet = {
      address: utils.remove0x(wallet.address),
      name: wallet.name,
      type: wallet.type,
      totalBalanceString: wallet.totalBalanceString,
      createdAt: wallet.createdAt,
      lastDeviceKey: wallet.lastDeviceKey,
      lastHash: wallet.lastHash,
      secret,
    }

    this.decryptedCache.set(formattedAddress, {
      wallet: decryptedWallet,
      expiresAt: now + this.CACHE_TTL_MS,
    })

    return decryptedWallet
  }

  async getPrivateKey(address: string): Promise<string> {
    const result = await this.getDecryptedWallet(address)
    return result.secret.privateKey
  }

  async getSeedPhrase(address: string): Promise<string> {
    const result = await this.getDecryptedWallet(address)
    return result.secret.seed
  }

  clearCache(): void {
    this.decryptedCache.clear()
  }
}

import type { FrameClient } from '@metanodejs/fiai-sdk'
import type {
  IBalanceProvider,
  BalanceInfo,
} from '../../domain/providers/balance-provider.interface'

export class FrameBalanceAdapter implements IBalanceProvider {
  constructor(private readonly client: FrameClient) {}

  async getBalance(address: string): Promise<string> {
    const balanceInfo = await this.client.call<{ balance?: string }>('getBalance', { address })
    return balanceInfo?.balance || '0'
  }

  async getBalanceByAddress(addresses: string[]): Promise<BalanceInfo[]> {
    return this.client.call<BalanceInfo[]>('getBalanceByAddress', { addresses })
  }
}

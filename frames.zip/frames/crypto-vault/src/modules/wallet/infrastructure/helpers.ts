import { deriveKeyFromPassword } from '@metanodejs/fiai-sdk'

let cachedHiddenWalletMasterKey: CryptoKey | null = null

/**
 * Sinh khóa Master Key tĩnh cho ví ẩn (Hidden Wallet).
 * Sử dụng biến môi trường VITE_STATIC_PASS hoặc chuỗi secret mặc định fallback.
 */
export async function getHiddenWalletMasterKey(): Promise<CryptoKey> {
  if (cachedHiddenWalletMasterKey) {
    return cachedHiddenWalletMasterKey
  }
  const staticPass =
    import.meta.env.VITE_STATIC_PASS ??
    '9d8cd8824fbd10f4d0628a2578cf37dbc1c85260090a436cb8d9506955802441'
  const staticSalt = new Uint8Array(16).fill(0x55)
  cachedHiddenWalletMasterKey = await deriveKeyFromPassword(staticPass, staticSalt)
  return cachedHiddenWalletMasterKey
}


export const WALLET_NAME_REGEX = /^[\p{L}0-9 _.-]{1,32}$/u

export function validateWalletName(name: string): void {
  const normalizedName = name.trim()

  if (!normalizedName || !WALLET_NAME_REGEX.test(normalizedName)) {
    throw new Error(
      'Invalid wallet name. Allowed 1-32 characters: letters, numbers, spaces, _, ., -',
    )
  }
}

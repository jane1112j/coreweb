import { db } from '@shared/infrastructure/persistence/app-database'
import type { Wallet } from '../../domain/types'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'

export class DexieWalletRepository implements IWalletRepository {
  async save(wallet: Wallet): Promise<void> {
    await db.wallets.put(wallet)
  }

  async findById(address: string): Promise<Wallet | undefined> {
    return db.wallets.get(address)
  }

  async findAll(): Promise<Wallet[]> {
    return db.wallets.toArray()
  }

  async findHidden(): Promise<Wallet | undefined> {
    return db.wallets.where('isHidden').equals(1).first()
  }

  async delete(address: string): Promise<void> {
    await db.wallets.delete(address)
  }

  async update(address: string, updates: Partial<Wallet>): Promise<void> {
    await db.wallets.update(address, updates)
  }
}

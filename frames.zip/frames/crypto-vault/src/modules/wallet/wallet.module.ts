import { VaultActions } from '@/core/actions'
import {
  GenericActionHandler,
  type ApplicationActionHandler,
  type FrameClient,
} from '@metanodejs/fiai-sdk'
import type { SecurityProvider } from '@shared/infrastructure/security'
import type { WalletEventProvider } from './application/events/wallet-event.provider'
import * as UseCases from './application/use-cases'
import { storageService } from '@shared/infrastructure/services/storage.service'
import { seedService } from '@shared/infrastructure/services/seed.service'
import { WalletProviderAdapter } from './infrastructure/adapters/wallet-provider.adapter'
import { FrameBalanceAdapter } from './infrastructure/adapters/frame-balance.adapter'
import { DexieWalletRepository } from './infrastructure/persistence/dexie-wallet-repository'
import { WalletGenerator } from './infrastructure/wallet-generator'
import type { IWalletProvider } from '@/shared/domain/providers'

export class WalletModule {
  private readonly walletProvider: WalletProviderAdapter
  private readonly walletGenerator = new WalletGenerator(seedService)
  private readonly walletRepository = new DexieWalletRepository()
  private readonly balanceProvider: FrameBalanceAdapter

  constructor(
    private readonly securityProvider: SecurityProvider,
    private readonly client: FrameClient,
    private readonly walletEventProvider: WalletEventProvider,
  ) {
    this.balanceProvider = new FrameBalanceAdapter(this.client)
    this.walletProvider = new WalletProviderAdapter(this.walletRepository, this.securityProvider)
  }

  public getHandlers(): ApplicationActionHandler[] {
    const createWalletUC = new UseCases.CreateWalletUseCase(
      this.walletRepository,
      this.walletGenerator,
      this.securityProvider,
      this.walletEventProvider,
    )
    const getWalletsUC = new UseCases.GetWalletsUseCase(this.walletRepository, this.balanceProvider)
    const deleteWalletUC = new UseCases.DeleteWalletUseCase(this.walletRepository)
    const backupWalletUC = new UseCases.BackupWalletUseCase(
      this.walletProvider,
      this.securityProvider,
    )
    const updateWalletUC = new UseCases.UpdateWalletInfoUseCase(this.walletRepository)
    const generateSeedUC = new UseCases.GetSeedUseCase(this.walletGenerator, seedService)
    const getHiddenWalletUC = new UseCases.GetHiddenWalletUseCase(this.walletRepository)
    const createHiddenWalletUC = new UseCases.CreateHiddenWalletUseCase(
      this.walletRepository,
      this.walletGenerator,
      this.securityProvider,
    )
    const getPublicKeyUC = new UseCases.GetPublicKeyUseCase(this.walletProvider)
    const getPublicWalletInfoUC = new UseCases.GetPublicWalletInfoUseCase(this.walletProvider)

    const createWalletFromPrivateKeyUC = new UseCases.CreateWalletFromPrivateKeyUseCase(
      this.walletRepository,
      this.walletGenerator,
      this.securityProvider,
      this.balanceProvider,
      this.walletEventProvider,
    )
    const setActiveWalletDappUC = new UseCases.SetActiveWalletDappUseCase(
      this.walletEventProvider,
      this.walletRepository,
      storageService,
    )
    const setSettingDappUC = new UseCases.SetSettingDappUseCase(storageService)
    const getSettingDappUC = new UseCases.GetSettingDappUseCase(storageService)
    const getActiveWalletDappUC = new UseCases.GetActiveWalletDappUseCase(
      this.walletRepository,
      storageService,
    )

    return [
      new GenericActionHandler(VaultActions.GET_ALL_WALLETS, getWalletsUC),
      new GenericActionHandler(VaultActions.CREATE_WALLET, createWalletUC),
      new GenericActionHandler(VaultActions.DELETE_WALLET, deleteWalletUC),
      new GenericActionHandler(VaultActions.BACKUP_WALLET, backupWalletUC),
      new GenericActionHandler<UseCases.UpdateWalletInfoRequest, UseCases.UpdateWalletInfoResponse>(
        VaultActions.UPDATE_WALLET_INFO,
        updateWalletUC,
      ),
      new GenericActionHandler(VaultActions.GET_SEED, generateSeedUC),
      new GenericActionHandler(VaultActions.GET_HIDDEN_WALLET, getHiddenWalletUC),
      new GenericActionHandler(VaultActions.CREATE_HIDDEN_WALLET, createHiddenWalletUC),
      new GenericActionHandler(VaultActions.GET_PUBLIC_KEY, getPublicKeyUC),
      new GenericActionHandler(VaultActions.GET_PUBLIC_WALLET_INFO, getPublicWalletInfoUC),
      new GenericActionHandler(VaultActions.GET_PUBLIC_KEY_FROM_DB, getPublicKeyUC),
      new GenericActionHandler(
        VaultActions.CREATE_WALLET_FROM_PRIVATE_KEY,
        createWalletFromPrivateKeyUC,
      ),
      new GenericActionHandler(VaultActions.SET_SETTING_DAPP, setSettingDappUC),
      new GenericActionHandler(VaultActions.GET_SETTING_DAPP, getSettingDappUC),
      new GenericActionHandler(VaultActions.SET_DAPP_SETTINGS, setSettingDappUC),
      new GenericActionHandler(VaultActions.GET_DAPP_SETTINGS, getSettingDappUC),
      new GenericActionHandler(VaultActions.SET_ACTIVE_WALLET_DAPP, setActiveWalletDappUC),
      new GenericActionHandler(VaultActions.GET_ACTIVE_WALLET_DAPP, getActiveWalletDappUC),
    ]
  }

  public getWalletProvider(): IWalletProvider {
    return this.walletProvider
  }
}

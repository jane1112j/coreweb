import type { FrameClient } from '@metanodejs/fiai-sdk'

export class WalletEventProvider {
  constructor(private readonly frameClient: FrameClient) {}

  public emitSetActiveWallet(address: string) {
    void this.frameClient.emit('onSetActiveWallet', { address })
  }

  public emitNewWallet(address: string) {
    void this.frameClient.emit('onNewWallet', { address })
  }
}

import { type IUseCase, utils } from '@metanodejs/fiai-sdk'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletResponse, Wallet } from '../../domain/types'

export interface UpdateWalletInfoRequest extends Partial<WalletResponse> {
  name?: string
  address: string
  backgroundImage?: string
}

export interface UpdateWalletInfoResponse {
  success: boolean
}

export class UpdateWalletInfoUseCase implements IUseCase<
  UpdateWalletInfoRequest,
  UpdateWalletInfoResponse
> {
  constructor(private readonly walletRepo: IWalletRepository) {}

  async execute(params: UpdateWalletInfoRequest): Promise<UpdateWalletInfoResponse> {
    const address = utils.formatAddress(params.address)
    const wallet = await this.walletRepo.findById(address)
    if (!wallet) {
      throw new Error('Wallet not found')
    }

    const { name, type, totalBalanceString, lastDeviceKey, lastHash, backgroundImage } = params

    const updates: Partial<Wallet> = {}
    if (name !== undefined) updates.name = name
    if (type !== undefined) updates.type = type
    if (totalBalanceString !== undefined) updates.totalBalanceString = totalBalanceString
    if (lastDeviceKey !== undefined) updates.lastDeviceKey = lastDeviceKey
    if (lastHash !== undefined) updates.lastHash = lastHash
    if (backgroundImage !== undefined) updates.backgroundImage = backgroundImage

    await this.walletRepo.update(address, updates)
    return { success: true }
  }
}

import { type IUseCase, utils } from '@metanodejs/fiai-sdk'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'

export interface DeleteWalletRequest {
  address: string
}

export class DeleteWalletUseCase implements IUseCase<DeleteWalletRequest, { success: boolean }> {
  constructor(private readonly walletRepo: IWalletRepository) {}

  async execute({ address }: DeleteWalletRequest): Promise<{ success: boolean }> {
    await this.walletRepo.delete(utils.formatAddress(address))
    return { success: true }
  }
}

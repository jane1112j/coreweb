import { encryptPayload, type IUseCase } from '@metanodejs/fiai-sdk'
import type { WalletResponse, WalletSecret } from '../../domain/types'
import type { SecurityProvider } from '@shared/infrastructure/security'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletGenerator } from '../../infrastructure/wallet-generator'
import { utils } from '@metanodejs/fiai-sdk'
import type { WalletEventProvider } from '../events/wallet-event.provider'
import type { IBalanceProvider } from '../../domain/providers/balance-provider.interface'
import { validateWalletName } from '../../infrastructure/helpers'
export interface CreateWalletFromPrivateKeyRequest {
  privateKey: string
  backgroundImage?: string
  name: string
}

export class CreateWalletFromPrivateKeyUseCase implements IUseCase<
  CreateWalletFromPrivateKeyRequest,
  WalletResponse
> {
  constructor(
    private readonly walletRepo: IWalletRepository,
    private readonly walletGenerator: WalletGenerator,
    private readonly securityProvider: SecurityProvider,
    private readonly balanceProvider: IBalanceProvider,
    private readonly walletEventProvider: WalletEventProvider,
  ) {}

  async execute(params: CreateWalletFromPrivateKeyRequest): Promise<WalletResponse> {
    try {
      const { privateKey, backgroundImage, name } = params

      if (!privateKey) {
        throw new Error('Private key is required')
      }

      const nameWallet = name || `wallet_${Date.now()}`
      validateWalletName(nameWallet)

      // 1. Đảm bảo đã unlock (Lấy Master Key)
      let currentMasterKey = this.securityProvider.ensureMasterKey({})

      if (!currentMasterKey) {
        currentMasterKey = await this.securityProvider.unlock()
      }

      // 2. Tạo ví từ private key
      const generated = this.walletGenerator.fromPrivateKey(privateKey)

      const formattedAddress = utils.formatAddress(generated.address)
      const existingWallet = await this.walletRepo.findById(formattedAddress)
      if (existingWallet) {
        throw new Error('Wallet already exists')
      }

      // 3. Chuẩn bị dữ liệu bí mật để mã hóa
      const secret: WalletSecret = {
        privateKey: generated.privateKey,
        seed: generated.seed,
        publicKey: generated.publicKey,
      }

      // 4. Mã hóa Secret bằng Master Key
      const { ciphertext, iv } = await encryptPayload(currentMasterKey, secret)

      // Fetch initial balance
      let initialBalance = '0'
      try {
        initialBalance = await this.balanceProvider.getBalance(generated.address)
      } catch (error) {
        console.error('[CreateWalletFromPrivateKeyUseCase] Failed to fetch initial balance:', error)
      }
      // 5. Lưu vào Repository (Dexie)
      const createdAt = Date.now()
      await this.walletRepo.save({
        address: utils.formatAddress(generated.address),
        name: nameWallet,
        type: generated.type,
        encryptedSecret: ciphertext,
        iv: iv,
        backgroundImage: backgroundImage || '',
        isHidden: 0,
        lastDeviceKey: '0000000000000000000000000000000000000000000000000000000000000000',
        lastHash: '0000000000000000000000000000000000000000000000000000000000000000',
        totalBalanceString: initialBalance,
        createdAt,
      })

      this.walletEventProvider.emitNewWallet(utils.remove0x(generated.address))

      return {
        address: utils.remove0x(generated.address),
        type: generated.type,
        name: nameWallet,
        totalBalanceString: initialBalance,
        lastDeviceKey: '0000000000000000000000000000000000000000000000000000000000000000',
        lastHash: '0000000000000000000000000000000000000000000000000000000000000000',
        createdAt,
      }
    } catch (error) {
      console.error('[CREATE WALLET FROM PRIVATE KEY USECASE] - ERROR', error)
      throw error
    }
  }
}

import { decryptPayload, utils, type IUseCase } from '@metanodejs/fiai-sdk'
import type { SecurityProvider } from '@shared/infrastructure/security'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { DecryptedWalletResponse, WalletSecret } from '../../domain/types'
import { getHiddenWalletMasterKey } from '../../infrastructure/helpers'
export interface GetDecryptedWalletParams {
  address: string
}

export class GetDecryptedWalletUseCase implements IUseCase<
  GetDecryptedWalletParams,
  DecryptedWalletResponse
> {
  constructor(
    private readonly walletRepo: IWalletRepository,
    private readonly securityProvider: SecurityProvider,
  ) {}

  async execute(params: GetDecryptedWalletParams): Promise<DecryptedWalletResponse> {
    const { address } = params

    if (!address) {
      throw new Error('Address is required')
    }
    // 1. Tìm ví trong repository trước để xác định phân loại bảo mật

    const wallet = await this.walletRepo.findById(utils.formatAddress(address))
    if (!wallet) {
      throw new Error('Wallet not found')
    }

    // 2. Xác định Master Key tương ứng
    let currentMasterKey: CryptoKey
    if (wallet.isHidden === 1) {
      // Ví ẩn: Giải mã mượt mà không yêu cầu tương tác sinh trắc học/mật khẩu
      currentMasterKey = await getHiddenWalletMasterKey()
    } else {
      // Ví thông thường: Bắt buộc xác thực bảo mật người dùng
      let master = this.securityProvider.ensureMasterKey({})
      if (!master) {
        master = await this.securityProvider.unlock()
      }
      currentMasterKey = master
    }
    // 3. Giải mã bí mật
    const secret = await decryptPayload<WalletSecret>(
      currentMasterKey,
      wallet.encryptedSecret,
      wallet.iv,
    )
    // 4. Trả về thông tin ví kèm theo bí mật đã giải mã
    return {
      address: utils.remove0x(wallet.address),
      name: wallet.name,
      type: wallet.type,
      totalBalanceString: wallet.totalBalanceString,
      createdAt: wallet.createdAt,
      lastDeviceKey: wallet.lastDeviceKey,
      lastHash: wallet.lastHash,
      secret,
    }
  }
}

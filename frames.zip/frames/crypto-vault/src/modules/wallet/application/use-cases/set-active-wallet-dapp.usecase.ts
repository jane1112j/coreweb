import { utils, type IUseCase } from '@metanodejs/fiai-sdk'
import type { IStorageService } from '@/shared/domain/services/storage-service.interface'
import type { WalletEventProvider } from '../events/wallet-event.provider'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import { writeDappSettings } from './dapp-settings'

export interface SetActiveWalletDappRequest {
  address?: string
  domain: string
}

export class SetActiveWalletDappUseCase implements IUseCase<SetActiveWalletDappRequest, boolean> {
  constructor(
    private readonly walletEventProvider: WalletEventProvider,
    private readonly walletRepo: IWalletRepository,
    private readonly storageService: IStorageService,
  ) {}

  async execute(request: SetActiveWalletDappRequest): Promise<boolean> {
    try {
      const { address, domain } = request
      if (!domain) throw new Error('Domain is required')
      if (!address) {
        await writeDappSettings(this.storageService, domain, { address: null })
        return true
      }
      const wallet = await this.walletRepo.findById(utils.formatAddress(address))

      if (!wallet) {
        throw new Error('Wallet not found')
      }

      await writeDappSettings(this.storageService, domain, {
        address: utils.formatAddress(address),
      })
      this.walletEventProvider.emitSetActiveWallet(address)
      return true
    } catch (error) {
      console.error('[SetActiveWalletUseCase] Error:', error)
      return false
    }
  }
}

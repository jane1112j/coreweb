import { utils, type IUseCase } from '@metanodejs/fiai-sdk'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletResponse } from '../../domain/types'

export class GetHiddenWalletUseCase implements IUseCase<void, WalletResponse | null> {
  constructor(private readonly walletRepo: IWalletRepository) {}

  async execute(_?: void): Promise<WalletResponse | null> {
    const hidden = await this.walletRepo.findHidden()
    if (!hidden) return null

    return {
      address: utils.remove0x(hidden.address),
      name: hidden.name,
      type: hidden.type,
      totalBalanceString: hidden.totalBalanceString,
      createdAt: hidden.createdAt,
      lastDeviceKey: hidden.lastDeviceKey,
      lastHash: hidden.lastHash,
    }
  }
}

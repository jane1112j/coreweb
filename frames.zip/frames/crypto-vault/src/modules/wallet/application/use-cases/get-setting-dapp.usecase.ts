import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IStorageService } from '@/shared/domain/services/storage-service.interface'
import { readDappSettings, DEFAULT_LANGUAGE, type DappSettings } from './dapp-settings'

export interface GetSettingDappRequest {
  domain: string
}

export interface GetSettingDappResponse extends DappSettings {
  language: 'vi' | 'en'
}

export class GetSettingDappUseCase
  implements IUseCase<GetSettingDappRequest, GetSettingDappResponse>
{
  constructor(private readonly storageService: IStorageService) {}

  async execute(request: GetSettingDappRequest): Promise<GetSettingDappResponse> {
    const settings = await readDappSettings(this.storageService, request.domain)

    return {
      ...settings,
      language: settings.language ?? DEFAULT_LANGUAGE,
    }
  }
}

import { utils, type IUseCase } from '@metanodejs/fiai-sdk'
import type { ISeedService } from '@/shared/domain/services/seed-service.interface'
import type { WalletGenerator } from '../../infrastructure/wallet-generator'

export interface GetSeedParams {
  lang?: string
  length?: number
}

export class GetSeedUseCase implements IUseCase<
  GetSeedParams,
  {
    listSeed: string[]
    address: string
  }
> {
  constructor(
    private readonly walletGenerator: WalletGenerator,
    private readonly seedService: ISeedService,
  ) {}
  execute(params: GetSeedParams): { listSeed: string[]; address: string } {
    const { lang = 'en', length = 24 } = params
    const listSeed = this.seedService.generateSeed(lang, length)
    const { address } = this.walletGenerator.generate(listSeed)
    return { listSeed, address: utils.remove0x(address) }
  }
}

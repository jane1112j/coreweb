import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IStorageService } from '@/shared/domain/services/storage-service.interface'
import { writeDappSettings, type DappSettings } from './dapp-settings'

export interface SetSettingDappRequest extends Partial<DappSettings> {
  domain: string
}

export interface SetSettingDappResponse {
  success: boolean
  settings?: DappSettings
}

export class SetSettingDappUseCase
  implements IUseCase<SetSettingDappRequest, SetSettingDappResponse>
{
  constructor(private readonly storageService: IStorageService) {}

  async execute(request: SetSettingDappRequest): Promise<SetSettingDappResponse> {
    try {
      const { domain, ...patch } = request
      const settings = await writeDappSettings(this.storageService, domain, patch)
      return { success: true, settings }
    } catch (error) {
      console.error('[SetSettingDappUseCase] Error:', error)
      return { success: false }
    }
  }
}

import { type IUseCase, utils } from '@metanodejs/fiai-sdk'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletResponse } from '../../domain/types'
import type {
  IBalanceProvider,
  BalanceInfo,
} from '../../domain/providers/balance-provider.interface'

export class GetWalletsUseCase implements IUseCase<void, WalletResponse[]> {
  constructor(
    private readonly walletRepo: IWalletRepository,
    private readonly balanceProvider: IBalanceProvider,
  ) {}

  async execute(_?: void): Promise<WalletResponse[]> {
    const wallets = await this.walletRepo.findAll()
    const activeWallets = wallets.filter((w) => !w.isHidden)

    if (activeWallets.length === 0) {
      return []
    }

    const addresses = activeWallets.map((w) => w.address)
    let balances: BalanceInfo[] = []

    try {
      balances = await this.balanceProvider.getBalanceByAddress(addresses)
    } catch (error) {
      console.error('[GetWalletsUseCase] Failed to fetch balances:', error)
    }

    const updatedWallets = await Promise.all(
      activeWallets.map(async (w) => {
        const balanceInfo = balances.find(
          (b) => utils.formatAddress(b.address) === utils.formatAddress(w.address),
        )
        const newBalance = balanceInfo
          ? balanceInfo.balance === '0'
            ? balanceInfo.pendingBalance
            : balanceInfo.balance
          : w.totalBalanceString

        if (newBalance && newBalance !== w.totalBalanceString) {
          try {
            await this.walletRepo.update(w.address, { totalBalanceString: newBalance })
            w.totalBalanceString = newBalance
          } catch (err) {
            console.error(
              `[GetWalletsUseCase] Failed to save updated balance for ${w.address}:`,
              err,
            )
          }
        }

        return {
          address: utils.remove0x(w.address),
          name: w.name,
          type: w.type,
          totalBalanceString: w.totalBalanceString,
          createdAt: w.createdAt,
          lastDeviceKey: w.lastDeviceKey,
          lastHash: w.lastHash,
        }
      }),
    )

    return updatedWallets
  }
}

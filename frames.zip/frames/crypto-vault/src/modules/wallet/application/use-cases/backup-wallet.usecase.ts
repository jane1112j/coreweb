import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IWalletProvider } from '@/shared/domain/providers/wallet-provider.interface'
import type { SecurityProvider } from '@shared/infrastructure/security'

export interface BackupWalletRequest {
  address: string
}

export interface BackupWalletResponse {
  address: string
  name: string
  privateKey: string
  seedPhrase: string
}

export class BackupWalletUseCase implements IUseCase<BackupWalletRequest, BackupWalletResponse> {
  constructor(
    private readonly walletProvider: IWalletProvider,
    private readonly securityProvider: SecurityProvider,
  ) {}

  async execute({ address }: BackupWalletRequest): Promise<BackupWalletResponse> {
    if (!address) {
      throw new Error('Address is required')
    }

    await this.securityProvider.forceUnlock()

    const wallet = await this.walletProvider.getDecryptedWallet(address)

    return {
      address: wallet.address,
      name: wallet.name,
      privateKey: wallet.secret.privateKey,
      seedPhrase: wallet.secret.seed ? wallet.secret.seed.split('-').join(' ') : '',
    }
  }
}

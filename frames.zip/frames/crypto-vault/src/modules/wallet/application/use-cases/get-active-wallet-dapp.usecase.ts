import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IStorageService } from '@/shared/domain/services/storage-service.interface'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletResponse } from '../../domain/types'
import { readDappSettings } from './dapp-settings'
import { utils } from '@metanodejs/fiai-sdk'

export interface GetActiveWalletDappRequest {
  domain: string
}

export type GetActiveWalletDappResponse = WalletResponse | { success: boolean }

export class GetActiveWalletDappUseCase implements IUseCase<
  GetActiveWalletDappRequest,
  GetActiveWalletDappResponse
> {
  constructor(
    private readonly walletRepository: IWalletRepository,
    private readonly storageService: IStorageService,
  ) {}

  async execute(params: GetActiveWalletDappRequest): Promise<GetActiveWalletDappResponse> {
    try {
      const { domain } = params
      if (!domain) throw new Error('Domain is required')
      const settings = await readDappSettings(this.storageService, domain)
      const activeWalletAddress = settings.address?.trim() ?? ''
      if (!activeWalletAddress) {
        return { success: false }
      }

      const wallet = await this.walletRepository.findById(utils.formatAddress(activeWalletAddress))
      if (wallet) {
        return {
          address: utils.remove0x(wallet.address),
          name: wallet.name,
          type: wallet.type,
          totalBalanceString: wallet.totalBalanceString,
          createdAt: wallet.createdAt,
          lastDeviceKey: wallet.lastDeviceKey,
          lastHash: wallet.lastHash,
        }
      }
      return { success: false }
    } catch {
      return { success: false }
    }
  }
}

import { utils } from '@metanodejs/fiai-sdk'
import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IWalletProvider } from '@/shared/domain/providers/wallet-provider.interface'
export interface GetPublicKeyParams {
  address: string
}

export class GetPublicKeyUseCase implements IUseCase<GetPublicKeyParams, { publicKey: string }> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(params: GetPublicKeyParams): Promise<{ publicKey: string }> {
    const address = utils.formatAddress(params.address)
    const result = await this.walletProvider.getDecryptedWallet(address)
    return {
      publicKey: result.secret.publicKey,
    }
  }
}

import { encryptPayload, utils, type IUseCase } from '@metanodejs/fiai-sdk'
import type { SecurityProvider } from '@shared/infrastructure/security'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletResponse, WalletSecret } from '../../domain/types'
import type { WalletGenerator } from '../../infrastructure/wallet-generator'
import type { WalletEventProvider } from '../events/wallet-event.provider'
import { validateWalletName } from '../../infrastructure/helpers'

export interface CreateWalletParams {
  name?: string
  backgroundImage?: string
  seed?: string[]
  isSaved?: boolean
}

export class CreateWalletUseCase implements IUseCase<CreateWalletParams, WalletResponse> {
  constructor(
    private readonly walletRepo: IWalletRepository,
    private readonly walletGenerator: WalletGenerator,
    private readonly securityProvider: SecurityProvider,
    private readonly walletEventProvider: WalletEventProvider,
  ) {}

  async execute(params: CreateWalletParams): Promise<WalletResponse> {
    try {
      const { name, seed, backgroundImage, isSaved = true } = params

      const nameWallet = name || `wallet_${Date.now()}`
      validateWalletName(nameWallet)

      if (seed && (!Array.isArray(seed) || seed.length !== 24)) {
        throw new Error('Seed must be an array of 24 words')
      }

      // 1. Đảm bảo đã unlock (Lấy Master Key)
      let currentMasterKey = this.securityProvider.ensureMasterKey({})

      if (!currentMasterKey) {
        currentMasterKey = await this.securityProvider.unlock()
      }

      // 2. Tạo ví (Nếu seed trống, generator sẽ tự gọi SeedService)
      const generated = this.walletGenerator.generate(seed)
      // 3. Chuẩn bị dữ liệu bí mật để mã hóa
      const secret: WalletSecret = {
        privateKey: generated.privateKey,
        seed: generated.seed,
        publicKey: generated.publicKey,
      }
      // 4. Mã hóa Secret bằng Master Key
      const { ciphertext, iv } = await encryptPayload(currentMasterKey, secret)

      // 5. Lưu vào Repository (Dexie)
      const createdAt = Date.now()
      if (isSaved) {
        await this.walletRepo.save({
          address: utils.formatAddress(generated.address),
          name: nameWallet,
          type: generated.type,
          encryptedSecret: ciphertext,
          iv: iv,
          backgroundImage: backgroundImage || '',
          isHidden: 0,
          lastDeviceKey: '0000000000000000000000000000000000000000000000000000000000000000',
          lastHash: '0000000000000000000000000000000000000000000000000000000000000000',
          totalBalanceString: '0',
          createdAt,
        })
      }

      this.walletEventProvider.emitNewWallet(utils.remove0x(generated.address))

      return {
        address: utils.remove0x(generated.address),
        type: generated.type,
        name: nameWallet,
        totalBalanceString: '0',
        lastDeviceKey: '0000000000000000000000000000000000000000000000000000000000000000',
        lastHash: '0000000000000000000000000000000000000000000000000000000000000000',
        createdAt,
      }
    } catch (error) {
      console.error('[CREATE WALLTE USERCASE] - CREATE WALLET ERROR', error)
      throw error
    }
  }
}

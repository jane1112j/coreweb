import { utils } from '@metanodejs/fiai-sdk'
import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { IWalletProvider } from '@/shared/domain/providers/wallet-provider.interface'

export interface GetPublicWalletInfoParams {
  address: string
}

export class GetPublicWalletInfoUseCase implements IUseCase<
  GetPublicWalletInfoParams,
  { publicKey: string; lastDeviceKey: string; lastHash: string }
> {
  constructor(private readonly walletProvider: IWalletProvider) {}

  async execute(
    params: GetPublicWalletInfoParams,
  ): Promise<{ publicKey: string; lastDeviceKey: string; lastHash: string }> {
    const address = utils.formatAddress(params.address)
    const result = await this.walletProvider.getDecryptedWallet(address)
    return {
      publicKey: result.secret.publicKey,
      lastDeviceKey: result.lastDeviceKey,
      lastHash: result.lastHash,
    }
  }
}

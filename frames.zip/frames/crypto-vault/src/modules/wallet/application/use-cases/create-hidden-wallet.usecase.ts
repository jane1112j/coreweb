import { encryptPayload, type IUseCase, utils } from '@metanodejs/fiai-sdk'
import type { SecurityProvider } from '@shared/infrastructure/security'
import type { IWalletRepository } from '../../domain/repositories/wallet.repository'
import type { WalletGenerator } from '../../infrastructure/wallet-generator'
import type { WalletResponse, WalletSecret } from '../../domain/types'
import { getHiddenWalletMasterKey } from '../../infrastructure/helpers'

export interface CreateHiddenWalletParams {
  masterKey?: string
}

export class CreateHiddenWalletUseCase implements IUseCase<
  CreateHiddenWalletParams,
  WalletResponse | null
> {
  constructor(
    private readonly walletRepo: IWalletRepository,
    private readonly walletGenerator: WalletGenerator,
    private readonly securityProvider: SecurityProvider,
  ) {}

  async execute(params: CreateHiddenWalletParams): Promise<WalletResponse | null> {
    const existing = await this.walletRepo.findHidden()
    if (existing) {
      return {
        address: utils.remove0x(existing.address),
        name: existing.name,
        type: existing.type,
        totalBalanceString: existing.totalBalanceString,
        createdAt: existing.createdAt,
        lastDeviceKey: existing.lastDeviceKey,
        lastHash: existing.lastHash,
      }
    }

    // 2. Đảm bảo có Master Key (chỉ lấy cái đang có sẵn trong RAM)
    let currentMasterKey = this.securityProvider.ensureMasterKey({
      masterKey: params.masterKey,
    })

    if (!currentMasterKey) {
      // Tự động sinh Master Key tĩnh cho ví ẩn để không chặn luồng tải trang tự động
      currentMasterKey = await getHiddenWalletMasterKey()
    }

    if (!currentMasterKey) {
      throw new Error('Failed to ensure master key for hidden wallet')
    }

    // 3. Tạo ví mới (SeedService tự tạo 24 từ)
    const generated = this.walletGenerator.generate()

    // 4. Mã hóa Secret
    const secret: WalletSecret = {
      privateKey: generated.privateKey,
      seed: generated.seed,
      publicKey: generated.publicKey,
    }
    const { ciphertext, iv } = await encryptPayload(currentMasterKey, secret)

    // 5. Lưu với isHidden = 1 (hidden)
    const createdAt = Date.now()
    await this.walletRepo.save({
      address: utils.formatAddress(generated.address),
      name: '__hidden__',
      type: generated.type,
      encryptedSecret: ciphertext,
      iv: iv,
      backgroundImage: '',
      isHidden: 1,
      lastDeviceKey: '0000000000000000000000000000000000000000000000000000000000000000',
      lastHash: '0000000000000000000000000000000000000000000000000000000000000000',
      totalBalanceString: '0',
      createdAt,
    })

    return {
      address: utils.remove0x(generated.address),
      type: generated.type,
      name: '__hidden__',
      totalBalanceString: '0',
      lastDeviceKey: '0000000000000000000000000000000000000000000000000000000000000000',
      lastHash: '0000000000000000000000000000000000000000000000000000000000000000',
      createdAt,
    }
  }
}

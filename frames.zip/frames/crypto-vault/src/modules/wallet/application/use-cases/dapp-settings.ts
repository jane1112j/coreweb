import type { IStorageService } from '@/shared/domain/services/storage-service.interface'

export type SupportedLocale = 'vi' | 'en'

export interface DappSettings {
  language?: SupportedLocale
  address?: string | null
}

export const DEFAULT_LANGUAGE: SupportedLocale = 'vi'

const SUPPORTED_LOCALES: SupportedLocale[] = ['vi', 'en']

function getSettingsPath(domain: string): string {
  return `setting_${domain}.json`
}

function normalizeLocale(value: unknown): SupportedLocale | undefined {
  if (typeof value !== 'string') return undefined
  const normalized = value.trim().toLowerCase()
  return SUPPORTED_LOCALES.includes(normalized as SupportedLocale)
    ? (normalized as SupportedLocale)
    : undefined
}

function normalizeActiveWallet(value: unknown): string | null | undefined {
  if (value === null) return null
  if (typeof value !== 'string') return undefined
  const normalized = value.trim().toLowerCase()
  if (!normalized) return null
  return normalized.startsWith('0x') ? normalized.slice(2) : normalized
}

async function readStorageAsText(
  storageService: IStorageService,
  path: string,
): Promise<string | null> {
  const rawValue = await storageService.readFile(path)

  if (!rawValue) return null
  if (typeof rawValue === 'string') return rawValue
  if (rawValue instanceof Blob) return await rawValue.text()
  if (rawValue instanceof ArrayBuffer) return new TextDecoder().decode(rawValue)

  return null
}

function parseSettings(rawValue: string | null): DappSettings {
  if (!rawValue) return {}

  try {
    const parsed = JSON.parse(rawValue) as Record<string, unknown>
    return {
      language: normalizeLocale(parsed.language),
      address: normalizeActiveWallet(parsed.address),
    }
  } catch {
    return {}
  }
}

async function readLegacySettings(
  storageService: IStorageService,
  domain: string,
): Promise<DappSettings> {
  const [legacyLanguage, legacyActiveWallet] = await Promise.all([
    readStorageAsText(storageService, `language_${domain}.txt`),
    readStorageAsText(storageService, `active_wallet_${domain}.txt`),
  ])

  return {
    language: normalizeLocale(legacyLanguage ?? undefined),
    address: normalizeActiveWallet(legacyActiveWallet ?? undefined),
  }
}

export async function readDappSettings(
  storageService: IStorageService,
  domain: string,
): Promise<DappSettings> {
  if (!domain) throw new Error('Domain is required')

  const rawSettings = await readStorageAsText(storageService, getSettingsPath(domain))
  const parsedSettings = parseSettings(rawSettings)

  if (parsedSettings.language !== undefined || parsedSettings.address !== undefined) {
    return parsedSettings
  }

  return await readLegacySettings(storageService, domain)
}

export async function writeDappSettings(
  storageService: IStorageService,
  domain: string,
  patch: Partial<DappSettings>,
): Promise<DappSettings> {
  if (!domain) throw new Error('Domain is required')

  const currentSettings = await readDappSettings(storageService, domain)
  const nextSettings: DappSettings = { ...currentSettings }

  if ('language' in patch) {
    if (patch.language === undefined) {
      delete nextSettings.language
    } else {
      const normalizedLanguage = normalizeLocale(patch.language)
      if (!normalizedLanguage) {
        throw new Error('Locale must be either "vi" or "en"')
      }
      nextSettings.language = normalizedLanguage
    }
  }

  if ('address' in patch) {
    if (patch.address === undefined) {
      delete nextSettings.address
    } else {
      nextSettings.address = normalizeActiveWallet(patch.address) ?? null
    }
  }

  await storageService.writeFile(getSettingsPath(domain), JSON.stringify(nextSettings))

  return nextSettings
}

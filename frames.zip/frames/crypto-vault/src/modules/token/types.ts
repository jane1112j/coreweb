export interface Token {
  id?: number
  address: string // Token contract address
  symbol: string
  name: string
  decimals: number
  walletAddress: string // Owner wallet address
}

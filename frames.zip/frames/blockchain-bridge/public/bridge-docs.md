# Blockchain Bridge Module

The **Blockchain Bridge** acts as a secure middleware layer between the decentralized application and various blockchain networks. It manages low-level RPC communications, transaction encoding, and event subscriptions.

## Core Features

- **Transaction Orchestration**: Manages the full lifecycle of a transaction from encoding to broadcast.
- **Contract Interaction**: Provides high-level abstractions for reading from and writing to smart contracts.
- **Real-time Subscriptions**: Efficiently handles WebSocket-based event streams for specific contract addresses.
- **Protocol Buffers (Meta Proto)**: Uses optimized binary serialization for high-performance data transfer.

## Supported API Actions

| Action                | Description                                               | Parameters                                    |
| :-------------------- | :-------------------------------------------------------- | :-------------------------------------------- |
| `sendTransaction`     | Executes a contract call (read/write) or simple transfer. | `to`, `abiData`, `functionName`, `inputArray` |
| `getBalance`          | Retrieves the balance of the currently active wallet.     | None                                          |
| `getBalanceByAddress` | Retrieves the balance of a specific address.              | `address`                                     |
| `getBlockNumber`      | Retrieves the latest block number.                        | None                                          |
| `getBlockByNumber`    | Retrieves block details by its block number.              | `blockNumber`                                 |
| `searchTransactions`  | Searches for transactions using specific criteria.        | `offset`, `limit`, `queryString`              |
| `subscribeToAddress`  | Subscribes to events emitted by a specific address.       | `address`                                     |
| `ping`                | Checks the connectivity status of the bridge.             | None                                          |

## Technical Implementation

### Communication Layer

The bridge utilizes [`@metanodejs/fiai-sdk`](https://www.npmjs.com/package/@metanodejs/fiai-sdk) to handle secure message routing between the enclave and the decentralized application (dApp).

### RPC Provider

The bridge uses a **WsRpcProvider** connected to optimized Sequoia nodes via WebSockets, ensuring low-latency communication and instant event delivery.

### Security Model

The Bridge works in tandem with the **Crypto Vault**. It prepares transaction payloads but never touches private keys. Signing requests are forwarded back to the Vault through the SDK's secure routing system.

---

_Crafted with 🖤 by the Metanode Core Team_

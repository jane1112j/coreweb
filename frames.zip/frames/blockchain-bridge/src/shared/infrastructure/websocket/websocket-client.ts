export interface WebSocketMessage {
  id?: number
  jsonrpc?: string
  method?: string
  params?: any
  result?: any
  error?: {
    code: number
    message: string
  }
}

export type WebSocketEventListener = {
  open: () => void | Promise<void>
  close: () => void | Promise<void>
  message: (data: WebSocketMessage) => void
  error: (err: Event) => void
}

export class WebSocketClient {
  private ws: WebSocket | null = null
  private listeners: Partial<WebSocketEventListener> = {}
  private pendingQueue: string[] = []

  private reconnectTimer: ReturnType<typeof setTimeout> | null = null
  private retryCount = 0
  private isDestroyed = false

  private readonly BASE_DELAY = 1000
  private readonly MAX_DELAY = 30000

  constructor(private readonly url: string) {
    this.connect()
  }

  public registerListeners(listeners: Partial<WebSocketEventListener>) {
    this.listeners = { ...this.listeners, ...listeners }
  }

  private connect() {
    try {
      this.ws = new WebSocket(this.url)

      this.ws.onopen = async () => {
        console.warn('[WebSocketClient] Connected to', this.url)
        this.retryCount = 0

        if (this.listeners.open) {
          await this.listeners.open()
        }

        // Flush queued messages
        const queue = [...this.pendingQueue]
        this.pendingQueue = []
        for (const msg of queue) {
          this.ws?.send(msg)
        }
      }

      this.ws.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data) as WebSocketMessage
          if (this.listeners.message) {
            this.listeners.message(parsed)
          }
        } catch (e) {
          console.error('[WebSocketClient] Error parsing message:', e)
        }
      }

      this.ws.onerror = (error) => {
        console.error('[WebSocketClient] Error:', error)
        if (this.listeners.error) {
          this.listeners.error(error)
        }
      }

      this.ws.onclose = async () => {
        if (this.listeners.close) {
          await this.listeners.close()
        }
        this.scheduleReconnect()
      }
    } catch (err) {
      console.error('[WebSocketClient] Failed to initialize:', err)
      this.scheduleReconnect()
    }
  }

  private scheduleReconnect() {
    if (this.isDestroyed) return

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
    }

    // Exponential backoff with jitter
    const backoff = Math.min(this.BASE_DELAY * Math.pow(2, this.retryCount), this.MAX_DELAY)
    const jitter = Math.random() * 500 // up to 500ms jitter
    const delay = Math.floor(backoff + jitter)

    console.warn(`[WebSocketClient] Reconnecting in ${delay}ms (retry ${this.retryCount + 1})...`)
    this.reconnectTimer = setTimeout(() => {
      this.retryCount++
      this.connect()
    }, delay)
  }

  public destroy() {
    this.isDestroyed = true
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
    if (this.ws) {
      this.ws.onopen = null
      this.ws.onmessage = null
      this.ws.onerror = null
      this.ws.onclose = null
      this.ws.close()
      this.ws = null
    }
  }

  public send(message: unknown) {
    const payloadStr = JSON.stringify(message)
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      this.pendingQueue.push(payloadStr)
    } else {
      this.ws.send(payloadStr)
    }
  }

  public isConnected(): boolean {
    return !!this.ws && this.ws.readyState === WebSocket.OPEN
  }
}

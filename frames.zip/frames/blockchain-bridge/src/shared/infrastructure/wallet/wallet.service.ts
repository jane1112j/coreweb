import type { FrameClient } from '@metanodejs/fiai-sdk'

export class WalletService {
  constructor(private readonly client: FrameClient) {}

  async getPublicKey(address: string): Promise<{ publicKey: string }> {
    console.warn('[WalletService] getPublicKey', { address })
    return await this.client.call<{ publicKey: string }>('getPublicKey', { address })
  }

  async getPublicWalletInfo(
    address: string,
  ): Promise<{ lastDeviceKey: string; lastHash: string; publicKey: string }> {
    return await this.client.call<{ lastDeviceKey: string; lastHash: string; publicKey: string }>(
      'getPublicWalletInfo',
      { address },
    )
  }

  async signWithWallet(
    address: string,
    algorithm: string,
    payload: string,
  ): Promise<{ signature: string; algorithm: string; address: string }> {
    return await this.client.call<{ signature: string; algorithm: string; address: string }>(
      'signWithWallet',
      {
        address,
        payload,
        algorithm,
      },
    )
  }

  /**
   * Cập nhật lastHash và lastDeviceKey của wallet sau khi giao dịch thành công
   */
  async updateWalletInfo(params: {
    address: string
    lastHash?: string
    lastDeviceKey?: string
    totalBalanceString?: string
  }): Promise<void> {
    await this.client.call<{ success: boolean }>('updateWalletInfo', params)
  }

  async getPrivateKey(address: string): Promise<{ privateKey: string }> {
    return await this.client.call<{ privateKey: string }>('getPrivateKey', {
      address,
    })
  }

  async getHiddenWallet(): Promise<{ address: string }> {
    return await this.client.call('getHiddenWallet', {})
  }
}

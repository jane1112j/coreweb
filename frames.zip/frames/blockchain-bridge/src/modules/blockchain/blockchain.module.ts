import { BridgeActions } from '@/core/actions'
import type { WalletService } from '@/shared/infrastructure/wallet'
import {
  GenericActionHandler,
  type ApplicationActionHandler,
  type FrameClient,
} from '@metanodejs/fiai-sdk'
import {
  ExecuteContractUseCase,
  GetBalanceByAddressUseCase,
  GetBalanceUseCase,
  GetBlockByNumberUseCase,
  GetBlockNumberUseCase,
  ReadContractUseCase,
  SearchTransactionsUseCase,
  SendTransactionUseCase,
  SubscribeToAddressUseCase,
  TransactionMonitorService,
} from './application'
import { TransactionPolicyService, TransactionSigningService } from './domain'
import {
  HttpRpcClient,
  RpcAccountGateway,
  RpcBlockGateway,
  RpcContractGateway,
  RpcTransactionGateway,
  TransactionAssembler,
  TransactionDecoder,
  TransactionEncoder,
  WsRpcClient,
} from './infrastructure'

export interface BlockchainModuleDeps {
  rpcUrl: string
  wsUrl: string
  chainId: number
  walletService: WalletService
  client: FrameClient
}

export class BlockchainModule {
  private readonly rpcClient: HttpRpcClient
  private readonly wsRpcClient: WsRpcClient
  private readonly accountGateway: RpcAccountGateway
  private readonly transactionGateway: RpcTransactionGateway
  private readonly contractGateway: RpcContractGateway
  private readonly blockGateway: RpcBlockGateway

  private readonly policyService: TransactionPolicyService
  private readonly signingService: TransactionSigningService

  private readonly encoder: TransactionEncoder
  private readonly decoder: TransactionDecoder
  private readonly assembler: TransactionAssembler
  private readonly monitorService: TransactionMonitorService

  constructor(private readonly deps: BlockchainModuleDeps) {
    // 1. Initialize RPC client
    this.rpcClient = new HttpRpcClient(this.deps.rpcUrl, this.deps.chainId)
    this.wsRpcClient = new WsRpcClient(this.deps.wsUrl, this.deps.client)

    // 2. Initialize gateways
    this.accountGateway = new RpcAccountGateway(this.rpcClient)
    this.transactionGateway = new RpcTransactionGateway(this.rpcClient)
    this.contractGateway = new RpcContractGateway(this.rpcClient)
    this.blockGateway = new RpcBlockGateway(this.rpcClient)

    // 3. Initialize domain services
    this.policyService = new TransactionPolicyService()
    this.signingService = new TransactionSigningService(this.deps.walletService)

    // 4. Initialize protocol encoders/decoders/assembler
    this.encoder = new TransactionEncoder()
    this.decoder = new TransactionDecoder()
    this.assembler = new TransactionAssembler(this.policyService, this.encoder)

    // 5. Initialize application services
    this.monitorService = new TransactionMonitorService(this.transactionGateway)
  }

  public getHandlers(): ApplicationActionHandler[] {
    const readContractUC = new ReadContractUseCase(
      this.contractGateway,
      this.policyService,
      this.encoder,
      this.decoder,
    )
    const executeContractUC = new ExecuteContractUseCase(
      this.accountGateway,
      this.transactionGateway,
      this.blockGateway,
      this.policyService,
      this.signingService,
      this.assembler,
      this.deps.walletService,
      this.monitorService,
      this.encoder,
      readContractUC,
    )

    return [
      new GenericActionHandler(
        BridgeActions.SEND_TRANSACTION,
        new SendTransactionUseCase(readContractUC, executeContractUC),
      ),
      new GenericActionHandler(
        BridgeActions.SUBSCRIBE_TO_ADDRESS,
        new SubscribeToAddressUseCase(this.wsRpcClient),
      ),
      new GenericActionHandler(
        BridgeActions.GET_BLOCK_NUMBER,
        new GetBlockNumberUseCase(this.blockGateway),
      ),
      new GenericActionHandler(
        BridgeActions.GET_BLOCK_BY_NUMBER,
        new GetBlockByNumberUseCase(this.blockGateway),
      ),
      new GenericActionHandler(
        BridgeActions.SEARCH_TRANSACTIONS,
        new SearchTransactionsUseCase(this.transactionGateway),
      ),
      new GenericActionHandler(
        BridgeActions.GET_BALANCE_BY_ADDRESS,
        new GetBalanceByAddressUseCase(this.accountGateway),
      ),
      new GenericActionHandler(
        BridgeActions.GET_BALANCE,
        new GetBalanceUseCase(this.accountGateway),
      ),
    ]
  }
}

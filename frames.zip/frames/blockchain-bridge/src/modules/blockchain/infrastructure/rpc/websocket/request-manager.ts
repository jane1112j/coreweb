export class RequestManager {
  private nextId = 1
  private requestHandlers: Map<
    number,
    {
      resolve: (val: any) => void
      reject: (err: any) => void
      timer: ReturnType<typeof setTimeout>
    }
  > = new Map()

  /**
   * Registers a new JSON-RPC request and returns the request ID and its Promise.
   * If not resolved within timeoutMs, the promise is rejected.
   */
  public createRequest<T>(timeoutMs = 15000): { id: number; promise: Promise<T> } {
    const id = this.nextId++
    const promise = new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        if (this.requestHandlers.has(id)) {
          this.requestHandlers.delete(id)
          reject(new Error(`WS Request (ID: ${id}) timed out after ${timeoutMs}ms`))
        }
      }, timeoutMs)

      this.requestHandlers.set(id, { resolve, reject, timer })
    })

    return { id, promise }
  }

  /**
   * Resolves a pending request by ID.
   */
  public resolveRequest(id: number, result: any) {
    const handler = this.requestHandlers.get(id)
    if (handler) {
      clearTimeout(handler.timer)
      this.requestHandlers.delete(id)
      handler.resolve(result)
    }
  }

  /**
   * Rejects a pending request by ID.
   */
  public rejectRequest(id: number, error: Error) {
    const handler = this.requestHandlers.get(id)
    if (handler) {
      clearTimeout(handler.timer)
      this.requestHandlers.delete(id)
      handler.reject(error)
    }
  }

  /**
   * Checks if a request ID is currently pending.
   */
  public hasRequest(id: number): boolean {
    return this.requestHandlers.has(id)
  }

  /**
   * Rejects all pending requests with a specific reason.
   * Useful when the connection is closed or client is destroyed.
   */
  public rejectAll(reason: Error) {
    for (const handler of this.requestHandlers.values()) {
      clearTimeout(handler.timer)
      handler.reject(reason)
    }
    this.requestHandlers.clear()
  }
}

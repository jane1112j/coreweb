export interface RpcClient {
  request<T>(method: string, params?: unknown[]): Promise<T>
  getChainId(): number
}

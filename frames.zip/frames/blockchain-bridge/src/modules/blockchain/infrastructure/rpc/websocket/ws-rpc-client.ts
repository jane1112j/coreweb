import { WebSocketClient, type WebSocketMessage } from '@/shared/infrastructure/websocket'
import { utils, type FrameClient } from '@metanodejs/fiai-sdk'
import { RequestManager } from './request-manager'

export enum WsState {
  IDLE = 'IDLE',
  CONNECTING = 'CONNECTING',
  OPEN = 'OPEN',
  RECONNECTING = 'RECONNECTING',
  CLOSING = 'CLOSING',
  DESTROYED = 'DESTROYED',
}

/**
 * WebSocket client implementation for smart contract event log subscription and forwarding
 */
export class WsRpcClient {
  private readonly client: WebSocketClient
  private readonly frameClient: FrameClient
  private state: WsState = WsState.IDLE

  // Kept set of active subscribed contract addresses (normalized lowercase)
  private subscribedAddresses: Set<string> = new Set()

  // Track subscription ID to restore on reconnect (indexed by address)
  private activeSubscriptions: Map<string, string> = new Map()

  private requestManager = new RequestManager()

  constructor(url: string, frameClient: FrameClient) {
    this.client = new WebSocketClient(url)
    this.frameClient = frameClient
    this.transitionState(WsState.CONNECTING)
    this.initListeners()
  }

  public getState(): WsState {
    return this.state
  }

  private transitionState(newState: WsState) {
    if (this.state === WsState.DESTROYED) {
      console.warn(`[WsRpcClient] Prevented state transition from DESTROYED to ${newState}`)
      return
    }

    if (this.state === newState) {
      return
    }

    console.warn(`[WsRpcClient] State transition: ${this.state} -> ${newState}`)
    this.state = newState
  }

  private initListeners() {
    this.client.registerListeners({
      open: async () => {
        this.transitionState(WsState.OPEN)
        console.warn('[WsRpcClient] WebSocket connection opened/reconnected')
        // Auto resubscribe active subscriptions to prevent event loss on reconnect
        const addresses = Array.from(this.subscribedAddresses)
        for (const address of addresses) {
          try {
            const newSubId = await this.sendRequest<string>('eth_subscribe', ['logs', { address }])
            this.activeSubscriptions.set(address, newSubId)
            console.warn(`[WsRpcClient] Re-subscribed to ${address}, new subId: ${newSubId}`)
          } catch (err) {
            console.error(`[WsRpcClient] Failed to re-subscribe to ${address}:`, err)
          }
        }
      },
      message: (data: WebSocketMessage) => {
        // 1. Process eth_subscription event from smart contract (SMC)
        if (data.method === 'eth_subscription' && data.params) {
          const { result } = data.params
          console.warn('[WebSocketClient] Received message:', result)
          if (result && result.address) {
            const resultAddress = result.address.toLowerCase().trim()

            // Check if the address was previously subscribed
            if (this.subscribedAddresses.has(resultAddress)) {
              console.warn(`[WsRpcClient] Event log matched subscribed address: ${resultAddress}`)

              // Format topics like in legacy client: remove '0x' and lowercase
              const formattedTopics = result.topics
                ? result.topics.map((topic: string) => topic.replace('0x', '').toLowerCase())
                : []

              const formattedLog = {
                ...result,
                topics: formattedTopics,
              }

              // Emit EventLogs back to host/enclave
              this.frameClient
                .emit('EventLogs', {
                  data: [formattedLog],
                })
                .catch((err) => {
                  console.error('[WsRpcClient] Failed to emit EventLogs to host:', err)
                })
            }
          }
          return
        }

        // 2. Handle standard JSON-RPC responses (for subscription requests)
        if (data.id && this.requestManager.hasRequest(data.id)) {
          if (data.error) {
            this.requestManager.rejectRequest(
              data.id,
              new Error(`RPC WS Error: ${data.error.message}`),
            )
          } else {
            this.requestManager.resolveRequest(data.id, data.result)
          }
        }
      },
      close: () => {
        if (this.state !== WsState.DESTROYED) {
          this.transitionState(WsState.RECONNECTING)
        }
        console.warn('[WsRpcClient] WebSocket connection closed')
        this.activeSubscriptions.clear()
      },
    })
  }

  private async sendRequest<T>(method: string, params: any[] = []): Promise<T> {
    if (this.state !== WsState.OPEN) {
      return Promise.reject(
        new Error(
          `TransportUnavailableError: Cannot send request "${method}", socket state is ${this.state}`,
        ),
      )
    }

    const { id, promise } = this.requestManager.createRequest<T>()

    const payload = {
      id,
      jsonrpc: '2.0',
      method,
      params,
    }

    try {
      this.client.send(payload)
    } catch (err) {
      this.requestManager.rejectRequest(id, err as Error)
    }

    return promise
  }

  /**
   * Subscribe to event logs of a contract/address
   */
  public async subscribeToAddress(address: string): Promise<string> {
    const normalizedAddress = utils.formatAddress(address.toLowerCase().trim())

    // Add to active subscribed addresses set
    this.subscribedAddresses.add(normalizedAddress)

    // Call eth_subscribe on node
    const subId = await this.sendRequest<string>('eth_subscribe', [
      'logs',
      { address: normalizedAddress },
    ])

    this.activeSubscriptions.set(normalizedAddress, subId)
    return subId
  }

  public destroy() {
    if (this.state === WsState.DESTROYED) {
      return
    }

    this.transitionState(WsState.DESTROYED)

    // 1. Destroy underlying client
    this.client.destroy()

    // 2. Clear and reject pending requests
    this.requestManager.rejectAll(new Error(`ClientDestroyedError: WsRpcClient was destroyed`))

    // 3. Clear subscriptions
    this.subscribedAddresses.clear()
    this.activeSubscriptions.clear()

    console.warn('[WsRpcClient] Destroyed successfully.')
  }
}

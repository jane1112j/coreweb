import { HttpClient } from '@/shared/infrastructure/http'
import type { RpcClient } from '../rpc-client'

import type {
  ClusterIdentity,
  RegistrationMessage,
  RegistrationStatus,
} from '../../../domain/gateways/transaction.gateway'

export interface RpcResponse<T> {
  result?: T
  error?: {
    code: number
    message: string
  }
}

/**
 * HTTP implementation of JSON-RPC client
 */
export class HttpRpcClient implements RpcClient {
  private readonly client: HttpClient
  private readonly chainId: number
  private nextId = 1

  constructor(rpcUrl: string, chainId: number) {
    this.client = new HttpClient(rpcUrl)
    this.chainId = chainId
  }

  public async request<T>(method: string, params: unknown[] = []): Promise<T> {
    const payload = {
      jsonrpc: '2.0',
      id: this.nextId++,
      method,
      params,
    }

    const response = await this.client.post<RpcResponse<T>>('', payload)

    if (response.error) {
      throw new Error(
        `RPC Error (${method}) [Code ${response.error.code}]: ${response.error.message}`,
      )
    }

    return response.result
  }

  getChainId(): number {
    return this.chainId
  }

  async call(params: { to: string; data?: string; from: string }): Promise<string> {
    return await this.request('eth_call', [params, 'latest'])
  }

  async estimateGas(params: {
    from?: string
    to: string
    data?: string
    value?: string
  }): Promise<string> {
    return await this.request('eth_estimateGas', [params])
  }

  async broadcastTransaction(signedTx: string): Promise<string> {
    return await this.request('eth_sendRawTransaction', [signedTx])
  }

  async getBalance(address: string): Promise<string> {
    return await this.request('eth_getBalance', [address, 'latest'])
  }

  async getBlockNumber(): Promise<string> {
    return await this.request('eth_blockNumber')
  }

  async getBlockByNumber(blockNumber: string = 'latest'): Promise<string> {
    return await this.request('eth_getBlockByNumber', [blockNumber, false])
  }

  async getTransactionByHash(transactionHash: string): Promise<string> {
    return await this.request('eth_getTransactionByHash', [transactionHash])
  }

  async searchTransactions(params: {
    offset: number
    limit: number
    queryString: string
  }): Promise<string> {
    return await this.request('mtn_searchTransactions', [
      params.queryString,
      params.offset,
      params.limit,
    ])
  }

  async getAccountState(address: string): Promise<any> {
    return await this.request('mtn_getAccountState', [address, 'latest'])
  }

  async getDeviceKey(lastHash: string): Promise<string> {
    return await this.request<string>('mtn_getDeviceKey', [lastHash])
  }

  async getNonce(address: string): Promise<string> {
    return await this.request<string>('eth_getTransactionCount', [address, 'latest'])
  }

  async sendRawTransactionWithDeviceKey(transactionHex: string): Promise<string> {
    return await this.request<string>('mtn_sendRawTransactionWithDeviceKey', [transactionHex])
  }

  async getTransactionReceipt(txHash: string): Promise<any> {
    return await this.request('eth_getTransactionReceipt', [txHash])
  }

  async registerBlsKeyWithSignature(params: {
    address: string
    blsPrivateKey: string
    timestamp: string
    signature: string
  }) {
    return this.request<string>('rpc_registerBlsKeyWithSignature', [params])
  }

  async getClusterIdentity(): Promise<ClusterIdentity> {
    return await this.request<ClusterIdentity>('mtn_getClusterIdentity', [])
  }

  async getRegistrationStatus(address: string): Promise<RegistrationStatus> {
    return await this.request<RegistrationStatus>('mtn_getRegistrationStatus', [address])
  }

  async getRegistrationMessage(address: string): Promise<RegistrationMessage> {
    return await this.request<RegistrationMessage>('mtn_getRegistrationMessage', [address])
  }

  async registerAccount(address: string, signature: string): Promise<unknown> {
    return await this.request('mtn_registerAccount', [address, signature])
  }

  async confirmAccountWithoutSignVia9545(params: { signedTransaction: string }) {
    const txHash = await this.broadcastTransaction(params.signedTransaction)

    return {
      txHash,
      hash: txHash,
      status: 'submitted',
    }
  }
}

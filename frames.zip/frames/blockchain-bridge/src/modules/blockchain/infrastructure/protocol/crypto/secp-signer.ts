export class SecpSigner {
  // Capsule for any future SECP operations
}

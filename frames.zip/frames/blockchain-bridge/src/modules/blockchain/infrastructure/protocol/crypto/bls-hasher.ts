import { getBLS } from '@metanodejs/bls-crypto'

export class BlsHasher {
  public keccak256(data: string, type: number = 1): { hash: string } {
    return getBLS().keccak256(data, type)
  }
}

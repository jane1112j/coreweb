import { getBLS } from '@metanodejs/bls-crypto'
import { Interface, type InterfaceAbi } from './abi-interface'

/**
 * Service responsible for decoding blockchain response data.
 */
export class TransactionDecoder {
  /**
   * Decode smart contract result
   */
  decode(hexData: string, abiData: InterfaceAbi, functionName: string): unknown {
    try {
      const bls = getBLS()

      // Find function ABI
      const abiInterface = new Interface(abiData)
      const funcAbi = abiInterface.getFunction(functionName)
      if (!funcAbi) {
        throw new Error(`Function ${functionName} not found in ABI`)
      }

      // Decode outputs directly
      const outputs = funcAbi.outputs || []

      const result = bls.abi_decode(hexData, outputs)

      // Parse decode field
      if (result?.decode) {
        try {
          return JSON.parse(result.decode)
        } catch {
          return result.decode
        }
      }

      return result
    } catch (error) {
      console.error('[TransactionDecoder] decode error', error)
      throw error
    }
  }
}

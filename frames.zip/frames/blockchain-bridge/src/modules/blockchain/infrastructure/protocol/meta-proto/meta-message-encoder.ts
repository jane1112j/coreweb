import { getMetaProto } from '@metanodejs/meta-proto'

export class MetaMessageEncoder {
  public static validateRequireInput(params: {
    key: string
    data: Record<string, unknown>
    type: string
    controller: string
    functionCode: string
    number: number
  }) {
    const metaProto = getMetaProto()
    return metaProto.validateRequireInput(params)
  }

  public static encodeCallData(params: { input: string; data?: string }) {
    const metaProto = getMetaProto()
    return metaProto.encodeCallData(params)
  }

  public static encodeTransactionHashData(dataHashBuf: unknown) {
    const metaProto = getMetaProto()
    return metaProto.encodeTransactionHashData(dataHashBuf)
  }

  public static encodeTransaction(currentTransaction: unknown) {
    const metaProto = getMetaProto()
    return metaProto.encodeTransaction(currentTransaction)
  }

  public static getHeaderForCommand(params: {
    command: string
    toAddress: string
    sign: string
    publicKey: string
  }) {
    const metaProto = getMetaProto()
    return metaProto.getHeaderForCommand(params)
  }

  public static encodeTransactionWithDeviceKey(params: { transaction: string; deviceKey: string }) {
    const metaProto = getMetaProto()
    return metaProto.encodeTransactionWithDeviceKey(params)
  }

  public static encodeMessage(params: { header: unknown; body: string }) {
    const metaProto = getMetaProto()
    return metaProto.encodeMessage(params)
  }
}

import { getBLS } from '@metanodejs/bls-crypto'
import { HexSerializer } from '../serialization/hex-serializer'
import { RlpSerializer } from '../serialization/rlp-serializer'
import { MetaMessageEncoder } from '../meta-proto/meta-message-encoder'
import type { TransactionEncoder } from './transaction-encoder'

export interface DeviceKeys {
  hashLastKey: string
  newDeviceKey: string
}

export interface DataHashBuf {
  to: string
  pendingUse: string
  amount: string
  maxGas: number
  maxGasPrice: number
  maxTimeUse: number
  lastDeviceKey: string
  newDeviceKey: string
  from: string
  nonce: string
  chainId: number
  data?: string
  r?: string
  s?: string
  v?: string
  hash?: string
  sign?: string
}

export interface PreparedDataHash {
  dataHashBuf: DataHashBuf
  callDataInput: string
  items: string[]
  shouldSignSecp: boolean
}

export class TransactionAssembler {
  constructor(
    private readonly validationService: {
      validateAbiData(abiData: any): void
      validateInput(input: string): void
    },
    private readonly encoder: TransactionEncoder,
  ) {}

  /**
   * Computes the temporary and new device keys using the last hash.
   */
  computeDeviceKeys(lastHash: string): DeviceKeys {
    const bls = getBLS()
    const hashLastKey = bls.keccak256(lastHash, 1).hash.toLocaleLowerCase()
    const newDeviceKey = bls.keccak256(hashLastKey, 1).hash.toLocaleLowerCase()
    return { hashLastKey, newDeviceKey }
  }

  /**
   * Prepares the initial data hash buffer and determines if SECP signing is required.
   */
  prepareDataHashBuf(params: {
    txData: any
    lastDeviceKey: string
    newDeviceKey: string
    chainId: number
  }): PreparedDataHash {
    const { txData, lastDeviceKey, newDeviceKey, chainId } = params

    const cleanTo =
      txData.to.startsWith('0x') || txData.to.startsWith('0X') ? txData.to.slice(2) : txData.to
    const cleanFrom =
      txData.from.startsWith('0x') || txData.from.startsWith('0X')
        ? txData.from.slice(2)
        : txData.from

    const dataHashBuf: DataHashBuf = {
      to: cleanTo,
      pendingUse: txData.pendingBalance,
      amount: txData.amount,
      maxGas: txData.gas,
      maxGasPrice: txData.gasPrice,
      maxTimeUse: txData.timeUse,
      lastDeviceKey,
      newDeviceKey,
      from: cleanFrom,
      nonce: this.nonceToHex(txData.nonce),
      chainId: chainId,
      data: txData.data,
    }

    const callData: { input: string; data: string } = { input: '', data: '' }
    const items = ['0x', txData.gasPrice, txData.gas, '0x' + cleanTo, '0x']

    if (txData.isCall) {
      if (typeof txData.input === 'string' && txData.input.length > 0) {
        callData.input = txData.input
      } else {
        this.validationService.validateAbiData(txData.abiData)
        callData.input = this.encoder.encode(txData.abiData, txData.functionName, txData.inputArray)
        items.push(`0x${callData.input}`)
      }
      this.validationService.validateInput(callData.input)
      const encodeCallData = MetaMessageEncoder.encodeCallData(callData)
      if (!encodeCallData.success) {
        throw new Error(`Input validation failed: ${encodeCallData.message}`)
      }
      dataHashBuf.data = encodeCallData.data
    } else if (txData.data && txData.data.length > 0) {
      callData.input = txData.data
      const encodeCallData = MetaMessageEncoder.encodeCallData(callData)
      dataHashBuf.data = encodeCallData.data
    }

    const shouldSignSecp = dataHashBuf.nonce === '0000000000000000'

    return {
      dataHashBuf,
      callDataInput: callData.input,
      items,
      shouldSignSecp,
    }
  }

  /**
   * Generates SECP payload (hashRLP) to be signed.
   */
  prepareSecpPayload(items: string[], chainId: number): string {
    const itemsWithChain = [...items, chainId, '0x', '0x']
    const rlp = RlpSerializer.encode(itemsWithChain)
    const bls = getBLS()
    return bls.keccak256(rlp, 1).hash
  }

  /**
   * Applies the SECP signature into the dataHashBuf, computing the recovery parameter vInt.
   */
  applySecpSignature(dataHashBuf: DataHashBuf, signature: string, chainId: number): void {
    const r = signature.substring(0, 64)
    const s = signature.substring(64, 128)
    const v = signature.substring(128)

    dataHashBuf.r = r
    dataHashBuf.s = s

    const intValue = this.hexStringToInt(v)
    const vInt = chainId * 2 + 35 + intValue
    dataHashBuf.v = this.convertStringNumberToHexString(String(vInt))
  }

  /**
   * Generates the BLS payload (encodeTransactionHashData.data) to be signed.
   */
  prepareBlsPayload(dataHashBuf: DataHashBuf): string {
    const encodeTransactionHashData = MetaMessageEncoder.encodeTransactionHashData(dataHashBuf)
    if (!encodeTransactionHashData.success) {
      throw new Error(encodeTransactionHashData.message)
    }
    return encodeTransactionHashData.data
  }

  /**
   * Frames and encodes the final transaction, returning transaction message body and transaction hash.
   */
  finalizeTransaction(params: {
    dataHashBuf: DataHashBuf
    blsPayload: string
    signature: string
    hashLastKey: string
    publicKey: string
    signOfMessage: string
  }): { signedTx: string; hash: string; newMessage: string } {
    const { dataHashBuf, blsPayload, signature, hashLastKey, publicKey, signOfMessage } = params

    const currentTransaction = { ...dataHashBuf, hash: '', sign: '' }

    const blsLib = getBLS()
    const hashData = blsLib.keccak256(blsPayload, 1).hash.toLocaleLowerCase()

    currentTransaction.hash = hashData
    currentTransaction.sign = signature

    const encodeTransaction = MetaMessageEncoder.encodeTransaction(currentTransaction)
    if (!encodeTransaction.success) {
      throw new Error(encodeTransaction.message)
    }

    const newHeader = MetaMessageEncoder.getHeaderForCommand({
      command: 'SendTransactionWithDeviceKey',
      toAddress: '0000000000000000000000000000000000000000',
      sign: signOfMessage,
      publicKey: publicKey,
    })

    const transactionWithDeviceKey = MetaMessageEncoder.encodeTransactionWithDeviceKey({
      transaction: encodeTransaction.data,
      deviceKey: hashLastKey,
    })

    if (!transactionWithDeviceKey.success) {
      throw new Error(transactionWithDeviceKey.message)
    }

    const newMessage = MetaMessageEncoder.encodeMessage({
      header: newHeader,
      body: transactionWithDeviceKey.data,
    })

    if (!newMessage.success) {
      throw new Error(newMessage.message)
    }

    return {
      signedTx: transactionWithDeviceKey.data,
      hash: hashData,
      newMessage: newMessage.data,
    }
  }

  /**
   * Helper utility functions for Hex conversions (delegating to HexSerializer)
   */
  convertStringNumberToHexString(value: string): string {
    return HexSerializer.convertStringNumberToHexString(value)
  }

  nonceToHex(nonce: number | string): string {
    return HexSerializer.nonceToHex(nonce)
  }

  hexStringToInt(hexString: string): number {
    return HexSerializer.hexStringToInt(hexString)
  }
}

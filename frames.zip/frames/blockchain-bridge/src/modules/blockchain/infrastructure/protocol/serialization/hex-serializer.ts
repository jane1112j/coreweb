export class HexSerializer {
  public static convertStringNumberToHexString(value: string): string {
    let hexValue = BigInt(value).toString(16)
    if (hexValue.length % 2 !== 0) {
      hexValue = '0' + hexValue
    }
    return hexValue.padStart(64, '0')
  }

  public static nonceToHex(nonce: number | string): string {
    const hex = BigInt(nonce).toString(16)
    return hex.padStart(16, '0')
  }

  public static hexStringToInt(hexString: string): number {
    if (typeof hexString !== 'string') {
      throw new Error('Input must be a string')
    }
    let clean = hexString
    if (clean.startsWith('0x') || clean.startsWith('0X')) {
      clean = clean.slice(2)
    }
    return parseInt(clean, 16)
  }
}

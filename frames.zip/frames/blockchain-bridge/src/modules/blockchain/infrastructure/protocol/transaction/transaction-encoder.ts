import { Interface, type InterfaceAbi } from './abi-interface'
import { getBLS } from '@metanodejs/bls-crypto'

/**
 * Service responsible for encoding contract function calls into hexadecimal data.
 */
export class TransactionEncoder {
  /**
   * Encodes a function call (function name + arguments) into call data.
   */
  encode(abi: InterfaceAbi, functionName: string, args: unknown[], fnSign?: string): string {
    try {
      // 1. Get function signature fragment
      const iface = new Interface(abi)
      const fragment = iface.getFunction(functionName)
      if (!fragment) {
        throw new Error(`Function "${functionName}" not found in ABI`)
      }

      const bls = getBLS()

      if (!fnSign) {
        const iface = new Interface(abi)

        const fragment = iface.getFunction(functionName)

        if (!fragment) {
          throw new Error(`Function "${functionName}" not found in ABI`)
        }
        fnSign = fragment.format()
      }

      // 2. Generate function selector (4 bytes)
      const { hash } = bls.keccak256(fnSign, 0)
      const selector = hash.substring(0, 8)

      // 3. Encode arguments using BLS library
      const encodedArgs = bls.abi_encode(args, abi as unknown[], functionName)

      // 4. Combine selector and arguments
      return `${selector}${encodedArgs.substring(8)}`
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      throw new Error(`Failed to encode contract call: ${message}`, { cause: error })
    }
  }
}

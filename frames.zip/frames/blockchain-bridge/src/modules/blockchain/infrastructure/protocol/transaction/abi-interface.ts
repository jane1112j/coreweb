export type ParamType = {
  name: string
  type: string
  components?: ParamType[]
}

export interface FunctionFragment {
  name: string
  type: 'function' | 'constructor' | 'fallback' | 'receive'
  inputs: ParamType[]
  outputs?: ParamType[]
  stateMutability?: string
  format(): string
}

export type FunctionFragmentInput = {
  name: string
  type?: 'function' | 'constructor' | 'fallback' | 'receive'
  inputs?: ParamType[]
  outputs?: ParamType[]
  stateMutability?: string
}

export type InterfaceAbi = string | readonly (string | FunctionFragment | FunctionFragmentInput)[]

export class FunctionFragmentImpl implements FunctionFragment {
  name: string
  type: 'function' | 'constructor' | 'fallback' | 'receive'
  inputs: ParamType[]
  outputs?: ParamType[]
  stateMutability?: string

  constructor(data: FunctionFragmentInput) {
    this.name = data.name
    this.type = data.type || 'function'
    this.inputs = data.inputs || []
    this.outputs = data.outputs || []
    this.stateMutability = data.stateMutability
  }

  format(): string {
    const formatParam = (p: ParamType): string => {
      if (p.type === 'tuple' && p.components) {
        return `(${p.components.map(formatParam).join(',')})`
      }
      if (p.type.startsWith('tuple[') && p.components) {
        const arrayPart = p.type.substring(5)
        return `(${p.components.map(formatParam).join(',')})${arrayPart}`
      }
      if (p.type.endsWith('[]')) {
        const baseType = p.type.slice(0, -2)
        if (baseType === 'tuple' && p.components) {
          return `(${p.components.map(formatParam).join(',')})[]`
        }
      }
      return p.type
    }
    const params = this.inputs.map(formatParam).join(',')
    return `${this.name}(${params})`
  }
}

export class Interface {
  private functions = new Map<string, FunctionFragment>()

  constructor(abi: InterfaceAbi) {
    let abiArray: readonly (string | FunctionFragment | FunctionFragmentInput)[]
    if (typeof abi === 'string') {
      try {
        abiArray = JSON.parse(abi) as readonly (string | FunctionFragment | FunctionFragmentInput)[]
      } catch {
        abiArray = [abi]
      }
    } else {
      abiArray = abi
    }

    for (const item of abiArray) {
      if (typeof item === 'string') {
        const clean = item.replace(/function\s+/, '').trim()
        const match = clean.match(/^([a-zA-Z0-9_]+)\s*\((.*)\)/)
        if (match) {
          const name = match[1]
          const paramsStr = match[2].trim()
          const inputs = paramsStr
            ? paramsStr.split(',').map((param) => {
                const parts = param.trim().split(/\s+/)
                return { name: parts[1] || '', type: parts[0] }
              })
            : []
          this.functions.set(name, new FunctionFragmentImpl({ name, type: 'function', inputs }))
        }
      } else if (
        item &&
        typeof item === 'object' &&
        'type' in item &&
        item.type === 'function' &&
        'name' in item &&
        typeof item.name === 'string'
      ) {
        this.functions.set(item.name, new FunctionFragmentImpl(item))
      }
    }
  }

  getFunction(name: string): FunctionFragment | null {
    if (name.includes('(')) {
      const cleanName = name.split('(')[0]
      return this.functions.get(cleanName) || null
    }
    return this.functions.get(name) || null
  }
}

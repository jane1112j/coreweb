import { getMetaProto } from '@metanodejs/meta-proto'

export class RlpSerializer {
  public static encode(items: unknown[]): string {
    const metaProto = getMetaProto()
    return metaProto.rlpEncode(items)
  }
}

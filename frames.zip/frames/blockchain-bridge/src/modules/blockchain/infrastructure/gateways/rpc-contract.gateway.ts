import type { ContractGateway } from '../../domain/gateways/contract.gateway'
import type { HttpRpcClient } from '../rpc/http/http-rpc-client'

export class RpcContractGateway implements ContractGateway {
  constructor(private readonly rpcClient: HttpRpcClient) {}

  async call(params: { to: string; from?: string; data?: string }): Promise<string> {
    return await this.rpcClient.call({
      to: params.to,
      from: params.from || '',
      data: params.data,
    })
  }

  async estimateGas(params: {
    from?: string
    to: string
    data?: string
    value?: string
  }): Promise<string> {
    return await this.rpcClient.estimateGas(params)
  }
}

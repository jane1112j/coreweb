import type { AccountGateway } from '../../domain/gateways/account.gateway'
import type { AccountState } from '../../domain/entities/account-state.entity'
import type { HttpRpcClient } from '../rpc/http/http-rpc-client'

export class RpcAccountGateway implements AccountGateway {
  constructor(private readonly rpcClient: HttpRpcClient) {}

  async getAccountState(address: string): Promise<AccountState> {
    return await this.rpcClient.getAccountState(address)
  }

  async getDeviceKey(address: string): Promise<string> {
    return await this.rpcClient.getDeviceKey(address)
  }

  async getBalance(address: string): Promise<string> {
    return await this.rpcClient.getBalance(address)
  }

  async getTransactionNonce(address: string): Promise<number> {
    const hex = await this.rpcClient.getNonce(address)
    return parseInt(hex, 16)
  }
}

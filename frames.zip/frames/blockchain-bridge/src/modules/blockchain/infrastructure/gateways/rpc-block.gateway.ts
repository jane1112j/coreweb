import type { BlockGateway } from '../../domain/gateways/block.gateway'
import type { HttpRpcClient } from '../rpc/http/http-rpc-client'

export class RpcBlockGateway implements BlockGateway {
  constructor(private readonly rpcClient: HttpRpcClient) {}

  async getBlockNumber(): Promise<string> {
    return await this.rpcClient.getBlockNumber()
  }

  async getBlockByNumber(blockNumber: string): Promise<string> {
    return await this.rpcClient.getBlockByNumber(blockNumber)
  }

  getChainId(): number {
    return this.rpcClient.getChainId()
  }
}

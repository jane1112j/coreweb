import type { TransactionGateway } from '../../domain/gateways/transaction.gateway'
import type { TransactionReceipt } from '../../domain/entities/transaction.entity'
import type { HttpRpcClient } from '../rpc/http/http-rpc-client'

export class RpcTransactionGateway implements TransactionGateway {
  constructor(private readonly rpcClient: HttpRpcClient) {}

  async broadcastTransaction(signedTx: string): Promise<string> {
    return await this.rpcClient.broadcastTransaction(signedTx)
  }

  async sendRawTransactionWithDeviceKey(transactionHex: string): Promise<string> {
    return await this.rpcClient.sendRawTransactionWithDeviceKey(transactionHex)
  }

  async getTransactionReceipt(txHash: string): Promise<TransactionReceipt | null> {
    return await this.rpcClient.getTransactionReceipt(txHash)
  }

  async getTransactionByHash(transactionHash: string): Promise<string> {
    return await this.rpcClient.getTransactionByHash(transactionHash)
  }

  async searchTransactions(params: {
    offset: number
    limit: number
    queryString: string
  }): Promise<string> {
    return await this.rpcClient.searchTransactions(params)
  }

  async registerBlsKeyWithSignature(params: {
    address: string
    blsPrivateKey: string
    timestamp: string
    signature: string
  }): Promise<any> {
    return await this.rpcClient.registerBlsKeyWithSignature(params)
  }

  async getClusterIdentity() {
    return await this.rpcClient.getClusterIdentity()
  }

  async getRegistrationStatus(address: string) {
    return await this.rpcClient.getRegistrationStatus(address)
  }

  async getRegistrationMessage(address: string) {
    return await this.rpcClient.getRegistrationMessage(address)
  }

  async registerAccount(address: string, signature: string) {
    return await this.rpcClient.registerAccount(address, signature)
  }
}

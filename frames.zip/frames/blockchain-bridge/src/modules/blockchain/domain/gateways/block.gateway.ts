export interface BlockGateway {
  getBlockNumber(): Promise<string>
  getBlockByNumber(blockNumber: string): Promise<string>
  getChainId(): number
}

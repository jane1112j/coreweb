import type { AccountState } from '../entities/account-state.entity'

export interface AccountGateway {
  getAccountState(address: string): Promise<AccountState>
  getDeviceKey(address: string): Promise<string>
  getBalance(address: string): Promise<string>
  getTransactionNonce(address: string): Promise<number>
}

import type { TransactionReceipt } from '../entities/transaction.entity'

export interface ClusterIdentity {
  accountGate?: boolean
  clusterKey?: string
}

export interface RegistrationStatus {
  status?: string
  reason?: string
  homeCluster?: string
}

export interface RegistrationMessage {
  hashToSign?: string
  digest?: string
}

export interface TransactionGateway {
  broadcastTransaction(signedTx: string): Promise<string>
  sendRawTransactionWithDeviceKey(transactionHex: string): Promise<string>
  getTransactionReceipt(txHash: string): Promise<TransactionReceipt | null>
  getTransactionByHash(transactionHash: string): Promise<string>
  searchTransactions(params: {
    offset: number
    limit: number
    queryString: string
  }): Promise<string>
  registerBlsKeyWithSignature: (params: {
    address: string
    blsPrivateKey: string
    timestamp: string
    signature: string
  }) => Promise<any>
  getClusterIdentity(): Promise<ClusterIdentity>
  getRegistrationStatus(address: string): Promise<RegistrationStatus>
  getRegistrationMessage(address: string): Promise<RegistrationMessage>
  registerAccount(address: string, signature: string): Promise<unknown>
}

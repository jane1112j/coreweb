export interface ContractGateway {
  call(params: { to: string; from?: string; data?: string }): Promise<string>
  estimateGas(params: { from?: string; to: string; data?: string; value?: string }): Promise<string>
}

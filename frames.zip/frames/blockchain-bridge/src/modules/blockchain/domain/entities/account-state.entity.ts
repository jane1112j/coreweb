export interface AccountState {
  accountType: number
  address: string
  balance: string
  deviceKey: string
  lastHash: string
  nonce: number
  pendingBalance: string
  publicKeyBls: string
}

export type Account = {
  nonce: number
  lastDeviceKey: string
  lastHash: string
  publicKey: string
  balance: string
  address: string
  privateKey: string
}

export interface TransactionReceipt {
  transactionHash: string
  status: string
  gasUsed: string
  logs: Array<{
    address: string
    topics: string[]
    data: string
  }>
  [key: string]: unknown
}

import type { WalletService } from '@/shared/infrastructure/wallet'

/**
 * Service responsible for managing transaction signing keys and initialization.
 */
export class TransactionSigningService {
  constructor(private readonly walletService: WalletService) {}

  /**
   * Khởi tạo tài khoản cho client (thiết lập BLS public key trên system contract)
   */
  async initializeAccount(
    address: string,
    executeTx: (params: any) => Promise<{ returnValue: unknown }>,
  ): Promise<string> {
    try {
      console.warn('[initializeAccount] address: ', address)
      // 1. Lấy public key từ vault
      const { publicKey } = await this.walletService.getPublicKey(address)
      console.warn('[initializeAccount] publicKey: ', publicKey)
      const abiData = [
        {
          inputs: [
            {
              internalType: 'bytes',
              name: 'publicKey',
              type: 'bytes',
            },
          ],
          name: 'setBlsPublicKey',
          outputs: [
            {
              internalType: 'bool',
              name: '',
              type: 'bool',
            },
          ],
          stateMutability: 'nonpayable',
          type: 'function',
        },
      ]
      console.warn('[initializeAccount] abiData: ', abiData)
      // 2. Gửi giao dịch setBlsPublicKey tới system contract
      const result = await executeTx({
        from: address,
        to: '00000000000000000000000000000000D844bb55',
        abiData,
        inputArray: [
          {
            internalType: 'bytes',
            name: 'publicKey',
            type: 'bytes',
            value: publicKey,
          },
        ],
        feeType: 'sc',
        functionName: 'setBlsPublicKey',
        isCall: true,
      })
      console.warn('[initializeAccount] result: ', result)
      return result.returnValue as string
    } catch (error) {
      console.error('[initializeAccount] Error:', error)
      throw error
    }
  }
}

import { getMetaProto } from '@metanodejs/meta-proto'
import type { InterfaceAbi } from '../../infrastructure/protocol/transaction/abi-interface'

/**
 * Service responsible for validating transaction parameters and ensuring compliance with blockchain policies.
 */
export class TransactionPolicyService {
  /**
   * Validates if the given string is a valid hexadecimal address.
   */
  validateToAddress(address: string, functionCode: 'GESC' | 'ST' = 'GESC'): void {
    const metaProto = getMetaProto()
    const result = metaProto.validateRequireInput({
      key: 'to',
      data: { to: address },
      type: 'hex',
      controller: 'EX',
      functionCode,
      number: 10,
    })

    if (!result.success) {
      throw new Error(`Address validation failed: ${result.message}`)
    }
  }

  validateFromAddress(from: string, functionCode: 'GESC' | 'ST' = 'GESC'): void {
    const metaProto = getMetaProto()
    const result = metaProto.validateRequireInput({
      key: 'from',
      data: { from },
      type: 'hex',
      controller: 'EX',
      functionCode,
      number: 10,
    })

    if (!result.success) {
      throw new Error(`Address validation failed: ${result.message}`)
    }
  }

  validateAbiData(abiData: InterfaceAbi) {
    const metaProto = getMetaProto()
    const result = metaProto.validateRequireInput({
      key: 'abiData',
      data: { abiData },
      type: 'array',
      controller: 'EX',
      functionCode: 'GESC',
      number: 10,
    })

    if (!result.success) {
      throw new Error(`AbiData validation failed: ${result.message}`)
    }
  }

  validateInput(input: string) {
    const metaProto = getMetaProto()
    const result = metaProto.validateRequireInput({
      key: 'input',
      data: {
        input,
      },
      type: 'hex',
      controller: 'EX',
      functionCode: 'ECTM',
      number: 40,
    })

    if (!result.success) {
      throw new Error(`Input validation failed: ${result.message}`)
    }
  }
}

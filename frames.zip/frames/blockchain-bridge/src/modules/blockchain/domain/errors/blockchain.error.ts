export class BlockchainError extends Error {
  constructor(
    message: string,
    public readonly code?: number,
  ) {
    super(message)
    this.name = 'BlockchainError'
  }
}

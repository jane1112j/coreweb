export class Address {
  constructor(public readonly value: string) {
    if (!value) {
      throw new Error('Address value cannot be empty')
    }
  }

  public toString(): string {
    return this.value
  }
}

export class ChainId {
  constructor(public readonly value: number) {}

  public toNumber(): number {
    return this.value
  }
}

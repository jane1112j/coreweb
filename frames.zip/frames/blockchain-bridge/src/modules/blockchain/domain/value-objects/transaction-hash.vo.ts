export class TransactionHash {
  constructor(public readonly value: string) {
    if (!value) {
      throw new Error('Transaction hash cannot be empty')
    }
  }

  public toString(): string {
    return this.value
  }
}

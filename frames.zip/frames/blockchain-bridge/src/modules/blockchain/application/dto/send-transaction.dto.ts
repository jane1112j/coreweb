import type { InterfaceAbi } from '../../infrastructure/protocol/transaction/abi-interface'
export interface SendTransactionRequest {
  to: string
  from?: string
  feeType?: 'read' | 'sc'

  // Common contract fields
  functionName: string
  abiData?: any
  inputArray?: InterfaceAbi[]

  // Execute specific fields
  isCall?: boolean
  gas?: number | string
  gasPrice?: number | string
  timeUse?: number | string
  amount?: number | string
  value?: number | string
  isDeploy?: boolean
  abiEvent?: InterfaceAbi

  // Additional data payload if any
  data?: string
  isFreeGas?: boolean

  /** eth_sendRawTransaction: ABI thuần (mặc định, giống eth_call) vs protobuf encodeCallData */
  ethDataMode?: 'rawAbi' | 'protoCallData'
  /** eth_sendRawTransaction: nonce MTN vs eth_getTransactionCount */
  ethNonceSource?: 'mtnAccountState' | 'ethTransactionCount'
  /** eth_sendRawTransaction: legacy EIP-155 vs EIP-1559 (0x02) vs bytes giống mtnSignedTx */
  ethTxEnvelope?: 'legacy' | 'eip1559' | 'mtnProto'

  [key: string]: unknown
}

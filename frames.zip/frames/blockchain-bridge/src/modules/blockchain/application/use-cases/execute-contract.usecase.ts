import type { WalletService } from '@/shared/infrastructure/wallet'
import { getBLS } from '@metanodejs/bls-crypto'
import { getMetaProto } from '@metanodejs/meta-proto'
import type { Account, TransactionSigningService } from '../../domain'
import type { AccountGateway } from '../../domain/gateways/account.gateway'
import type { BlockGateway } from '../../domain/gateways/block.gateway'
import type { TransactionGateway } from '../../domain/gateways/transaction.gateway'
import type { TransactionPolicyService } from '../../domain/services/transaction-policy.service'
import type { SendTransactionRequest } from '../dto/send-transaction.dto'
import type { TransactionMonitorService } from '../services/transaction-monitor.service'
import type { ReadContractUseCase } from './read-contract.usecase'
import { utils as _utils } from '@metanodejs/fiai-sdk'
import {
  RlpSerializer,
  type TransactionAssembler,
  type TransactionEncoder,
} from '../../infrastructure'

export class ExecuteContractUseCase {
  constructor(
    private readonly accountGateway: AccountGateway,
    private readonly transactionGateway: TransactionGateway,
    private readonly blockGateway: BlockGateway,
    private readonly policyService: TransactionPolicyService,
    private readonly _signingService: TransactionSigningService,
    private readonly _assembler: TransactionAssembler,
    private readonly walletService: WalletService,
    private readonly monitorService: TransactionMonitorService,
    private readonly encoder: TransactionEncoder,
    private readonly readUC: ReadContractUseCase,
  ) {
    void this._assembler
    void this._signWithWallet
    void _utils
  }
  private accountMap = new Map<string, Account>()
  private promiseMap = new Map<string, Promise<any>>()
  private hiddenAddress = ''

  private async isHidden(address: string) {
    if (!this.hiddenAddress) {
      this.hiddenAddress = add0x((await this.walletService.getHiddenWallet()).address)
    }
    return this.hiddenAddress === add0x(address)
  }

  private async fetchAccount(address: string) {
    address = add0x(address)
    const promise = (async () => {
      try {
        const state = await this.accountGateway.getAccountState(address)
        const wallet = await this.walletService.getPublicWalletInfo(address)
        const privateKey = (await this.walletService.getPrivateKey(address)).privateKey

        const emptyKey = add0x(numberToHex(0, 32))
        // Tạm bỏ mtn_getDeviceKey — luồng ETH không cần device key.
        // const isEmpty = emptyKey === add0x(state.lastHash)
        const account = {
          lastDeviceKey: emptyKey,
          // lastDeviceKey: isEmpty
          //   ? emptyKey
          //   : await this.accountGateway.getDeviceKey(state.lastHash),
          lastHash: state.lastHash,
          nonce: state.nonce,
          publicKey: wallet.publicKey,
          balance: state.pendingBalance,
          address,
          privateKey,
        }

        this.accountMap.set(address, account)
        return account
      } finally {
        this.promiseMap.delete(address)
      }
    })()
    this.promiseMap.set(address, promise)

    return promise
  }

  private async getAccoutState(address: string) {
    address = add0x(address)
    let account = this.accountMap.get(address)
    if (!account) {
      const promise = this.promiseMap.get(address)
      if (promise) {
        account = await promise
      } else {
        account = await this.fetchAccount(address)
      }
    }
    return account
  }

  private async updateAccount(address: string, value: Partial<Account>) {
    address = add0x(address)
    const old = await this.getAccoutState(address)
    this.accountMap.set(address, { ...old, ...value })
  }

  private computeDeviceKeys(lastHash: string) {
    const bls = getBLS()
    const hashLastKey = bls.keccak256(lastHash, 1).hash.toLocaleLowerCase()
    const newDeviceKey = bls.keccak256(hashLastKey, 1).hash.toLocaleLowerCase()
    return { hashLastKey, newDeviceKey }
  }

  private async _signWithWallet(address: string, payload: any) {
    const account = await this.getAccoutState(address)
    const blsLib = getBLS()
    const { sign } = blsLib.sign(account.privateKey, payload, true)
    return { signature: sign }
  }

  private resolveEthPrepareOptions(
    params: SendTransactionRequest,
    options?: PrepareOptions,
  ): PrepareOptions {
    const ethDataMode =
      options?.ethDataMode ??
      (params.ethDataMode === 'protoCallData' ? 'protoCallData' : 'rawAbi')
    const ethNonceSource =
      options?.ethNonceSource ??
      (params.ethNonceSource === 'ethTransactionCount'
        ? 'ethTransactionCount'
        : 'mtnAccountState')
    const ethTxEnvelope =
      options?.ethTxEnvelope ??
      (params.ethTxEnvelope === 'eip1559' || params.ethTxEnvelope === 'mtnProto'
        ? params.ethTxEnvelope
        : 'legacy')

    return {
      ...options,
      isEth: true,
      ethDataMode,
      ethNonceSource,
      ethTxEnvelope,
    }
  }

  private async sendTransaction(params: SendTransactionRequest, options?: PrepareOptions) {
    const { to, from, gas = 10000, gasPrice = 0, amount: rawAmount = 0, value: rawValue } = params
    // Ethereum convention value priority, fallback to amount
    const blsLib = getBLS()
    const amount = rawValue || rawAmount || 0
    const formattedTo = add0x(to)
    const formattedFrom = add0x(from)
    this.policyService.validateFromAddress(formattedFrom, 'ST')
    this.policyService.validateToAddress(formattedTo, 'ST')
    const account = await this.getAccoutState(formattedFrom)
    const ethPrepare = this.resolveEthPrepareOptions(params, options)

    let accountForTx = account
    if (ethPrepare.ethNonceSource === 'ethTransactionCount') {
      const ethNonce = await this.accountGateway.getTransactionNonce(formattedFrom)
      accountForTx = { ...account, nonce: ethNonce }
    }

    const { hashLastKey, newDeviceKey } = this.computeDeviceKeys(account.lastHash)
    const chainId = this.blockGateway.getChainId()

    const finalGas = Math.max(100_000, Number(gas || 0))
    const finalGasPrice = Math.max(100_000, Number(gasPrice || 0))

    const builder = new TransactionBuilder(
      {
        account: accountForTx,
        amount: amount,
        chainId: chainId,
        device: { hashLastKey, newDeviceKey },
        from: formattedFrom,
        to: formattedTo,
        gas: finalGas,
        gasPrice: finalGasPrice,
        payload: {
          abiData: params.abiData,
          functionName: params.functionName,
          inputArray: params.inputArray,
        },
        options: ethPrepare,
      },
      this.encoder,
    )

    const rawTx = builder.ethSignedTx
    assertValidEthRawTx(rawTx)
    console.warn('[execute-contract] eth_sendRawTransaction', {
      ethDataMode: ethPrepare.ethDataMode,
      ethNonceSource: ethPrepare.ethNonceSource,
      ethTxEnvelope: ethPrepare.ethTxEnvelope,
      chainId,
      mtnNonce: account.nonce,
      txNonce: accountForTx.nonce,
      rawTxPrefix: rawTx.slice(0, 18),
    })

    const returnedHash = await this.transactionGateway.broadcastTransaction(rawTx)
    // : await this.transactionGateway.sendRawTransactionWithDeviceKey(builder.mtnSignedTx)

    if (!returnedHash) {
      throw new Error(`Cannot find hash of function ${params.functionName}`)
    }

    let transactionUpdate = {
      lastHash: returnedHash,
      lastDeviceKey: hashLastKey,
    } as any

    if (!['uploadChunk', 'confirmAccountWithoutSign'].includes(params.functionName)) {
      transactionUpdate = {
        ...transactionUpdate,
        nonce: accountForTx.nonce + 1,
      }
    }

    await this.updateAccount(formattedFrom, transactionUpdate)

    let returnValue: unknown = ''
    // 14. Monitor transaction receipt mining
    const response = await this.monitorService.monitorTransaction(returnedHash)
    console.warn('[blockchain-bridge] ExecuteContractUseCase response: ', response)

    if (!response.success) {
      const receipt = response.data
      const detail =
        receipt != null
          ? ` status=${String(receipt.status)} gasUsed=${String(receipt.gasUsed)} tx=${returnedHash}`
          : ` tx=${returnedHash}`
      throw new Error(`${response.message || 'Transaction failed'} (${params.functionName})${detail}`)
    }

    // 15. Decode event logs
    const receipt = response.data
    if (receipt && receipt.logs && receipt.logs.length > 0 && (params as any).abiEvent) {
      const abiEvent = (params as any).abiEvent
      try {
        const eventHash = blsLib
          .keccak256(`${abiEvent.name}(${abiEvent.inputs.map((i: any) => i.type).join(',')})`, 1)
          .hash.toLowerCase()
          .replace('0x', '')

        const matchedLog = receipt.logs.find((log) =>
          (log.topics || []).some((topic) => topic.toLowerCase().replace('0x', '') === eventHash),
        )
        const encodedData = matchedLog?.data || receipt.logs[0]?.data
        if (encodedData) {
          const { decode } = blsLib.abi_decode(encodedData, abiEvent.inputs) || {}
          if (typeof decode === 'string' && (decode.includes('{') || decode.includes('['))) {
            returnValue = JSON.parse(decode)
          }
        }
      } catch (err) {
        console.error('[execute-contract] Decode or JSON parse error:', err)
      }
    }
    // 16. Update Vault Storage state upon success
    if (returnedHash) {
      try {
        await this.walletService.updateWalletInfo({
          address: formattedFrom,
          lastHash: returnedHash,
          lastDeviceKey: hashLastKey,
          totalBalanceString: account.balance,
        })
      } catch (err) {
        console.error('[execute-contract] Failed to update wallet info:', err)
      }
    }
    return {
      returnValue,
    }
  }

  async execute(
    params: SendTransactionRequest,
    _isAddAccountForClient?: boolean,
  ): Promise<{ returnValue: unknown }> {
    if (!params.from) {
      throw new Error('Sender address (from) is required to execute a contract transaction')
    }

    let account = await this.getAccoutState(params.from)

    if (!_isAddAccountForClient && account.nonce === 0) {
      await this._signingService.initializeAccount(params.from, (p) => this.execute(p, true))
      await this.fetchAccount(params.from)
      account = await this.getAccoutState(params.from)
    }

    await new RegisterAccount(
      params,
      account,
      await this.isHidden(params.from),
      this.sendTransaction.bind(this),
      this.readUC,
      this.transactionGateway,
    ).register()

    return this.sendTransaction(params, {
      isEth: true,
      ethDataMode: params.ethDataMode === 'protoCallData' ? 'protoCallData' : 'rawAbi',
      ethNonceSource:
        params.ethNonceSource === 'ethTransactionCount'
          ? 'ethTransactionCount'
          : 'mtnAccountState',
      ethTxEnvelope:
        params.ethTxEnvelope === 'eip1559' || params.ethTxEnvelope === 'mtnProto'
          ? params.ethTxEnvelope
          : 'legacy',
    })

    /* Tạm bỏ luồng MTN (mtn_getDeviceKey / sendRawTransactionWithDeviceKey), gọi ETH như isEth.
    try {
        const {
          to,
          from,
          isCall = true,
          gas = 10000,
          gasPrice = 0,
          timeUse = 0,
          amount: rawAmount = 0,
          value: rawValue,
          isDeploy = false,
        } = params
        // Ethereum convention value priority, fallback to amount
        const amount = rawValue || rawAmount || 0
        if (!from) {
          throw new Error('Sender address (from) is required to execute a contract transaction')
        }
        console.warn('[blockchain-bridge] ExecuteContractUseCase params: ', params)
        const blsLib = getBLS()

        const formattedTo = _utils.formatAddress(to)
        const formattedFrom = _utils.formatAddress(from)

        // 1. Validate addresses
        this.policyService.validateFromAddress(formattedFrom, 'ST')
        this.policyService.validateToAddress(formattedTo, 'ST')
        // 2. Fetch account state efficiently
        // let accountState = await this.accountGateway.getAccountState(formattedFrom)
        let account = await this.getAccoutState(formattedFrom)
        // console.warn('[blockchain-bridge] accountState: ', accountState)

        // 3. Initialize account with system contract BLS key if nonce is zero
        if (!isAddAccountForClient && account.nonce === 0) {
          await this._signingService.initializeAccount(formattedFrom, (p) => this.execute(p, true))
          // accountState = await this.accountGateway.getAccountState(formattedFrom)
          await this.fetchAccount(formattedFrom)
          account = await this.getAccoutState(formattedFrom)
          await this.fetchAccount(formattedFrom)
        }

        // 4. Compute device keys
        // const account = this.getAccoutState(formattedFrom)
        const { hashLastKey, newDeviceKey } = this._assembler.computeDeviceKeys(account.lastHash)
        const chainId = this.blockGateway.getChainId()
        const lastHash = account.lastHash
        const lastDeviceKey = (await this.getAccoutState(formattedFrom)).lastDeviceKey

        // const publicKeyInfo = await this.walletService.getPublicWalletInfo(formattedFrom)
        const publicKeyInfo = {
          lastHash,
          publicKey: (await this.getAccoutState(formattedFrom)).publicKey,
          lastDeviceKey,
        }

        // 5. Clean gas parameters
        const parsedGas = Number(gas)
        const finalGas = parsedGas < 20000 ? (isDeploy || isCall ? 100000 : 20000) : parsedGas

        const parsedGasPrice = Number(gasPrice)
        const finalGasPrice = parsedGasPrice < 100_000 ? 100_000 : parsedGasPrice

        const parsedTimeUse = Number(timeUse)
        const finalTimeUse = !parsedTimeUse ? (isDeploy || isCall ? 1000 : 0) : parsedTimeUse
        // 6. Build the clean tx parameters
        const txData = {
          ...publicKeyInfo,
          ...params,
          isCall,
          gas: finalGas,
          gasPrice: finalGasPrice,
          timeUse: finalTimeUse,
          amount: this._assembler.convertStringNumberToHexString(`${amount}`),
          nonce: account.nonce,
          pendingBalance: this._assembler.convertStringNumberToHexString(`${account.balance}`),
          lastHash: account.lastHash,
        }
        // 7. move to 4
        // 8. Delegate packaging of initial dataHashBuf to TransactionAssembler
        const preparedHash = this._assembler.prepareDataHashBuf({
          txData,
          lastDeviceKey,
          newDeviceKey,
          chainId,
        })

        const { dataHashBuf, items, shouldSignSecp } = preparedHash

        // 9. Sign SECP payload if required (nonce is zero)
        if (shouldSignSecp) {
          const hashRLP = this._assembler.prepareSecpPayload(items, chainId)
          const signSECP2561 = await this.walletService.signWithWallet(
            formattedFrom,
            'secp256k1',
            hashRLP,
          )
          this._assembler.applySecpSignature(dataHashBuf, signSECP2561.signature, chainId)
        }

        // 10. Generate BLS payload and request BLS signature
        const blsPayload = this._assembler.prepareBlsPayload(dataHashBuf)
        // const { signature } = await this.walletService.signWithWallet(
        //   formattedFrom,
        //   'bls',
        //   blsPayload,
        // )
        const { signature } = await this._signWithWallet(formattedFrom, blsPayload)

        // 11. Sign the framed transaction message
        const metaProto = getMetaProto()
        const currentTransaction = { ...dataHashBuf, hash: '', sign: '' }
        const hashData = blsLib.keccak256(blsPayload, 1).hash.toLocaleLowerCase()

        currentTransaction.hash = hashData
        currentTransaction.sign = signature

        const encodeTransaction = metaProto.encodeTransaction(currentTransaction)
        if (!encodeTransaction.success) {
          throw new Error(encodeTransaction.message)
        }

        // const signOfMessage = await this.walletService.signWithWallet(
        //   formattedFrom,
        //   'bls',
        //   encodeTransaction.data,
        // )
        const signOfMessage = await this._signWithWallet(formattedFrom, encodeTransaction.data)

        // 12. Frame the transaction message body via TransactionAssembler
        const { signedTx } = this._assembler.finalizeTransaction({
          dataHashBuf,
          blsPayload,
          signature,
          hashLastKey,
          publicKey: publicKeyInfo.publicKey,
          signOfMessage: signOfMessage.signature,
        })

        // 13. Send raw transaction
        const returnedHash = await this.transactionGateway.sendRawTransactionWithDeviceKey(
          _utils.formatAddress(signedTx),
        )

        if (!returnedHash) {
          throw new Error(`Cannot find hash of function ${params.functionName}`)
        }

        if (params.functionName === 'uploadChunk') {
          await this.updateAccount(formattedFrom, {
            lastHash: returnedHash,
            lastDeviceKey: hashLastKey,
          })
          return {
            returnValue: returnedHash,
          }
        } else {
          await this.updateAccount(formattedFrom, {
            lastHash: returnedHash,
            lastDeviceKey: hashLastKey,
            nonce: account.nonce + 1,
          })
        }

        // 14. Monitor transaction receipt mining
        const response = await this.monitorService.monitorTransaction(returnedHash)

        if (!response.success) {
          throw new Error(response.message || 'Transaction failed')
        }

        // 15. Decode event logs
        const receipt = response.data
        let returnValue: unknown = ''
        if (receipt && receipt.logs && receipt.logs.length > 0 && (params as any).abiEvent) {
          const abiEvent = (params as any).abiEvent
          try {
            const eventHash = blsLib
              .keccak256(
                `${abiEvent.name}(${abiEvent.inputs.map((i: any) => i.type).join(',')})`,
                1,
              )
              .hash.toLowerCase()
              .replace('0x', '')

            const matchedLog = receipt.logs.find((log) =>
              (log.topics || []).some(
                (topic) => topic.toLowerCase().replace('0x', '') === eventHash,
              ),
            )
            const encodedData = matchedLog?.data || receipt.logs[0]?.data
            if (encodedData) {
              const { decode } = blsLib.abi_decode(encodedData, abiEvent.inputs) || {}
              if (typeof decode === 'string' && (decode.includes('{') || decode.includes('['))) {
                returnValue = JSON.parse(decode)
              }
            }
          } catch (err) {
            console.error('[execute-contract] Decode or JSON parse error:', err)
          }
        }
        // 16. Update Vault Storage state upon success
        if (returnedHash) {
          try {
            await this.walletService.updateWalletInfo({
              address: formattedFrom,
              lastHash: returnedHash,
              lastDeviceKey: hashLastKey,
              totalBalanceString: account.balance,
            })
          } catch (err) {
            console.error('[execute-contract] Failed to update wallet info:', err)
          }
        }
        return {
          returnValue,
        }
      } catch (error) {
        console.error('[blockchain-bridge] Error:', error)
        throw error
      }
    */
  }
}

type EthDataMode = 'rawAbi' | 'protoCallData'
type EthNonceSource = 'mtnAccountState' | 'ethTransactionCount'
type EthTxEnvelope = 'legacy' | 'eip1559' | 'mtnProto'

type PrepareOptions = {
  hasSig?: boolean
  isEth?: boolean
  /** Case 2: tx.data = encodeCallData(protobuf) thay vì ABI thuần */
  ethDataMode?: EthDataMode
  /** Case 3: nonce từ eth_getTransactionCount thay vì mtn_getAccountState */
  ethNonceSource?: EthNonceSource
  /** Legacy RLP, typed 0x02, hoặc protobuf MTN (A/B test qua eth_sendRawTransaction) */
  ethTxEnvelope?: EthTxEnvelope
}

class TransactionBuilder {
  baseItems: any[]
  defaultLastBytes: any
  _callData: string

  constructor(
    private readonly input: {
      chainId: number
      gas: number
      gasPrice: number
      to: string
      from: string
      amount: string | number
      account: Account
      payload: {
        abiData: any[]
        functionName: string
        inputArray: any[]
      }
      device: {
        newDeviceKey: string
        hashLastKey: string
      }
      options?: PrepareOptions
    },
    private readonly encoder: TransactionEncoder,
  ) {
    const { account } = input
    const valueField = formatEthValueField(input.amount)
    this.baseItems = [account.nonce, input.gasPrice, input.gas, input.to, valueField]
    this.defaultLastBytes = [input.chainId, '0x', '0x']
  }

  get payload() {
    return this.input.payload
  }
  get account() {
    return this.input.account
  }

  get options() {
    return this.input.options ?? {}
  }

  get callData() {
    if (!this._callData) {
      const p = this.payload
      this._callData = this.encoder.encode(p.abiData, p.functionName, p.inputArray)
    }
    return this._callData
  }

  /** Payload đưa vào trường `data` của eth_sendRawTransaction (ký và broadcast dùng cùng bytes). */
  get ethTxDataHex() {
    if (this.options.ethDataMode === 'protoCallData') {
      return strip0x(this.useProto('encodeCallData', { input: this.callData }))
    }
    return strip0x(this.callData)
  }

  /** ECDSA (legacy EIP-155) — dùng cho mtnSignedTx khi hasSig. */
  get sig() {
    return this.signLegacyEip155Payload([
      ...this.baseItems,
      add0x(this.ethTxDataHex),
      ...this.defaultLastBytes,
    ])
  }

  private signLegacyEip155Payload(unsignedFields: unknown[]) {
    const bls = getBLS()
    const unsignedTx = RlpSerializer.encode(unsignedFields)
    const txHash = bls.keccak256(unsignedTx, 1).hash
    const sign = signPersonnal(this.account.privateKey, txHash)
    const r = sign.substring(0, 64)
    const s = sign.substring(64, 128)
    const v = sign.substring(128)
    const recoveryId = normalizeEcdsaRecoveryId(v)
    const vInt = this.input.chainId * 2 + 35 + recoveryId
    return { r: r.toLowerCase(), s: s.toLowerCase(), v: vInt, yParity: recoveryId }
  }

  private signEip1559Payload(unsignedFields: unknown[]) {
    const bls = getBLS()
    const unsignedRlp = strip0x(RlpSerializer.encode(unsignedFields))
    const signingHex = add0x(`02${unsignedRlp}`)
    const txHash = bls.keccak256(signingHex, 1).hash
    const sign = signPersonnal(this.account.privateKey, txHash)
    const r = sign.substring(0, 64)
    const s = sign.substring(64, 128)
    const v = sign.substring(128)
    const yParity = normalizeEcdsaRecoveryId(v)
    return { r: r.toLowerCase(), s: s.toLowerCase(), yParity }
  }

  get device() {
    return this.input.device
  }
  get dataHasBuf() {
    const data = this.useProto('encodeCallData', { input: this.callData })
    return {
      amount: numberToHex(this.input.amount, 32),
      chainId: this.input.chainId,
      data,
      from: strip0x(this.input.from),
      lastDeviceKey: this.account.lastDeviceKey,
      maxGas: this.input.gas,
      maxGasPrice: this.input.gasPrice,
      maxTimeUse: 1_000,
      newDeviceKey: this.device.newDeviceKey,
      nonce: numberToHex(this.account.nonce, 8),
      pendingUse: numberToHex(this.account.balance, 32),
      to: strip0x(this.input.to),
    }
  }

  useProto(name: string, ...arg: any) {
    const proto = getMetaProto() as any
    const fn = proto[name]
    if (typeof fn !== 'function') throw new Error('[useProto] Invalid function')
    const rs = fn(...arg)
    if (!rs.success) {
      console.error('useProto', arg)
      throw new Error(`[useProto][${name}] ${rs?.message ?? 'Unknown error'}`)
    }
    return rs.data
  }

  get ethSignedTx() {
    if (this.options.ethTxEnvelope === 'mtnProto') {
      return this.mtnSignedTx
    }
    if (this.options.ethTxEnvelope === 'eip1559') {
      return this.buildEip1559SignedTx()
    }
    return this.buildLegacySignedTx()
  }

  private buildLegacySignedTx() {
    const txData = add0x(this.ethTxDataHex)
    const sig = this.signLegacyEip155Payload([
      ...this.baseItems,
      txData,
      ...this.defaultLastBytes,
    ])
    const payload = [...this.baseItems, txData, sig.v, add0x(sig.r), add0x(sig.s)]
    const signedTx = RlpSerializer.encode(payload)
    return add0x(signedTx)
  }

  private buildEip1559SignedTx() {
    const txData = add0x(this.ethTxDataHex)
    const fee = this.input.gasPrice
    const valueField = formatEthValueField(this.input.amount)
    const unsignedFields: unknown[] = [
      this.input.chainId,
      this.account.nonce,
      fee,
      fee,
      this.input.gas,
      this.input.to,
      valueField,
      txData,
      [],
    ]
    const sig = this.signEip1559Payload(unsignedFields)
    const signedRlp = strip0x(
      RlpSerializer.encode([
        ...unsignedFields,
        sig.yParity,
        add0x(sig.r),
        add0x(sig.s),
      ]),
    )
    return add0x(`02${signedRlp}`)
  }

  get mtnSignedTx() {
    const bls = getBLS()
    const sig = this.sig
    const dataHashBuf = this.options.hasSig
      ? { ...this.dataHasBuf, ...sig, v: numberToHex(sig.v, 32).toLowerCase() }
      : this.dataHasBuf

    const payload = this.useProto('encodeTransactionHashData', dataHashBuf)
    const hash = bls.keccak256(payload, 1).hash
    const sign = bls.sign(this.account.privateKey, payload, true).sign
    const currentTransaction = { ...dataHashBuf, hash, sign }
    const encoded = this.useProto('encodeTransaction', currentTransaction)

    const signedTx = this.useProto('encodeTransactionWithDeviceKey', {
      transaction: encoded,
      deviceKey: this.device.hashLastKey,
    })

    return add0x(signedTx)
  }
}

class RegisterAccount {
  constructor(
    private readonly params: SendTransactionRequest,
    private readonly account: Account,
    _isHidden: boolean,
    _sendTransaction: ExecuteContractUseCase['sendTransaction'],
    _readUC: ReadContractUseCase,
    private readonly gateway: TransactionGateway,
  ) {}

  get from() {
    return this.params.from
  }

  async register() {
    const address = add0x(this.from)

    try {
      const identity = await this.gateway.getClusterIdentity()
      if (!identity?.accountGate) return
    } catch {
      return
    }

    const current = await this.readStatus(address)
    if (current?.status === 'CONFIRMED') return
    this.assertTerminalStatus(current)

    const message = await this.gateway.getRegistrationMessage(address)
    if (!message?.digest) {
      throw new Error('Failed to retrieve registration message digest from cluster')
    }

    const signature = personalSign(this.account.privateKey, message.digest)
    await this.gateway.registerAccount(address, signature)

    const maxAttempts = 30
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      const status = await this.readStatus(address)
      if (status?.status === 'CONFIRMED') return
      this.assertTerminalStatus(status)
    }

    throw new Error('Registration submitted. Still awaiting Parent Chain finality.')
  }

  private async readStatus(address: string) {
    try {
      return await this.gateway.getRegistrationStatus(address)
    } catch {
      return null
    }
  }

  private assertTerminalStatus(
    status: { status?: string; reason?: string; homeCluster?: string } | null,
  ) {
    if (status?.status === 'REJECTED') {
      throw new Error(
        `Registration rejected: Account is already registered on cluster ${status.homeCluster || 'another cluster'}`,
      )
    }
    if (status?.status === 'FAILED') {
      throw new Error(`Registration relay failed: ${status.reason || 'Parent Chain rejected'}`)
    }
  }
}

/* Luồng BLS cũ (setBlsPublicKey / confirmAccountWithoutSign / rpc_registerBlsKeyWithSignature).
class RegisterAccountLegacy {
  private to = '00000000000000000000000000000000D844bb55'
  get from() {
    return ''
  }
  get base() {
    return { from: this.from, to: this.to }
  }
  get isFreeGas() {
    return false
  }
  private async getBlsPublicKey() {
    const abiData = [
      {
        inputs: [] as any,
        name: 'getPublickeyBls',
        outputs: [] as any,
        stateMutability: 'nonpayable',
        type: 'function',
      },
    ]
    const payload = {
      functionName: 'getPublickeyBls',
      abiData,
      feeType: 'read',
      inputArray: [] as any,
      gas: 0,
      ...this.base,
    } as any

    const rs = await this.readUC.execute(payload, (rs) => rs)

    return rs.returnValue as string
  }

  private async setPublicKey(publicKey: string) {
    const abiData = [
      {
        inputs: [
          {
            internalType: 'bytes',
            name: 'publicKey',
            type: 'bytes',
          },
        ],
        name: 'setBlsPublicKey',
        outputs: [
          {
            internalType: 'bool',
            name: '',
            type: 'bool',
          },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
      },
    ]

    const payload = {
      functionName: 'setBlsPublicKey',
      abiData,
      isCall: true,
      feeType: 'sc',
      inputArray: [
        {
          internalType: 'bytes',
          name: 'publicKey',
          type: 'bytes',
          value: publicKey,
        },
      ],
      gas: 0,
      ...this.base,
    } as any

    console.log('setPublicKey 1', payload)

    await this.sendTransaction(payload, { hasSig: true, isEth: this.isFreeGas })
  }

  private async confirmAccount() {
    const abiData = [
      {
        inputs: [
          {
            internalType: 'address',
            name: 'account',
            type: 'address',
          },
        ],
        name: 'confirmAccountWithoutSign',
        outputs: [] as any,
        stateMutability: 'nonpayable',
        type: 'function',
      },
    ]

    const payload = {
      functionName: 'confirmAccountWithoutSign',
      abiData,
      isCall: true,
      feeType: 'sc',
      inputArray: [
        {
          internalType: 'address',
          name: 'account',
          type: 'address',
          value: strip0x(this.from),
        },
      ],
      gas: 0,
      ...this.base,
    } as any

    await this.sendTransaction(payload, { hasSig: true, isEth: true })
  }

  private async registerBls() {
    const privateKey = this.account.privateKey
    const timestamp = new Date().toISOString()
    const message = `BLS Data: ${add0x(privateKey)}\nTimestamp: ${timestamp}`
    const hashMessage = add0x(createPersonalMessage(message).toLowerCase())
    const signature = add0x(signPersonnal(privateKey, hashMessage))

    await this.gateway.registerBlsKeyWithSignature({
      address: add0x(this.from),
      blsPrivateKey: privateKey,
      signature,
      timestamp: timestamp,
    })
  }

  async register() {
    const publicKey =
      this.isFreeGas && this.isHidden ? await this.getBlsPublicKey() : this.account.publicKey

    await this.setPublicKey(publicKey)

    if (!this.isFreeGas) return
    await this.confirmAccount()

    if (this.isHidden) return
    await this.registerBls()
  }
}
*/

export function numberToHex(value: number | string, byteCount: number): string {
  return value
    .toString(16)
    .toUpperCase()
    .padStart(byteCount * 2, '0')
}

export function strip0x(hex: string = '') {
  return hex.startsWith('0x') ? hex.slice(2) : hex
}

export function add0x(hex: string = '') {
  return hex.startsWith('0x') ? hex : `0x${hex}`
}

/** Trường `value` legacy / EIP-1559 — khớp eth_call khi có amount/value. */
function formatEthValueField(amount: string | number): string {
  if (amount === undefined || amount === null || amount === '') return '0x'
  const asBig = BigInt(String(amount))
  if (asBig === BigInt(0)) return '0x'
  return add0x(asBig.toString(16))
}

function assertValidEthRawTx(rawTx: string) {
  const body = strip0x(rawTx)
  if (!body) {
    throw new Error(
      'ethSignedTx is empty (metaProto rlpEncode failed — check console for rlpEncode error)',
    )
  }
}

/** ECDSA v suffix: 0/1 hoặc 27/28 → recovery id 0/1 cho EIP-155 / EIP-1559. */
function normalizeEcdsaRecoveryId(vHex: string): number {
  const n = parseInt(vHex, 16)
  if (n === 27 || n === 28) return n - 27
  if (n === 0 || n === 1) return n
  return n
}

function utf8(str: string): Uint8Array {
  return new TextEncoder().encode(str)
}

function concat(...arrays: Uint8Array[]): Uint8Array {
  const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0)

  const result = new Uint8Array(totalLength)

  let offset = 0
  for (const arr of arrays) {
    result.set(arr, offset)
    offset += arr.length
  }

  return result
}

export function bytesToHex(bytes: Uint8Array): string {
  let hex = ''

  for (let i = 0; i < bytes.length; i++) {
    hex += (bytes[i]).toString(16).padStart(2, '0')
  }

  return hex
}

export function createPersonalMessage(message: string) {
  const bls = getBLS()
  const msg = utf8(message)

  const prefix = utf8(`Ethereum Signed Message:\n${msg.length}`)

  const input = concat(Uint8Array.of(0x19), prefix, msg)

  return bls.keccak256(bytesToHex(input), 1).hash
}

export function signPersonnal(privateKey: string, input: string, isHex = true) {
  const bls = getBLS()
  return bls.ecdsa_sign(privateKey, input, isHex).sign.toLowerCase()
}

/** MetaMask `personal_sign`: keccak256("\x19Ethereum Signed Message:\n" + byteLength + bytes). */
export function personalSign(privateKey: string, digestHex: string): string {
  const bls = getBLS()
  const msg = bls.hexToByte(strip0x(digestHex))
  const prefix = utf8(`Ethereum Signed Message:\n${msg.length}`)
  const input = concat(Uint8Array.of(0x19), prefix, msg)
  const hash = bls.keccak256(bytesToHex(input), 1).hash
  const raw = signPersonnal(privateKey, hash, true)
  return add0x(withEthereumRecoveryId(raw))
}

function withEthereumRecoveryId(signature: string): string {
  const hex = strip0x(signature).toLowerCase()
  if (hex.length < 130) return hex
  const v = parseInt(hex.slice(128, 130), 16)
  if (v === 0 || v === 1) {
    return hex.slice(0, 128) + (v + 27).toString(16).padStart(2, '0')
  }
  return hex
}

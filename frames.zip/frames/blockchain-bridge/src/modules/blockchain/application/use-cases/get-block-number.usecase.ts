import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { BlockGateway } from '../../domain/gateways/block.gateway'

export class GetBlockNumberUseCase implements IUseCase<void, number> {
  constructor(private readonly blockGateway: BlockGateway) {}

  async execute(): Promise<number> {
    const hexNumber = await this.blockGateway.getBlockNumber()
    return parseInt(hexNumber, 16)
  }
}

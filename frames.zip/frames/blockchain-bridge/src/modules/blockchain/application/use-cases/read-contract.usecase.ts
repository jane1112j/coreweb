import type { ContractGateway } from '../../domain/gateways/contract.gateway'
import type { TransactionPolicyService } from '../../domain/services/transaction-policy.service'
import type { TransactionEncoder } from '../../infrastructure/protocol/transaction/transaction-encoder'
import type { TransactionDecoder } from '../../infrastructure/protocol/transaction/transaction-decoder'
import type { SendTransactionRequest } from '../dto/send-transaction.dto'
import { utils } from '@metanodejs/fiai-sdk'

export class ReadContractUseCase {
  constructor(
    private readonly contractGateway: ContractGateway,
    private readonly policyService: TransactionPolicyService,
    private readonly encoder: TransactionEncoder,
    private readonly decoder: TransactionDecoder,
  ) {}

  async execute(params: SendTransactionRequest, customDecode?: (...arg: any) => void) {
    const { to, from, abiData, functionName, inputArray } = params

    const formattedTo = utils.formatAddress(to)
    const formattedFrom = from ? utils.formatAddress(from) : from

    this.policyService.validateToAddress(formattedTo, 'GESC')
    this.policyService.validateAbiData(abiData)

    const callData = this.encoder.encode(abiData, functionName, inputArray || [])

    // Perform eth_call via contract gateway
    console.log('thanhduy call 1')
    const rawResult = await this.contractGateway.call({
      from: formattedFrom,
      to: formattedTo,
      data: `0x${callData}`,
    })
    console.log('thanhduy call 2')

    // Decode the result
    const data = customDecode
      ? customDecode(rawResult, abiData, functionName)
      : this.decoder.decode(rawResult, abiData, functionName)
    // if (!data) throw new Error('Failed to decode contract call result')
    return {
      returnValue: data,
    }
  }
}

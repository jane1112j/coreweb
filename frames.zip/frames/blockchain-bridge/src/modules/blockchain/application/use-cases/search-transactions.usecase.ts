import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { TransactionGateway } from '../../domain/gateways/transaction.gateway'

export interface SearchTransactionsParams {
  offset: number
  limit: number
  queryString: string
}

export class SearchTransactionsUseCase implements IUseCase<SearchTransactionsParams, string> {
  constructor(private readonly transactionGateway: TransactionGateway) {}

  async execute(params: SearchTransactionsParams): Promise<string> {
    return await this.transactionGateway.searchTransactions(params)
  }
}

import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { BlockGateway } from '../../domain/gateways/block.gateway'

export class GetBlockByNumberUseCase implements IUseCase<{ block: string }, string> {
  constructor(private readonly blockGateway: BlockGateway) {}

  async execute(params: { block: string }): Promise<string> {
    return await this.blockGateway.getBlockByNumber(params.block)
  }
}

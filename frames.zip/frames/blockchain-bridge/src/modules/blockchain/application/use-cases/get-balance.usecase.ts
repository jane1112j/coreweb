import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { AccountGateway } from '../../domain/gateways/account.gateway'

export interface GetBalanceParams {
  address: string
}

export interface GetBalanceResponse {
  balance: string
  pendingBalance: string
}

export class GetBalanceUseCase implements IUseCase<GetBalanceParams, GetBalanceResponse> {
  constructor(private readonly accountGateway: AccountGateway) {}

  async execute(params: GetBalanceParams): Promise<GetBalanceResponse> {
    if (!params || !params.address) {
      return {
        balance: '0',
        pendingBalance: '0',
      }
    }

    try {
      const accountState = await this.accountGateway.getAccountState(params.address)
      return {
        balance: accountState.balance,
        pendingBalance: accountState.pendingBalance,
      }
    } catch (error) {
      console.error(
        `[GetBalanceUseCase] Failed to get balance for address ${params.address}:`,
        error,
      )
      return {
        balance: '0',
        pendingBalance: '0',
      }
    }
  }
}

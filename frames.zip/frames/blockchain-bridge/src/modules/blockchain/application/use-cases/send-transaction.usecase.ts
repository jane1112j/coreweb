import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { ReadContractUseCase } from './read-contract.usecase'
import type { ExecuteContractUseCase } from './execute-contract.usecase'
import type { SendTransactionRequest } from '../dto/send-transaction.dto'

export class SendTransactionUseCase implements IUseCase<SendTransactionRequest, any> {
  constructor(
    private readonly readUC: ReadContractUseCase,
    private readonly executeUC: ExecuteContractUseCase,
  ) {}

  async execute(params: SendTransactionRequest): Promise<unknown> {
    switch (params.feeType) {
      case 'read':
        return await this.readUC.execute(params)
      case 'sc':
        return await this.executeUC.execute(params)
      default:
        throw new Error(`Unsupported feeType: `)
    }
  }
}

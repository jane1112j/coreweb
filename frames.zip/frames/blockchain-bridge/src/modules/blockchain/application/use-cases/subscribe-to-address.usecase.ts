import { utils, type IUseCase } from '@metanodejs/fiai-sdk'
import type { WsRpcClient } from '../../infrastructure'

export interface SubscribeToAddressParams {
  toAddress: string | string[]
  fromAddress: string
}

export interface SubscribeToAddressResponse {
  address: string
}

export class SubscribeToAddressUseCase implements IUseCase<
  SubscribeToAddressParams,
  SubscribeToAddressResponse
> {
  constructor(private readonly wsRpcClient: WsRpcClient) {}

  async execute(params: SubscribeToAddressParams): Promise<SubscribeToAddressResponse> {
    const { fromAddress, toAddress } = params
    if (!toAddress || toAddress.length === 0) throw new Error('toAddress is required')
    if (!fromAddress) throw new Error('fromAddress is required')

    const rawAddresses = Array.isArray(toAddress) ? toAddress : [toAddress]
    const subscribedList: string[] = []

    for (const rawAddress of rawAddresses) {
      if (!rawAddress) continue
      const contractAddress = rawAddress.toLowerCase().trim()
      const normalizedAddress = utils.formatAddress(contractAddress)

      try {
        await this.wsRpcClient.subscribeToAddress(normalizedAddress)
        subscribedList.push(normalizedAddress)
      } catch (error: any) {
        console.error(
          `[SubscribeToAddressUseCase] Failed to subscribe to address ${normalizedAddress}:`,
          error,
        )
      }
    }

    if (subscribedList.length === 0) throw new Error('Failed to subscribe to any address')

    return {
      address: fromAddress,
    }
  }
}

import type { IUseCase } from '@metanodejs/fiai-sdk'
import type { AccountGateway } from '../../domain/gateways/account.gateway'
import { utils } from '@metanodejs/fiai-sdk'
export interface GetBalanceByAddressParams {
  addresses: string[]
}

export interface WalletBalanceInfo {
  address: string
  balance: string
  pendingBalance: string
}

export class GetBalanceByAddressUseCase implements IUseCase<
  GetBalanceByAddressParams,
  WalletBalanceInfo[]
> {
  constructor(private readonly accountGateway: AccountGateway) {}

  async execute(params: GetBalanceByAddressParams): Promise<WalletBalanceInfo[]> {
    if (!params || !params.addresses || !Array.isArray(params.addresses)) {
      return []
    }

    const results = await Promise.all(
      params.addresses.map(async (address) => {
        try {
          const accountState = await this.accountGateway.getAccountState(
            utils.formatAddress(address),
          )
          return {
            address,
            balance: accountState.balance,
            pendingBalance: accountState.pendingBalance,
          }
        } catch (error) {
          console.error(
            `[GetBalanceByAddressUseCase] Failed to get balance for address ${address}:`,
            error,
          )
          return {
            address,
            balance: '0',
            pendingBalance: '0',
          }
        }
      }),
    )

    return results
  }
}

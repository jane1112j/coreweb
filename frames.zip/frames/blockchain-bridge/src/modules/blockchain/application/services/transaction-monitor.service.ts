import type { TransactionGateway } from '../../domain/gateways/transaction.gateway'
import type { TransactionReceipt } from '../../domain/entities/transaction.entity'

/** eth_getTransactionReceipt.status: 0x1, 0x01, 1, true, … */
export function isReceiptSuccess(status: unknown): boolean {
  if (status === true || status === 1) return true
  if (status === false || status === 0) return false
  if (typeof status === 'string') {
    const normalized = status.startsWith('0x') || status.startsWith('0X') ? status.slice(2) : status
    if (!normalized) return false
    try {
      return BigInt(`0x${normalized}`) === BigInt(1)
    } catch {
      return normalized === '1'
    }
  }
  return false
}

export class TransactionMonitorService {
  constructor(private readonly transactionGateway: TransactionGateway) {}

  /**
   * Monitor a transaction by polling its receipt until confirmed or max retries reached.
   */
  async monitorTransaction(
    txHash: string,
    maxRetries = 60,
    intervalMs = 50,
  ): Promise<{
    success: boolean
    data?: TransactionReceipt
    message?: string
    code?: number
  }> {
    return new Promise((resolve) => {
      let retries = 0

      const interval = setInterval(async () => {
        try {
          const receipt = await this.transactionGateway.getTransactionReceipt(txHash)
          if (receipt) {
            clearInterval(interval)
            if (isReceiptSuccess(receipt.status)) {
              resolve({
                success: true,
                data: receipt,
                code: 200,
              })
            } else {
              console.warn('[TransactionMonitorService] Transaction reverted', {
                txHash,
                status: receipt.status,
                gasUsed: receipt.gasUsed,
              })
              resolve({
                success: false,
                data: receipt,
                code: 300,
                message: 'Transaction failed (reverted)',
              })
            }
          }
        } catch (error) {
          console.error('[TransactionMonitorService] Error checking receipt:', error)
          clearInterval(interval)
          resolve({
            success: false,
            message: `Error checking receipt: ${error instanceof Error ? error.message : String(error)}`,
            code: 400,
          })
        }

        retries++
        if (retries >= maxRetries) {
          clearInterval(interval)
          resolve({
            success: false,
            message: `Transaction not confirmed after ${(maxRetries * intervalMs) / 1000} seconds`,
            code: 408,
          })
        }
      }, intervalMs)
    })
  }
}

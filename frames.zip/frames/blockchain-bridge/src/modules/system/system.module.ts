import { GenericActionHandler, type ApplicationActionHandler } from '@metanodejs/fiai-sdk'
import { BridgeActions } from '@/core/actions'
import { PingUseCase } from './application/use-cases/ping.usecase'

export class SystemModule {
  public getHandlers(): ApplicationActionHandler[] {
    return [new GenericActionHandler(BridgeActions.PING, new PingUseCase())]
  }
}

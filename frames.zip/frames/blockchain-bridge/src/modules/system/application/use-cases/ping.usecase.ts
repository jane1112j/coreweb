import type { IUseCase } from '@metanodejs/fiai-sdk'

export class PingUseCase implements IUseCase<void, { pong: boolean; timestamp: number }> {
  async execute(): Promise<{ pong: boolean; timestamp: number }> {
    return {
      pong: true,
      timestamp: Date.now(),
    }
  }
}

/**
 * Blockchain Bridge Frame - Clean Architecture with Use Cases
 */
import { BlockchainModule } from '@/modules/blockchain/blockchain.module'
import { SystemModule } from '@/modules/system/system.module'
import { WalletService } from '@/shared/infrastructure/wallet'
import { getBLS, loadBLS } from '@metanodejs/bls-crypto'
import type { ApplicationActionHandler } from '@metanodejs/fiai-sdk'
import { FrameClient } from '@metanodejs/fiai-sdk'
import { loadMetaProto } from '@metanodejs/meta-proto'
import { registerSW } from 'virtual:pwa-register'

// 1. Đọc chain config từ URL hash params (được truyền từ fiai-sdk host)
const hashParams = new URLSearchParams(window.location.hash.substring(1))
const RPC_URL = hashParams.get('rpcUrl')
  ? decodeURIComponent(hashParams.get('rpcUrl'))
  : 'http://192.168.1.234:8747'
const WS_URL = hashParams.get('wsUrl')
  ? decodeURIComponent(hashParams.get('wsUrl'))
  : 'ws://192.168.1.234:8747/ws'
const CHAIN_ID = hashParams.get('chainId') ? Number(hashParams.get('chainId')) : 991 // Sequoia Network Chain ID
const client = new FrameClient('blockchain-bridge')

// 2. Luồng khởi tạo chính
async function bootstrap() {
  try {
    const walletService = new WalletService(client)
    // 3. Khởi tạo BlockchainModule
    const blockchainModule = new BlockchainModule({
      rpcUrl: RPC_URL,
      wsUrl: WS_URL,
      chainId: CHAIN_ID,
      walletService,
      client,
    })

    const systemModule = new SystemModule()

    const handlers: ApplicationActionHandler[] = [
      ...blockchainModule.getHandlers(),
      ...systemModule.getHandlers(),
    ]

    // 4. Nạp Meta Proto & BLS
    await loadMetaProto()
    await loadBLS()
    const bls = getBLS()
    await bls.initBLS()
    bls.init_context()
    // 5. Đăng ký Handlers
    handlers.forEach((handler) => {
      if (!handler || !handler.action) {
        console.warn('[blockchain-bridge] Found invalid handler:', handler)
        return
      }
      client.handle(handler.action, (params: ApplicationActionHandler) => handler.handle(params))
    })

    void client.ready()
  } catch (error) {
    console.error('[blockchain-bridge] Initialization failed:', error)
  }
}

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', bootstrap)
} else {
  void bootstrap()
}
// Đăng ký Service Worker để hỗ trợ Offline
registerSW({
  onNeedRefresh() {
    console.warn('[blockchain-bridge] New version available, please refresh.')
  },
  onOfflineReady() {
    console.warn('[blockchain-bridge] Bridge is ready to work offline.')
  },
})

/**
 * Danh sách các Action thông thường (Request-Response) hỗ trợ bởi Blockchain Bridge.
 */
export const BridgeActions = {
  /** Kiểm tra kết nối bridge */
  PING: 'bridge:ping',
  /** Gửi giao dịch lên blockchain */
  SEND_TRANSACTION: 'sendTransaction',
  /** Lấy số block hiện tại */
  GET_BLOCK_NUMBER: 'getBlockNumber',
  /** Lấy thông tin chi tiết block theo block number */
  GET_BLOCK_BY_NUMBER: 'getBlockByNumber',
  /** Tìm kiếm các giao dịch trên blockchain */
  SEARCH_TRANSACTIONS: 'searchTransactions',
  /** Đăng ký lắng nghe sự kiện của một hoặc nhiều địa chỉ blockchain */
  SUBSCRIBE_TO_ADDRESS: 'subscribeToAddress',
  /** Lấy số dư của địa chỉ blockchain */
  GET_BALANCE_BY_ADDRESS: 'getBalanceByAddress',
  /** Lấy số dư mặc định */
  GET_BALANCE: 'getBalance',
} as const

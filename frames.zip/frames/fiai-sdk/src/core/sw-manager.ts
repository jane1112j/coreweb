export class SWManager {
  private registration: ServiceWorkerRegistration | null = null

  constructor() {}

  async register() {
    if (!('serviceWorker' in navigator)) {
      console.warn('[SWManager] Service Workers are not supported in this browser.')
      return
    }

    try {
      // Tìm xem có Service Worker nào đã được đăng ký cho scope/script này trước đó không
      const registrations = await navigator.serviceWorker.getRegistrations()
      const existingReg = registrations.find(
        (reg) =>
          reg.scope.includes('/runtime/') ||
          (reg.active && reg.active.scriptURL.includes('runtime-sw.js')),
      )

      const isLocal =
        window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'

      try {
        // Thêm query param để ép trình duyệt tải file mới thay vì dùng cache khi online
        // Khi chạy local, dùng 'dev' cố định để tránh tạo registration mới liên tục gây vòng lặp tải
        const swUrl = isLocal ? '/runtime-sw.js?v=dev' : '/runtime-sw.js?v=1.0.2'

        this.registration = await navigator.serviceWorker.register(swUrl, {
          scope: '/runtime/',
        })
      } catch (regError) {
        console.warn('[SWManager] Failed to register/update Service Worker:', regError)

        // Nếu offline hoặc lỗi mạng mà đã có SW hoạt động từ trước, sử dụng tiếp SW cũ
        // Khi chạy local thì bỏ qua fallback cache offline này
        if (!isLocal && existingReg && existingReg.active) {
          this.registration = existingReg
        } else {
          // Nếu không có SW cũ và đăng ký mới thất bại, bắt buộc phải báo lỗi
          throw regError
        }
      }

      // Chờ SW sẵn sàng (Không dùng navigator.serviceWorker.ready vì page ở '/' còn SW scope ở '/runtime/')
      // Việc chờ ready trực tiếp từ navigator.serviceWorker.ready sẽ bị HANG nếu không có SW nào quản lý root '/'
      if (this.registration) {
        const activeWorker =
          this.registration.installing || this.registration.waiting || this.registration.active
        if (activeWorker && activeWorker.state !== 'activated') {
          await new Promise<void>((resolve) => {
            const handler = () => {
              if (activeWorker.state === 'activated') {
                activeWorker.removeEventListener('statechange', handler)
                resolve()
              }
            }
            activeWorker.addEventListener('statechange', handler)
            // Timeout bảo vệ 2s để tránh treo app
            setTimeout(() => {
              activeWorker.removeEventListener('statechange', handler)
              resolve()
            }, 2000)
          })
        }
      }

      // Đảm bảo SW đã kiểm soát page hiện tại (Tránh loop reload)
      // Chỉ kiểm tra controller nếu không chạy local (vì local không đăng ký SW cho root '/')
      if (
        !isLocal &&
        !navigator.serviceWorker.controller &&
        !sessionStorage.getItem('sw_reloaded')
      ) {
        sessionStorage.setItem('sw_reloaded', 'true')
        window.location.reload()
      }
    } catch (error) {
      console.error('[SWManager] Registration failed:', error)
      throw error
    }
  }

  isReady() {
    if (this.registration && this.registration.active) return true
    return !!navigator.serviceWorker.controller
  }
}

export const swManager = new SWManager()

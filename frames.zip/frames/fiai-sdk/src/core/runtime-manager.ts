import { runtimeDb } from '../infrastructure/storage/runtime-db'
import { swManager } from './sw-manager'

export enum RuntimeState {
  IDLE = 'IDLE',
  BOOTING = 'BOOTING',
  MOUNTED = 'MOUNTED',
  SWAPPING = 'SWAPPING',
  ERROR = 'ERROR',
}

export class RuntimeManager {
  private state: RuntimeState = RuntimeState.IDLE
  private activeAppId: string | null = null
  private activeFrame: HTMLIFrameElement | null = null

  constructor() {}

  /**
   * Khởi chạy ứng dụng từ Virtual File System
   */
  async boot(appId: string, version: string, files?: Record<string, any>) {
    try {
      this.setState(RuntimeState.BOOTING)
      console.warn(`[RuntimeManager] Booting ${appId} v${version}...`)
      // 1. Lưu vào Virtual File System (IndexedDB) nếu có tệp mới
      if (files && Object.keys(files).length > 0) {
        await runtimeDb.saveFiles(appId, files)
      }

      // 2. Đảm bảo Service Worker đã sẵn sàng
      if (!swManager.isReady()) {
        await swManager.register()
      }
      // 3. Mount ứng dụng
      await this.mount(appId)
      this.activeAppId = appId
      this.setState(RuntimeState.MOUNTED)
    } catch (error) {
      this.setState(RuntimeState.ERROR)
      throw error
    }
  }

  /**
   * Mount ứng dụng vào #runtime-root sử dụng Iframe để cách ly hoàn toàn (Isolate)
   */
  private async mount(appId: string) {
    const root = document.getElementById('runtime-root')
    if (!root) throw new Error('#runtime-root not found')

    // Tạo frame mới (Double Buffer Pattern: chuẩn bị frame mới trước khi xoá cũ)
    const frame = document.createElement('iframe')
    frame.id = `runtime-${appId}`
    frame.style.width = '100%'
    frame.style.height = '100%'
    frame.style.border = 'none'
    frame.style.display = 'block'

    // Đường dẫn ảo được xử lý bởi Service Worker
    let currentPath = window.location.pathname
    if (currentPath === '/') {
      currentPath = '/index.html'
    }
    const currentSearch = window.location.search
    const currentHash = window.location.hash

    frame.src = `/runtime/${appId}${currentPath}${currentSearch}${currentHash}`

    return new Promise<void>((resolve, reject) => {
      frame.onload = () => {
        // Đảm bảo iframe contentWindow có window.fiaiSDK khi load xong
        if (frame.contentWindow) {
          try {
            const win = frame.contentWindow as any
            win.fiaiSDK = (window as any).fiaiSDK

            // Track route changes
            const saveRoute = () => {
              try {
                const url = win.location.pathname + win.location.search + win.location.hash
                const prefix = `/runtime/${appId}`
                let parentPath = url

                if (url.startsWith(prefix)) {
                  parentPath = url.substring(prefix.length)
                  if (parentPath === '' || parentPath === '/index.html') {
                    parentPath = '/'
                  } else if (parentPath.startsWith('/index.html')) {
                    parentPath = parentPath.substring('/index.html'.length)
                  }

                  if (!parentPath.startsWith('/')) {
                    parentPath = '/' + parentPath
                  }
                }

                const currentParentUrl =
                  window.location.pathname + window.location.search + window.location.hash
                if (currentParentUrl !== parentPath && currentParentUrl !== parentPath + '/') {
                  window.history.replaceState(null, '', parentPath)
                }
              } catch (_err) {
                console.warn('LOG: RuntimeManager [saveRoute] Error: ', _err)
              }
            }

            saveRoute()
            win.addEventListener('hashchange', saveRoute)
            win.addEventListener('popstate', saveRoute)

            const originalPushState = win.history.pushState
            win.history.pushState = function (this: any, ...args: any[]) {
              originalPushState.apply(this, args)
              saveRoute()
            }

            const originalReplaceState = win.history.replaceState
            win.history.replaceState = function (this: any, ...args: any[]) {
              originalReplaceState.apply(this, args)
              saveRoute()
            }
          } catch (e) {
            console.error('[RuntimeManager] Failed to inject fiaiSDK on load:', e)
          }
        }

        // Thực hiện Swap: Xoá frame cũ nếu có
        if (this.activeFrame && this.activeFrame !== frame) {
          this.activeFrame.remove()
        }
        this.activeFrame = frame
        resolve()
      }
      // eslint-disable-next-line @typescript-eslint/prefer-promise-reject-errors
      frame.onerror = (e) => reject(e)

      root.appendChild(frame)

      // Cố gắng inject ngay lập tức khi vừa append để đảm bảo script chạy sớm có fiaiSDK
      if (frame.contentWindow) {
        try {
          ;(frame.contentWindow as any).fiaiSDK = (window as any).fiaiSDK
        } catch (e) {
          console.error('[RuntimeManager] Failed to inject fiaiSDK immediately:', e)
        }
      }
    })
  }

  private setState(state: RuntimeState) {
    this.state = state
  }

  getState() {
    return this.state
  }

  getActiveAppId() {
    return this.activeAppId
  }
}

export const runtimeManager = new RuntimeManager()

export type ChainType = 'public' | 'private'

export interface ChainConfig {
  rpcUrl: string
  wsUrl: string
  chainId: number
}

/** Cấu hình mặc định: Public Chain (Sequoia Network) */
export const PUBLIC_CHAIN_CONFIG: ChainConfig = {
  rpcUrl: 'http://192.168.1.234:8747',
  wsUrl: 'ws://192.168.1.234:8747/ws',
  chainId: 991,
}

/** Cấu hình Private Chain */
export const PRIVATE_CHAIN_CONFIG: ChainConfig = {
  rpcUrl: 'https://dqit.vn:8666',
  wsUrl: 'wss://dqit.vn:8666',
  chainId: 991,
}

/**
 * Mapping domain → chain config.
 * Domain KHÔNG có trong map này sẽ dùng PUBLIC_CHAIN_CONFIG mặc định.
 */
export const DOMAIN_CHAIN_MAP: Record<string, ChainConfig> = {
  'dqit.vn': PRIVATE_CHAIN_CONFIG,
  'chat-free-gas.fi.ai': PRIVATE_CHAIN_CONFIG,
  // Thêm các domain sử dụng private chain ở đây
}

/** Lấy chain config cho một domain */
export function getChainConfigForDomain(domain: string): ChainConfig {
  return DOMAIN_CHAIN_MAP[domain] ?? PUBLIC_CHAIN_CONFIG
}

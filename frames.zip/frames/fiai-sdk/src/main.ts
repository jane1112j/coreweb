import { FiaiSDK } from '@metanodejs/fiai-sdk'
import { getChainConfigForDomain } from './core/chain-config'
import { swManager } from './core/sw-manager'
import { runtimeManager } from './core/runtime-manager'
import { runtimeDb } from './infrastructure/storage/runtime-db'
import { ShellLoader } from './ui/ShellLoader'
import { registerSW } from 'virtual:pwa-register'

/**
 * Host OS Kernel Initialization
 */

const DOMAIN = window.location.hostname
async function bootKernel() {
  const shellLoader = new ShellLoader()

  const updateStatus = (text: string) => {
    shellLoader.setStatus(text)
    console.warn(`[Kernel] ${text}`)
  }

  try {
    // 1. Initialize Service Worker (Virtual File System Proxy)
    updateStatus('Initializing Virtual File System...')
    await swManager.register()

    // 2. Initialize FiaiSDK (Kernel Communication Layer)
    updateStatus('Connecting to SDK Services...')
    const chainConfig = getChainConfigForDomain(DOMAIN)
    const sdk = await FiaiSDK.init({ chainConfig })
    ;(window as any).fiaiSDK = sdk
    // Hàm helper để boot app
    const bootApp = async (id: string, version: string, files: any) => {
      updateStatus(`Booting Application v${version}...`)

      // Lưu manifest vào IndexedDB để lần sau check hasCachedFiles
      console.warn('[fiai-sdk] KHAIHOAN DEBUG - DOMAIN TO CHECK', DOMAIN)
      await runtimeDb.manifests.put({
        id,
        domain: DOMAIN,
        version,
        createdAt: Date.now(),
        hash: '',
      })
      await runtimeManager.boot(id, version, files)
      updateStatus(`Application v${version} is running.`)

      shellLoader.hide()
      updateStatus('Kernel and Runtime Ready.')
    }

    // Lắng nghe tiến độ tải (nếu có update)
    sdk.on('on-process-download-file', (data: any) => {
      updateStatus(`Downloading update: ${data.percent}%`)
    })

    // 3. Đăng ký listener trước để tránh race condition (sync xong trước khi Kernel kịp nghe)
    let unsubscribeReady = () => {}
    let unsubscribeError = () => {}

    const onRuntimeReady = async (data: any) => {
      console.warn('[Kernel] Runtime is ready from background sync:', data.version)
      unsubscribeError()
      await bootApp(data.id, data.version, data.files)
    }
    const onRuntimeError = (data: any) => {
      console.error('[Kernel] Runtime sync error:', data.message)
      unsubscribeReady()
      shellLoader.showError(data.message ?? 'Unknown sync error')
    }

    unsubscribeReady = sdk.once('runtime-ready', onRuntimeReady)
    unsubscribeError = sdk.once('runtime-error', onRuntimeError)

    // 4. Kiểm tra thông tin domain
    updateStatus('Checking for updates...')
    const manifest = await runtimeDb.manifests.where('domain').equals(DOMAIN).first()
    const hasCachedFiles = manifest
      ? (await runtimeDb.files.where('appId').equals(manifest.id).count()) > 0
      : false

    const response = await sdk.request<any>('getDomainInfo', {
      domain: DOMAIN,
      hasCachedFiles,
    })

    if (response.updateNeeded) {
      // Cần update, listener đã được đăng ký ở bước 3 sẽ tự động xử lý khi xong
      updateStatus('Update required. Syncing assets...')
    } else {
      // Huỷ listener đã đăng ký ở bước 3 vì chúng ta sẽ boot trực tiếp từ cache
      unsubscribeReady()
      unsubscribeError()

      // Version đã khớp và có sẵn files trong cache (hoặc đang offline)
      // Nếu response.files không được trả về (đã tối ưu hóa), bootApp vẫn chạy hoàn hảo vì files đã lưu trong runtimeDb
      await bootApp(response.id, response.version, response.files)
    }
  } catch (error: any) {
    console.error('[Kernel] Critical Boot Error:', error)
    const message = error instanceof Error ? error.message : String(error)
    shellLoader.showError(message)
  }
}

// Start the kernel
if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', bootKernel)
} else {
  void bootKernel()
}
registerSW({
  onNeedRefresh() {
    console.warn('[fiai-sdk] New version available, please refresh.')
  },
  onOfflineReady() {
    console.warn('[fiai-sdk] Shell is ready to work offline.')
  },
})

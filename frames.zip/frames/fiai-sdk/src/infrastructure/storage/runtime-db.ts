import Dexie, { type Table } from 'dexie'

export interface RuntimeManifest {
  id: string
  domain: string
  version: string
  hash: string
  createdAt: number
}

export interface RuntimeFile {
  id?: number
  appId: string
  path: string
  content: ArrayBuffer | Blob
  mimeType: string
}

export interface RuntimePackage {
  appId: string
  version: string
  blob: Blob
}

export class RuntimeDB extends Dexie {
  manifests!: Table<RuntimeManifest>
  files!: Table<RuntimeFile>
  packages!: Table<RuntimePackage>

  constructor() {
    super('fiai-runtime-vfs')
    this.version(100).stores({
      manifests: 'id, domain, version',
      files: '++id, [appId+path], appId',
      packages: 'appId, version',
    })
  }

  /**
   * Lưu trữ toàn bộ package files vào Virtual File System
   */
  async saveFiles(appId: string, files: Record<string, any>) {
    const fileEntries: RuntimeFile[] = []

    for (const [path, content] of Object.entries(files)) {
      let data: any = content
      if (content && content.data && Array.isArray(content.data)) {
        data = new Uint8Array(content.data).buffer
      } else if (content instanceof Uint8Array) {
        data = content.buffer
      } else if (typeof content === 'string') {
        data = new TextEncoder().encode(content).buffer
      }

      fileEntries.push({
        appId,
        path: path.startsWith('/') ? path.substring(1) : path,
        content: data,
        mimeType: this.getMimeType(path),
      })
    }

    // Xoá file cũ của app này trước khi lưu mới (tránh rác)
    await this.files.where('appId').equals(appId).delete()
    await this.files.bulkAdd(fileEntries)
  }

  async getFile(appId: string, path: string) {
    const cleanPath = path.startsWith('/') ? path.substring(1) : path
    return await this.files.where({ appId, path: cleanPath }).first()
  }

  private getMimeType(path: string): string {
    const ext = path.split('.').pop()?.toLowerCase()
    switch (ext) {
      case 'html':
        return 'text/html'
      case 'js':
        return 'application/javascript'
      case 'css':
        return 'text/css'
      case 'json':
        return 'application/json'
      case 'png':
        return 'image/png'
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg'
      case 'gif':
        return 'image/gif'
      case 'svg':
        return 'image/svg+xml'
      case 'webp':
        return 'image/webp'
      case 'wasm':
        return 'application/wasm'
      default:
        return 'application/octet-stream'
    }
  }
}

export const runtimeDb = new RuntimeDB()

const FADE_OUT_MS = 500

const escapeHtml = (value: string): string =>
  value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')

export class ShellLoader {
  private readonly root = document.getElementById('shell-loading')
  private readonly status = document.getElementById('shell-status')
  private readonly graphic = this.root?.querySelector<HTMLElement>('.shell-loader__graphic') ?? null
  private readonly copy = this.root?.querySelector<HTMLElement>('.shell-loader__copy') ?? null
  private tooltip: HTMLDivElement | null = null

  constructor() {
    this.setupTooltip()
  }

  setStatus(text: string): void {
    if (this.status) {
      this.status.textContent = text
    }
    if (this.tooltip) {
      this.tooltip.textContent = `Loading ${text}`
    }
  }

  hide(): void {
    if (!this.root) return

    this.root.style.opacity = '0'
    window.setTimeout(() => {
      if (this.root) {
        this.root.style.display = 'none'
      }
      this.destroyTooltip()
    }, FADE_OUT_MS)
  }

  showError(message: string): void {
    if (this.graphic) {
      this.graphic.style.display = 'none'
    }
    this.destroyTooltip()

    if (this.copy) {
      this.copy.innerHTML = `
        <div class="shell-loader__error-card">
          <h2 class="shell-loader__error-title">Boot Failure</h2>
          <p class="shell-loader__error-message">${escapeHtml(message)}</p>
          <button type="button" class="shell-loader__error-action" id="shell-loader-retry">
            Reload System
          </button>
        </div>
      `

      const retryButton = this.copy.querySelector<HTMLButtonElement>('#shell-loader-retry')
      retryButton?.addEventListener('click', () => {
        window.location.reload()
      })
    }
  }

  private setupTooltip(): void {
    if (!this.root) return

    const tooltip = document.createElement('div')
    tooltip.className = 'shell-loader__tooltip'
    tooltip.textContent = 'Loading...'
    document.body.appendChild(tooltip)
    this.tooltip = tooltip

    this.root.addEventListener('mouseenter', this.handleMouseEnter)
    this.root.addEventListener('mouseleave', this.handleMouseLeave)
    this.root.addEventListener('mousemove', this.handleMouseMove)
  }

  private destroyTooltip(): void {
    if (this.root) {
      this.root.removeEventListener('mouseenter', this.handleMouseEnter)
      this.root.removeEventListener('mouseleave', this.handleMouseLeave)
      this.root.removeEventListener('mousemove', this.handleMouseMove)
    }
    this.tooltip?.remove()
    this.tooltip = null
  }

  private handleMouseEnter = (): void => {
    if (this.tooltip) {
      this.tooltip.style.opacity = '1'
    }
  }

  private handleMouseLeave = (): void => {
    if (this.tooltip) {
      this.tooltip.style.opacity = '0'
    }
  }

  private handleMouseMove = (event: MouseEvent): void => {
    if (!this.tooltip) return

    this.tooltip.style.left = `${event.clientX}px`
    this.tooltip.style.top = `${event.clientY}px`
  }
}

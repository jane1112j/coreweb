# FIAI SDK Framework

The **FIAI SDK** is the core orchestration framework and runtime environment of the Metanode ecosystem. It acts as the "Operating System" for decentralized applications, managing their lifecycle from discovery to execution.

## Application Loading Workflow

The SDK implements a robust loading sequence to ensure dApp integrity and performance:

1.  **Request Initiation**: The SDK triggers the `file-processor` module to fetch the target application's JSON manifest and assets.
2.  **Resource Sync**: It monitors the download and extraction progress of the `zip`/`gzip` bundle.
3.  **Content Handshake**: Once extraction is complete, the `file-processor` returns the processed `HTML` and `Body` content back to the SDK.
4.  **Runtime Injection**: The SDK dynamically replaces the current window's DOM with the new content, effectively "booting" the application in a clean environment.

## Key Features

- **Dynamic Hot-Swapping**: Seamlessly transition between different dApps without full page reloads.
- **Secure Sandboxing**: Provides an isolated environment for dApp execution while maintaining bridge access to secure frames.
- **Event Orchestration**: Routes messages between the dApp, the **Crypto Vault**, and the **Blockchain Bridge**.

## Technical Implementation

### Core Messaging Layer

The framework is built upon [`@metanodejs/fiai-sdk`](https://www.npmjs.com/package/@metanodejs/fiai-sdk), which handles the complex `postMessage` routing and response matching required for cross-frame communication.

### Execution Context

The SDK maintains a global state and provides the `FiaiSDK` global object to injected applications, allowing them to interact with native Metanode services (Vault, Bridge, Processor) via a standardized API.

---

_Crafted with 🖤 by the Metanode Core Team_

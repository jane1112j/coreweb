/**
 * Fiai Runtime Service Worker
 * Acts as a Virtual File System Proxy for Runtime Apps
 */

const DB_NAME = 'fiai-runtime-vfs'
const DB_VERSION = 100

// Mở IndexedDB từ SW (Tự động thích ứng với version cao nhất từ Kernel)
function openDB() {
  return new Promise((resolve, reject) => {
    // Không truyền version để tránh lỗi VersionError khi Kernel nâng cấp
    const request = indexedDB.open(DB_NAME)
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
  })
}

// Lấy file từ IndexedDB
async function getFileFromDB(appId, path) {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['files'], 'readonly')
    const store = transaction.objectStore('files')
    const index = store.index('[appId+path]')
    const request = index.get([appId, path])

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
  })
}

self.addEventListener('install', (event) => {
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim())
})

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url)

  // Chỉ xử lý các request bắt đầu bằng /runtime/
  if (url.pathname.startsWith('/runtime/')) {
    event.respondWith(handleRuntimeRequest(event.request))
  }
})

async function handleRuntimeRequest(request) {
  const url = new URL(request.url)
  const parts = url.pathname.split('/').filter(Boolean) // ['', 'runtime', 'appId', 'path...']

  if (parts.length < 2) return fetch(request)

  const appId = parts[1]
  let filePath = parts.slice(2).join('/') || 'index.html'

  try {
    let fileRecord = await getFileFromDB(appId, filePath)

    // Hỗ trợ Base Path/Subfolder fallback: Nếu không tìm thấy file, thử bỏ segment đầu tiên (ví dụ: order.iqr.net/assets/index.js -> assets/index.js)
    if (!fileRecord && filePath.includes('/')) {
      const pathParts = filePath.split('/')
      if (pathParts.length > 1) {
        const fallbackPath = pathParts.slice(1).join('/')
        fileRecord = await getFileFromDB(appId, fallbackPath)
      }
    }

    // Hỗ trợ SPA Routing: Nếu không tìm thấy file, thử trả về index.html
    if (!fileRecord && !filePath.includes('.')) {
      fileRecord = await getFileFromDB(appId, 'index.html')
    }

    if (fileRecord) {
      return new Response(fileRecord.content, {
        headers: { 'Content-Type': fileRecord.mimeType },
      })
    }

    // Nếu vẫn không thấy, fallback ra network
    return fetch(request)
  } catch (error) {
    console.error('[SW] Error fetching from Virtual File System:', error)
    return fetch(request)
  }
}


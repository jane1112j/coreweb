import { defineConfig, loadEnv } from 'vite'
import { VitePWA } from 'vite-plugin-pwa'
import path from 'path'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, path.resolve(__dirname, '../../'), '')

  return {
    define: {
      'process.env.FIAI_BLOCKCHAIN_BRIDGE_URL': JSON.stringify(
        env.FIAI_BLOCKCHAIN_BRIDGE_URL || '',
      ),
      'process.env.FIAI_CRYPTO_VAULT_URL': JSON.stringify(env.FIAI_CRYPTO_VAULT_URL || ''),
      'process.env.FIAI_FILE_PROCESSOR_URL': JSON.stringify(env.FIAI_FILE_PROCESSOR_URL || ''),
      'process.env.VITE_URL_CONNECT_WALLET': JSON.stringify(env.VITE_URL_CONNECT_WALLET || ''),
      'process.env': {},
    },
    base: './',
    envDir: '../../',
    optimizeDeps: {
      exclude: ['@metanodejs/fiai-sdk'],
    },
    plugins: [
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.svg', 'icons.svg', 'runtime-sw.js', 'sdk-docs.md'],
        manifest: {
          name: 'Metanode Shell',
          short_name: 'Shell',
          description: 'Kernel and Runtime for Metanode',
          theme_color: '#000000',
          icons: [{ src: 'favicon.svg', sizes: 'any', type: 'image/svg+xml' }],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,wasm,txt,md}'],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: { maxEntries: 10, maxAgeSeconds: 60 * 60 * 24 * 365 },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
          ],
        },
      } as any),
    ],
    resolve: {
      alias: {
        '~': path.resolve(__dirname, '../../packages/fiai-sdk/src'),
      },
    },
    server: {
      port: 3004,
      cors: true,
      host: '0.0.0.0',
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
    },
  }
})

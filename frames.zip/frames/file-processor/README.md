# File Processor Module

The **File Processor** is an essential resource management service that enables offline capabilities for Metanode decentralized applications. It handles the retrieval, validation, and local persistence of application bundles and assets.

## Core Responsibilities

- **Manifest Validation**: Downloads and parses JSON manifests (e.g., from `https://json.fi.ai/`) to check for application metadata and version updates.
- **Bundle Extraction**: Automatically handles the decompression of `zip` and `gzip` archives containing dApp source code and assets.
- **Offline Persistence**: Stores extracted files into high-performance local storage, allowing applications to load instantaneously without an internet connection.
- **Version Management**: Compares local and remote versions to ensure the user is always running the latest verified build.

## Example Manifest

The processor consumes JSON manifests structured as follows:

```json
{
  "name": "Cyber manager test",
  "version": "1.9.18",
  "hash": "0x3aac6c9b9e42488fb2e3...",
  "pubKey": "927C8F340255D5A2D7B...",
  "sign": "0x83ec8f6ce7ee249c40...",
  "id": "meta.cyber-manager-test",
  "urlZip": "https://json.fi.ai/zip/..."
}
```

## Supported API Actions

| Action             | Description                                                  | Parameters                |
| :----------------- | :----------------------------------------------------------- | :------------------------ |
| `syncApplication`  | Initiates the manifest check and download process.           | `manifestUrl`, `targetId` |
| `extractBundle`    | Manually triggers the decompression of a downloaded archive. | `fileId`, `type`          |
| `getOfflineStatus` | Checks if a specific application is ready for offline use.   | `appId`                   |
| `purgeAppCache`    | Removes stored files for a specific application.             | `appId`                   |

## Technical Implementation

### Communication Layer

The processor utilizes [`@metanodejs/fiai-sdk`](https://www.npmjs.com/package/@metanodejs/fiai-sdk) to receive processing commands from the host application and report download progress.

### Storage Architecture

Assets are stored using a combination of **OPFS** (for large binary files) and **IndexedDB** (for file metadata and mapping). This hybrid approach ensures that dApp loading remains performant even with thousands of small files.

---

_Crafted with 🖤 by Metanode Core Team_

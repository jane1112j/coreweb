# File Processor Module

The **File Processor** is an essential resource management service that provides file handling, image processing, and domain information retrieval capabilities for Metanode decentralized applications.

## Core Responsibilities

- **Domain Info Resolution**: Retrieves application metadata, version updates, and manifests based on domain names.
- **File Management**: Uploads and manages files within the local environment.
- **Image Processing**: Processes images with specific effects.

## Supported API Actions

| Action          | Description                                                   | Parameters          |
| :-------------- | :------------------------------------------------------------ | :------------------ |
| `file:ping`     | Checks if the file processor frame is alive.                  | None                |
| `getDomainInfo` | Retrieves information, version, and files for a given domain. | `domain`            |
| `uploadFile`    | Initiates a file upload process.                              | `filename`          |
| `processImage`  | Applies effects to a specified image.                         | `imageId`, `effect` |

## Technical Implementation

### Communication Layer

The processor utilizes [`@metanodejs/fiai-sdk`](https://www.npmjs.com/package/@metanodejs/fiai-sdk) to receive processing commands from the host application.

---

_Crafted with 🖤 by the Metanode Core Team_

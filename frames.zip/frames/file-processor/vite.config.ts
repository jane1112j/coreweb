import { execSync } from 'child_process'
import path from 'path'
import { defineConfig, type UserConfig } from 'vite'
import { VitePWA } from 'vite-plugin-pwa'
import pkg from './package.json'
// import basicSsl from "@vitejs/plugin-basic-ssl"

let commitCount = '0'
try {
  commitCount = execSync('git rev-list --count HEAD').toString().trim()
} catch (_e) {
  console.error(_e)
}
process.env.VITE_APP_VERSION = `${pkg.version}.${commitCount}`

export default defineConfig({
  base: './',
  envDir: '../../',
  optimizeDeps: {
    exclude: ['@metanodejs/fiai-sdk'],
  },
  plugins: [
    // basicSsl(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: [
        'favicon.svg',
        'icons.svg',
        'lucide.min.js',
        'marked.min.js',
        'processor-docs.md',
      ],
      manifest: {
        name: 'Metanode File Processor',
        short_name: 'Processor',
        description: 'Resource management and offline processing for Metanode',
        theme_color: '#000000',
        icons: [
          { src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,wasm,txt,md}'],
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'google-fonts-cache',
              expiration: { maxEntries: 10, maxAgeSeconds: 60 * 60 * 24 * 365 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
        ],
      },
    } as any),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@shared': path.resolve(__dirname, './src/shared'),
      '@modules': path.resolve(__dirname, './src/modules'),
    },
  },
  server: {
    port: 3003,
    cors: true,
    host: '0.0.0.0',
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
} as UserConfig)

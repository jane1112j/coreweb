/**
 * HttpClient chuyên dụng cho việc tải dữ liệu JSON và Binary (ZIP)
 */
export class HttpClient {
  /**
   * Tải dữ liệu JSON
   */
  async getJson<T>(url: string): Promise<T> {
    const response = await fetch(`${url}?t=${Date.now()}`)
    if (!response.ok) {
      throw new Error(`Failed to fetch JSON: ${response.statusText} (${url})`)
    }
    return response.json()
  }

  /**
   * Tải dữ liệu Binary (ArrayBuffer) - phù hợp cho file ZIP
   */
  async getBinary(url: string, onProgress?: (percent: number) => void): Promise<ArrayBuffer> {
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Failed to fetch binary: ${response.statusText} (${url})`)
    }

    if (!onProgress || !response.body) {
      return response.arrayBuffer()
    }

    // Xử lý progress nếu cần (đọc từ stream)
    const contentLength = response.headers.get('content-length')
    const total = contentLength ? parseInt(contentLength, 10) : 0
    let loaded = 0

    const reader = response.body.getReader()
    const chunks: Uint8Array[] = []

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      chunks.push(value)
      loaded += value.length

      if (total > 0) {
        onProgress(Math.round((loaded / total) * 100))
      }
    }

    const result = new Uint8Array(loaded)
    let offset = 0
    for (const chunk of chunks) {
      result.set(chunk, offset)
      offset += chunk.length
    }

    return result.buffer
  }
}

import { getBLS } from '@metanodejs/bls-crypto'

/**
 * Kết quả xác minh file
 */
export interface VerifyFileHashResult {
  /** Hash thực tế của file (keccak256) */
  actualHash: string
  /** Hash mong đợi từ metadata */
  expectedHash: string
  /** Hash có khớp không */
  hashMatch: boolean
  /** Chữ ký BLS có hợp lệ không */
  signatureValid: boolean
  /** Tổng kết: cả hash + signature đều OK */
  valid: boolean
}

/**
 * Service xác minh tính toàn vẹn file bằng keccak256 hash và BLS signature.
 *
 * Flow:
 * 1. Đọc file binary → chuyển thành hex string (byteToHex)
 * 2. Tính hash keccak256 từ hex string
 * 3. So sánh hash với giá trị mong đợi từ manifest metadata
 * 4. Xác minh chữ ký BLS: verifySign(hash, pubKey, signature)
 */
export class VerifyFileHashService {
  /**
   * Chuẩn hóa chuỗi hex: bỏ prefix 0x và chuyển lowercase
   */
  private normalizeHex(hex: string): string {
    return hex.replace(/^0x/i, '').toLowerCase()
  }

  /**
   * Tính keccak256 hash từ ArrayBuffer, hỗ trợ file lớn qua streaming chunks.
   *
   * @param data - Dữ liệu binary (ArrayBuffer)
   * @param onProgress - Callback tiến trình (loaded, total, percent)
   * @returns Hash keccak256 dạng hex (không có prefix 0x)
   */
  async hashFile(
    data: ArrayBuffer,
    onProgress?: (loaded: number, total: number, percent: number) => void,
  ): Promise<string> {
    try {
      const bls = getBLS()
      if (!bls) {
        throw new Error('BLS crypto module is not initialized')
      }

      // Try streaming keccak256File first (with a timeout/fallback)
      if (typeof (bls as any).keccak256File === 'function') {
        try {
          // Wrap keccak256File in a promise with timeout to prevent hanging
          const hashPromise = (bls as any).keccak256File(data, 1048576, onProgress)
          const timeoutPromise = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Hashing timeout (30s exceeded)')), 30000),
          )
          const result = await Promise.race([hashPromise, timeoutPromise])
          if (result && result.hash) {
            return result.hash.toLowerCase()
          }
        } catch (streamErr) {
          console.warn(
            '[VerifyFileHashService] Streaming hash failed, falling back to direct hash:',
            streamErr,
          )
        }
      }

      // Fallback: byteToHex + keccak256
      if (onProgress) onProgress(0, data.byteLength, 0)
      const hex = bls.byteToHex(new Uint8Array(data))
      if (onProgress) onProgress(data.byteLength, data.byteLength, 100)

      const result = bls.keccak256(hex, 1)
      if (!result || !result.hash) {
        throw new Error('Keccak256 hash generation returned empty result')
      }
      return result.hash.toLowerCase()
    } catch (error: any) {
      console.error('[VerifyFileHashService] hashFile error:', error)
      throw new Error(`Failed to calculate file hash: ${error.message || error}`, { cause: error })
    }
  }

  /**
   * Xác minh hash của file buffer so với hash mong đợi.
   *
   * @param data - Dữ liệu binary (ArrayBuffer)
   * @param expectedHash - Hash mong đợi từ manifest (có thể có prefix 0x)
   * @returns true nếu hash khớp
   */
  async verifyHash(data: ArrayBuffer, expectedHash: string): Promise<boolean> {
    try {
      const actualHash = await this.hashFile(data)
      const normalizedExpected = this.normalizeHex(expectedHash)
      return actualHash === normalizedExpected
    } catch (error) {
      console.error('[VerifyFileHashService] verifyHash error:', error)
      return false
    }
  }

  /**
   * Xác minh chữ ký BLS.
   *
   * @param hash - Hash keccak256 của file (hex, không có prefix 0x)
   * @param pubKey - Public key của signer (hex, 96 chars)
   * @param signature - Chữ ký BLS (hex, có thể có prefix 0x)
   * @returns true nếu chữ ký hợp lệ
   */
  verifySignature(hash: string, pubKey: string, signature: string): boolean {
    const bls = getBLS()
    if (!bls) {
      throw new Error('BLS crypto module is not initialized')
    }
    const normalizedHash = this.normalizeHex(hash)
    const normalizedPubKey = this.normalizeHex(pubKey)
    const normalizedSignature = this.normalizeHex(signature)

    const result = bls.verifySign(normalizedHash, normalizedPubKey, normalizedSignature)

    // verifySign trả về object { verify: boolean } hoặc boolean tuỳ version
    if (typeof result === 'boolean') {
      return result
    }
    return (result as any).verify === true
  }

  /**
   * Xác minh toàn diện: hash + chữ ký BLS.
   *
   * @param data - Dữ liệu binary (ArrayBuffer) của file đã tải
   * @param expectedHash - Hash mong đợi từ manifest metadata (ví dụ: "0x1fce77...")
   * @param pubKey - Public key của signer (hex string)
   * @param signature - Chữ ký BLS từ manifest (ví dụ: "0x8954e5...")
   * @param onProgress - Callback tiến trình hashing (optional)
   * @returns Kết quả xác minh chi tiết
   */
  async verify(
    data: ArrayBuffer,
    expectedHash: string,
    pubKey: string,
    signature: string,
    onProgress?: (loaded: number, total: number, percent: number) => void,
  ): Promise<VerifyFileHashResult> {
    try {
      // 1. Tính hash keccak256 của file
      const actualHash = await this.hashFile(data, onProgress)
      const normalizedExpected = this.normalizeHex(expectedHash)
      const hashMatch = actualHash === normalizedExpected

      // 2. Xác minh chữ ký BLS (chỉ khi hash khớp)
      let signatureValid = false
      if (hashMatch && pubKey && signature) {
        try {
          signatureValid = this.verifySignature(actualHash, pubKey, signature)
        } catch (error) {
          console.error('[VerifyFileHashService] Signature verification error:', error)
          signatureValid = false
        }
      }

      const result: VerifyFileHashResult = {
        actualHash: `0x${actualHash}`,
        expectedHash: expectedHash.startsWith('0x') ? expectedHash : `0x${expectedHash}`,
        hashMatch,
        signatureValid,
        valid: hashMatch && signatureValid,
      }

      if (!hashMatch) {
        console.error(
          `[VerifyFileHashService] Hash mismatch!\n  Expected: ${result.expectedHash}\n  Actual:   ${result.actualHash}`,
        )
      }
      if (hashMatch && !signatureValid) {
        console.error('[VerifyFileHashService] BLS signature verification failed!')
      }

      return result
    } catch (error: any) {
      console.error('[VerifyFileHashService] Verification failed with error:', error)
      // Return a failed result instead of hanging or letting it crash silently
      return {
        actualHash: '0x',
        expectedHash: expectedHash.startsWith('0x') ? expectedHash : `0x${expectedHash}`,
        hashMatch: false,
        signatureValid: false,
        valid: false,
      }
    }
  }
}

import JSZip from 'jszip'
import type { UnzippedFiles } from '../storage/storage-strategy'

export class ZipService {
  /**
   * Giải nén ArrayBuffer thành Map các files.
   * Hỗ trợ định dạng ZIP chuẩn, GZIP đơn lẻ, và kho lưu trữ TAR.GZ (.tar.gz).
   */
  async unzip(data: ArrayBuffer, urlZip?: string): Promise<UnzippedFiles> {
    let files: UnzippedFiles = {}

    if (this.isGzip(data)) {
      console.log('[ZipService] Gzip magic bytes detected. Decompressing natively...')
      const decompressed = await this.decompressGzip(data)

      // Kiểm tra xem dữ liệu sau giải nén có phải là một file TAR hay không
      if (this.isTar(decompressed)) {
        console.log('[ZipService] Tar archive detected inside gzip. Parsing tarball...')
        files = this.parseTar(decompressed)
      } else {
        console.log('[ZipService] Single gzip file detected. Returning decompressed file...')
        const filename = this.deriveFilenameFromUrl(urlZip)

        if (/\.(json|html|js|css|txt)$/i.test(filename)) {
          const decoder = new TextDecoder('utf-8')
          files[filename] = decoder.decode(decompressed)
        } else {
          files[filename] = decompressed
        }
      }
    } else {
      // Mặc định giải nén theo định dạng ZIP thông thường sử dụng JSZip
      console.log('[ZipService] Parsing standard zip using JSZip...')
      const zip = await JSZip.loadAsync(data)
      const promises: Promise<void>[] = []

      zip.forEach((relativePath, file) => {
        if (file.dir) return

        const cleanPath = relativePath.replace(/^\.\//, '').replace(/^\//, '')

        const promise = (async () => {
          if (/\.(json|html|js|css|txt)$/i.test(cleanPath)) {
            files[cleanPath] = await file.async('text')
          } else {
            files[cleanPath] = await file.async('arraybuffer')
          }
        })()

        promises.push(promise)
      })

      await Promise.all(promises)
    }

    // Tự động bỏ thư mục gốc dùng chung và dọn dẹp file rác OS
    return this.stripCommonRoot(files)
  }

  /**
   * Kiểm tra Magic bytes của định dạng GZIP (1f 8b)
   */
  private isGzip(data: ArrayBuffer): boolean {
    if (data.byteLength < 2) return false
    const arr = new Uint8Array(data.slice(0, 2))
    return arr[0] === 0x1f && arr[1] === 0x8b
  }

  /**
   * Giải nén file GZIP sử dụng API DecompressionStream có sẵn trên trình duyệt hiện đại
   */
  private async decompressGzip(data: ArrayBuffer): Promise<ArrayBuffer> {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('DecompressionStream is not supported in this browser environment')
    }
    const stream = new Response(data).body
    if (!stream) {
      throw new Error('Gzip stream is null')
    }
    const decompressedStream = stream.pipeThrough(new DecompressionStream('gzip'))
    return await new Response(decompressedStream).arrayBuffer()
  }

  /**
   * Kiểm tra xem data có cấu trúc header của file TAR (USTAR hoặc V7 Tar) hay không
   */
  private isTar(data: ArrayBuffer): boolean {
    if (data.byteLength < 512) return false
    const view = new DataView(data)

    // 1. Kiểm tra ustar signature ở offset 257 (tiêu chuẩn POSIX/UStar)
    let ustarSig = ''
    for (let i = 0; i < 5; i++) {
      ustarSig += String.fromCharCode(view.getUint8(257 + i))
    }
    if (ustarSig === 'ustar') return true

    // 2. Fallback cho tệp Tar V7 cũ: kiểm tra trường kích thước (offset 124, 12 bytes octal)
    let sizeStr = ''
    let hasOctalDigits = false
    for (let i = 0; i < 11; i++) {
      const charCode = view.getUint8(124 + i)
      if (charCode === 0 || charCode === 32) continue
      if (charCode >= 48 && charCode <= 55) {
        sizeStr += String.fromCharCode(charCode)
        hasOctalDigits = true
      } else {
        return false // Có ký tự không hợp lệ cho hệ octal
      }
    }
    return hasOctalDigits && sizeStr.length > 0
  }

  /**
   * Phân tích và trích xuất file từ định dạng TAR POSIX/UStar
   */
  private parseTar(tarBuffer: ArrayBuffer): UnzippedFiles {
    const files: UnzippedFiles = {}
    const view = new DataView(tarBuffer)
    let offset = 0

    while (offset + 512 <= tarBuffer.byteLength) {
      // Kiểm tra xem block 512 bytes có toàn bộ là byte 0 hay không (Ký hiệu kết thúc hoặc khoảng đệm)
      let isAllZero = true
      for (let i = 0; i < 512; i++) {
        if (view.getUint8(offset + i) !== 0) {
          isAllZero = false
          break
        }
      }
      if (isAllZero) {
        offset += 512
        continue
      }

      // Đọc tên tệp tin (100 bytes đầu tiên ở offset 0)
      let name = ''
      for (let i = 0; i < 100; i++) {
        const char = view.getUint8(offset + i)
        if (char === 0) break
        name += String.fromCharCode(char)
      }

      // Đọc kích thước file (12 bytes ở offset 124, định dạng hệ cơ số 8 - octal)
      let sizeStr = ''
      for (let i = 0; i < 12; i++) {
        const char = view.getUint8(offset + 124 + i)
        if (char === 0 || char === 32) continue
        sizeStr += String.fromCharCode(char)
      }
      const size = parseInt(sizeStr, 8)

      // Đọc loại tệp tin (1 byte ở offset 156)
      const typeflag = String.fromCharCode(view.getUint8(offset + 156))

      // UStar prefix check (155 bytes ở offset 345)
      let prefix = ''
      let isUstar = false
      let ustarSig = ''
      for (let i = 0; i < 5; i++) {
        ustarSig += String.fromCharCode(view.getUint8(offset + 257 + i))
      }
      if (ustarSig === 'ustar') {
        isUstar = true
        for (let i = 0; i < 155; i++) {
          const char = view.getUint8(offset + 345 + i)
          if (char === 0) break
          prefix += String.fromCharCode(char)
        }
      }

      let fullPath = name
      if (isUstar && prefix) {
        fullPath = prefix + '/' + name
      }

      // Chuẩn hoá đường dẫn: loại bỏ leading "./" và "/"
      fullPath = fullPath.replace(/^\.\//, '').replace(/^\//, '')

      offset += 512

      // Loại tệp thông thường (typeflag '0' hoặc null byte)
      if (typeflag === '0' || typeflag === '\0') {
        if (size > 0 && offset + size <= tarBuffer.byteLength) {
          const fileData = tarBuffer.slice(offset, offset + size)

          if (/\.(json|html|js|css|txt)$/i.test(fullPath)) {
            const decoder = new TextDecoder('utf-8')
            files[fullPath] = decoder.decode(fileData)
          } else {
            files[fullPath] = fileData
          }
        }
      }

      // Nhảy qua các khối dữ liệu (được đệm vừa đủ block 512 bytes)
      offset += Math.ceil(size / 512) * 512
    }

    return files
  }

  /**
   * Trích xuất tên tệp tin đề xuất từ URL tải về
   */
  private deriveFilenameFromUrl(url?: string): string {
    if (!url) return 'index.js'
    try {
      const parsedUrl = new URL(url)
      const pathname = parsedUrl.pathname
      const lastSegment = pathname.substring(pathname.lastIndexOf('/') + 1)
      if (lastSegment) {
        // Loại bỏ phần mở rộng .gz nếu có
        return lastSegment.replace(/\.gz$/i, '')
      }
    } catch {
      // fallback
    }
    return 'index.js'
  }

  /**
   * Loại bỏ thư mục gốc dùng chung và các file rác OS
   */
  private stripCommonRoot(files: UnzippedFiles): UnzippedFiles {
    // 1. Loại bỏ các file rác OS hoặc header đặc biệt của tarball trước tiên
    const cleanFiles: UnzippedFiles = {}
    for (const [path, content] of Object.entries(files)) {
      const isJunk =
        path.includes('pax_global_header') ||
        path.includes('PaxHeader/') ||
        path.startsWith('._') ||
        path.includes('/._') ||
        path.endsWith('.DS_Store')

      if (!isJunk) {
        cleanFiles[path] = content
      }
    }

    const paths = Object.keys(cleanFiles)
    if (paths.length === 0) return cleanFiles

    // 2. Tìm kiếm thư mục cha dùng chung của toàn bộ tệp tin sạch
    let commonRoot = ''
    const firstPath = paths[0]
    const slashIdx = firstPath.indexOf('/')
    if (slashIdx !== -1) {
      const rootCandidate = firstPath.substring(0, slashIdx + 1) // e.g., "food-order/"

      // Kiểm tra xem tất cả các file sạch có cùng chia sẻ thư mục cha này không
      const allShareRoot = paths.every((p) => p.startsWith(rootCandidate))
      if (allShareRoot) {
        commonRoot = rootCandidate
      }
    }

    // 3. Nếu tìm thấy thư mục chung, loại bỏ nó ra khỏi đường dẫn lưu trữ
    if (commonRoot) {
      console.log(`[ZipService] Stripping common root directory: "${commonRoot}"`)
      const strippedFiles: UnzippedFiles = {}
      for (const [path, content] of Object.entries(cleanFiles)) {
        const strippedPath = path.substring(commonRoot.length)
        if (strippedPath) {
          strippedFiles[strippedPath] = content
        }
      }
      return strippedFiles
    }

    return cleanFiles
  }
}

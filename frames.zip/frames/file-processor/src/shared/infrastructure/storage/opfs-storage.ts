import type { DomainData, StorageStrategy } from './storage-strategy'

/**
 * Cài đặt lưu trữ bằng OPFS (Origin Private File System)
 */
export class OPFSStorage implements StorageStrategy {
  readonly name = 'OPFS'

  async isSupported(): Promise<boolean> {
    return (
      typeof navigator.storage !== 'undefined' &&
      typeof navigator.storage.getDirectory === 'function'
    )
  }

  async save(domain: string, data: DomainData): Promise<void> {
    const root = await navigator.storage.getDirectory()
    const domainDir = await root.getDirectoryHandle(domain, { create: true })

    // Lưu version vào một file riêng
    const versionFile = await domainDir.getFileHandle('version.txt', { create: true })
    const writable = await versionFile.createWritable()
    await writable.write(data.version)
    await writable.close()

    // Lưu id vào một file riêng
    const idFile = await domainDir.getFileHandle('id.txt', { create: true })
    const idWritable = await idFile.createWritable()
    await idWritable.write(data.id)
    await idWritable.close()

    // Lưu các file từ ZIP
    const filesDir = await domainDir.getDirectoryHandle('zip', { create: true })
    for (const [path, content] of Object.entries(data.files)) {
      // Xử lý nested directories nếu path có chứa '/'
      const parts = path.split('/')
      const filename = parts.pop()!
      let currentDir = filesDir

      for (const part of parts) {
        if (!part) continue
        currentDir = await currentDir.getDirectoryHandle(part, { create: true })
      }

      const fileHandle = await currentDir.getFileHandle(filename, { create: true })
      const fw = await fileHandle.createWritable()
      await fw.write(content)
      await fw.close()
    }
  }

  async get(domain: string): Promise<DomainData | null> {
    try {
      const version = await this.getVersion(domain)
      if (!version) return null

      // Trong thực tế, việc đọc toàn bộ 50MB files vào RAM có thể tốn kém
      // Tùy vào yêu cầu, chúng ta có thể chỉ trả về handles hoặc đọc theo yêu cầu
      // Ở đây mình cài đặt đọc hết để khớp với interface đơn giản ban đầu
      const root = await navigator.storage.getDirectory()
      const domainDir = await root.getDirectoryHandle(domain)
      const filesDir = await domainDir.getDirectoryHandle('zip')

      const idFile = await domainDir.getFileHandle('id.txt')
      const id = await (await idFile.getFile()).text()

      const files: Record<string, string | ArrayBuffer> = {}
      await this.readDirRecursive(filesDir, '', files)

      return { id, version, files }
    } catch (e) {
      return null
    }
  }

  async getVersion(domain: string): Promise<string | null> {
    try {
      const root = await navigator.storage.getDirectory()
      const domainDir = await root.getDirectoryHandle(domain)
      const versionFile = await domainDir.getFileHandle('version.txt')
      const file = await versionFile.getFile()
      return await file.text()
    } catch (e) {
      return null
    }
  }

  private async readDirRecursive(
    dirHandle: FileSystemDirectoryHandle,
    basePath: string,
    results: Record<string, any>,
  ) {
    for await (const [name, handle] of (dirHandle as any).entries()) {
      const path = basePath ? `${basePath}/${name}` : name
      if (handle.kind === 'directory') {
        await this.readDirRecursive(handle, path, results)
      } else {
        const file = await handle.getFile()
        // Giả sử text files là .json, .html, .js, .css
        if (/\.(json|html|js|css|txt)$/i.test(name)) {
          results[path] = await file.text()
        } else {
          results[path] = await file.arrayBuffer()
        }
      }
    }
  }
}

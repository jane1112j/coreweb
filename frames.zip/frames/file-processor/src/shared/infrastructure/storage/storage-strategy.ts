export interface UnzippedFiles {
  [path: string]: string | ArrayBuffer | Blob
}

export interface DomainData {
  id: string
  version: string
  files: UnzippedFiles
}

/**
 * Interface cho các chiến lược lưu trữ (OPFS hoặc IndexedDB)
 */
export interface StorageStrategy {
  readonly name: string
  isSupported(): Promise<boolean>
  save(domain: string, data: DomainData): Promise<void>
  get(domain: string): Promise<DomainData | null>
  getVersion(domain: string): Promise<string | null>
}

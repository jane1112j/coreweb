import { OPFSStorage } from './opfs-storage'
import { IndexedDBStorage } from './idb-storage'
import type { StorageStrategy } from './storage-strategy'

export class StorageFactory {
  static async getBestStrategy(): Promise<StorageStrategy> {
    const opfs = new OPFSStorage()
    if (await opfs.isSupported()) {
      return opfs
    }
    return new IndexedDBStorage()
  }
}

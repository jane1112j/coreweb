import Dexie, { type Table } from 'dexie'
import type { DomainData, StorageStrategy } from './storage-strategy'

class DomainDatabase extends Dexie {
  domains!: Table<{ domain: string; id: string; version: string; files: any }, string>

  constructor() {
    super('file_processor_cache')
    this.version(2).stores({
      domains: 'domain',
    })
  }
}

/**
 * Cài đặt lưu trữ bằng IndexedDB (Sử dụng Dexie)
 */
export class IndexedDBStorage implements StorageStrategy {
  readonly name = 'IndexedDB'
  private db = new DomainDatabase()

  async isSupported(): Promise<boolean> {
    return true // Hầu hết trình duyệt hiện đại đều hỗ trợ
  }

  async save(domain: string, data: DomainData): Promise<void> {
    if (!domain) {
      console.error('[file-processor] save: domain is required')
      return
    }
    await this.db.domains.put({
      domain,
      id: data.id,
      version: data.version,
      files: data.files,
    })
  }

  async get(domain: string): Promise<DomainData | null> {
    if (!domain) return null
    const item = await this.db.domains.get(domain)
    if (!item) return null
    return {
      id: item.id,
      version: item.version,
      files: item.files,
    }
  }

  async getVersion(domain: string): Promise<string | null> {
    if (!domain) return null
    const item = await this.db.domains.get(domain)
    return item ? item.version : null
  }
}

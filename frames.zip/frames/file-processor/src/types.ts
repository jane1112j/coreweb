export interface DomainInfoParams {
  domain: string
  hasCachedFiles?: boolean
}

export interface DomainInfoResponse {
  version: string
  id: string
  updateNeeded: boolean
  files?: Record<string, unknown>
}

export interface UploadFileParams {
  filename: string
}

export interface UploadFileResponse {
  fileId: string
}

export interface ProcessImageParams {
  imageId: string
  effect: string
}

export interface ProcessImageResponse {
  success: boolean
}

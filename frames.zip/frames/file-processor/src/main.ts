/**
 * File Processor Frame
 */

import { FrameClient, type ApplicationActionHandler, GenericActionHandler } from '@metanodejs/fiai-sdk'
import { FileActions } from '@/core/actions'
import { registerSW } from 'virtual:pwa-register'
import { getBLS, loadBLS } from '@metanodejs/bls-crypto'
import * as Handlers from './handlers/file.handlers'
import * as UseCases from './use-cases'
import { HttpClient } from '@/shared/infrastructure/http/http-client'
import { StorageFactory } from '@/shared/infrastructure/storage/storage-factory'
import { ZipService } from '@/shared/infrastructure/zip/zip-service'
import { VerifyFileHashService } from '@/shared/infrastructure/crypto/verify-file-hash.service'
import { RuntimeSyncManager } from './core/runtime-sync.manager'

async function bootstrap() {
  const client = new FrameClient('file-processor')

  // ─── Khởi tạo Infrastructure ────────────────────────────────

  const httpClient = new HttpClient()
  const storage = await StorageFactory.getBestStrategy()
  const zipService = new ZipService()

  // ─── Khởi tạo BLS Crypto & Verify Service ────────────────────

  await loadBLS()
  const bls = getBLS()
  await bls.initBLS()
  bls.init_context()
  const verifyFileHashService = new VerifyFileHashService()

  // ─── Khởi tạo Use Cases ─────────────────────────────────────

  const getDomainInfoUC = new UseCases.GetDomainInfoUseCase(httpClient, storage)

  // ─── Đăng ký Handlers ───────────────────────────────────────

  const handlers: ApplicationActionHandler[] = [
    new Handlers.PingHandler(),
    new GenericActionHandler(FileActions.GET_DOMAIN_INFO, getDomainInfoUC),
  ]
  handlers.forEach((handler) => {
    if (!handler || !handler.action) {
      console.warn('[file-processor] Found invalid handler:', handler)
      return
    }
    client.handle(handler.action, (params: ApplicationActionHandler) => handler.handle(params))
  })

  // ─── Khởi tạo Sync Manager (Background Process) ──────────────
  new RuntimeSyncManager(client, httpClient, storage, zipService, verifyFileHashService)

  // ─── Báo frame đã sẵn sàng ──────────────────────────────────

  void client.ready()
}

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', bootstrap)
} else {
  void bootstrap()
}
// Đăng ký Service Worker để hỗ trợ Offline
registerSW({
  onNeedRefresh() {
    console.warn('[file-processor] New version available, please refresh.')
  },
  onOfflineReady() {
    console.warn('[file-processor] Processor is ready to work offline.')
  },
})

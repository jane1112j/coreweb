import type { IUseCase } from '@metanodejs/fiai-sdk'
import { MAP_DOMAIN_TO_JSON_URL } from '@/core/constants'
import { eventBus, InternalEvents } from '@/core/event-bus'
import type { DomainInfoParams, DomainInfoResponse } from '../types'
import type { HttpClient } from '@/shared/infrastructure/http/http-client'
import type { StorageStrategy } from '@/shared/infrastructure/storage/storage-strategy'

interface DomainMetadata {
  name: string
  version: string
  hash: string
  pubKey: string
  sign: string
  id: string
  orientation: string
  author: string
  urlZip: string
}

export class GetDomainInfoUseCase implements IUseCase<DomainInfoParams, DomainInfoResponse> {
  constructor(
    private readonly httpClient: HttpClient,
    private readonly storage: StorageStrategy,
  ) {}

  async execute(params: DomainInfoParams): Promise<DomainInfoResponse> {
    const jsonUrl = MAP_DOMAIN_TO_JSON_URL[params.domain] ?? 'https://json.fi.ai/food-https.json'
    // if (!jsonUrl) {
    //   throw new Error(`Domain ${params.domain} not configured`)
    // }

    // 1. Tải JSON metadata
    let metadata: DomainMetadata
    try {
      metadata = await this.httpClient.getJson<DomainMetadata>(jsonUrl)

      // 2. Kiểm tra version trong cache
      const cachedVersion = await this.storage.getVersion(params.domain)
      // 3. Trả về metadata và trạng thái đồng bộ
      let updateNeeded = cachedVersion !== metadata.version

      // Nếu Host báo không có files trong VFS, ép buộc updateNeeded = true
      if (params.hasCachedFiles === false) {
        console.warn(
          `[file-processor] Host reported no cached files. Forcing sync for ${params.domain}`,
        )
        updateNeeded = true
      }

      const files: Record<string, unknown> | undefined = undefined
      if (!updateNeeded) {
        // Optimization: Skipping files loading & transfer since they already match the Host VFS cache!
        console.warn(
          `[file-processor] Cache matches Host VFS for ${params.domain}. Skipping files transfer.`,
        )
      }

      if (updateNeeded) {
        console.warn(`[file-processor] Update needed for ${params.domain}. Triggering sync...`)
        eventBus.emit(InternalEvents.NEEDS_SYNC, {
          domain: params.domain,
          id: metadata.id,
          urlZip: metadata.urlZip,
          version: metadata.version,
          hash: metadata.hash,
          pubKey: metadata.pubKey,
          sign: metadata.sign,
        })
      }

      return {
        version: metadata.version,
        id: metadata.id,
        updateNeeded,
        files,
      }
    } catch (error) {
      console.warn(
        `[file-processor] Failed to fetch metadata for ${params.domain}, checking cache...`,
        error,
      )

      const cachedData = await this.storage.get(params.domain)
      if (cachedData) {
        console.warn(`[file-processor] Found cached version ${cachedData.version} for offline use.`)
        return {
          version: cachedData.version,
          id: cachedData.id || params.domain,
          updateNeeded: false,
          files: cachedData.files,
        }
      }

      throw new Error(`Domain ${params.domain} is unreachable and no cached data found.`, {
        cause: error,
      })
    }
  }
}

import type { FrameClient } from '@metanodejs/fiai-sdk'
import { eventBus, InternalEvents } from './event-bus'
import type { HttpClient } from '@/shared/infrastructure/http/http-client'
import type { StorageStrategy } from '@/shared/infrastructure/storage/storage-strategy'
import type { ZipService } from '@/shared/infrastructure/zip/zip-service'
import type { VerifyFileHashService } from '@/shared/infrastructure/crypto/verify-file-hash.service'

/**
 * Quản lý việc đồng bộ Runtime trong background.
 * Lắng nghe sự kiện từ UseCase và gửi feedback (progress, completion) về cho Host.
 */
export class RuntimeSyncManager {
  constructor(
    private readonly client: FrameClient,
    private readonly httpClient: HttpClient,
    private readonly storage: StorageStrategy,
    private readonly zipService: ZipService,
    private readonly verifyFileHashService: VerifyFileHashService,
  ) {
    this.setupListeners()
  }

  private setupListeners() {
    eventBus.on(InternalEvents.NEEDS_SYNC, (data: any) => {
      this.handleSync(
        data.domain,
        data.id,
        data.urlZip,
        data.version,
        data.hash,
        data.pubKey,
        data.sign,
      ).catch((err) => {
        console.error('[file-processor] Sync failed:', err)
      })
    })
  }

  private async handleSync(
    domain: string,
    id: string,
    urlZip: string,
    version: string,
    hash?: string,
    pubKey?: string,
    sign?: string,
  ) {
    console.warn(
      `[file-processor] Starting background sync for ${domain} (ID: ${id}) v${version}...`,
    )

    try {
      // 1. Tải file ZIP với progress
      const zipBuffer = await this.httpClient.getBinary(urlZip, (percent) => {
        // Gửi progress về cho Host App
        void this.client.emit('on-process-download-file', {
          domain,
          version,
          percent,
          status: 'downloading',
        })
      })

      // 2. Xác minh tính toàn vẹn file (hash + BLS signature)
      if (hash && pubKey && sign) {
        const verifyResult = await this.verifyFileHashService.verify(zipBuffer, hash, pubKey, sign)
        if (!verifyResult.valid) {
          const reason = !verifyResult.hashMatch
            ? `Hash mismatch (expected: ${verifyResult.expectedHash}, actual: ${verifyResult.actualHash})`
            : 'BLS signature verification failed'

          void this.client.emit('runtime-error', {
            domain,
            version,
            message: `File integrity verification failed: ${reason}`,
          })
          return
        }
      } else {
        console.warn(
          `[file-processor] Skipping file verification for ${domain} (no hash/pubKey/sign provided)`,
        )
      }

      // 3. Giải nén
      const unzippedFiles = await this.zipService.unzip(zipBuffer, urlZip)

      // 4. Lưu cache
      await this.storage.save(domain, {
        id,
        version,
        files: unzippedFiles,
      })

      // 5. Báo hiệu hoàn tất
      void this.client.emit('runtime-ready', {
        id,
        domain,
        version,
        files: unzippedFiles,
        status: 'ready',
      })
    } catch (error: any) {
      void this.client.emit('runtime-error', {
        domain,
        version,
        message: error.message,
      })
      throw error
    }
  }
}

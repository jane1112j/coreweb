import { EventEmitter } from '@metanodejs/fiai-sdk'

/**
 * Event bus nội bộ cho frame file-processor.
 * Dùng để giao tiếp giữa các thành phần (Handlers -> Services)
 */
export const eventBus = new EventEmitter()

/**
 * Các sự kiện hệ thống
 */
export const InternalEvents = {
  /** Yêu cầu đồng bộ runtime (tải ZIP) */
  NEEDS_SYNC: 'system:needs-sync',
} as const

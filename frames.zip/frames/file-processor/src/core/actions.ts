/**
 * Định nghĩa tập trung các action names của File Processor
 */
export const FileActions = {
  PING: 'file:ping',
  GET_DOMAIN_INFO: 'getDomainInfo',
  UPLOAD_FILE: 'uploadFile',
  PROCESS_IMAGE: 'processImage',
} as const

/**
 * Danh sách bản đồ từ domain sang URL chứa file cấu hình JSON
 */
export const MAP_DOMAIN_TO_JSON_URL: Record<string, string> = {
  'dqit.vn': 'https://json.iqnb.com/gpu-rental-sdk.json',
  'connect-wallet-web.iqnb.com': 'https://json.iqnb.com/connectWalletWeb.json',
  'scan.iqnb.com': 'https://json.iqnb.com/explorer.json',
  'letc.iqnb.com': 'https://json.iqnb.com/meta-chat.json',
  'order.iqr.net': 'https://json.iqnb.com/food-https.json',
  'admin.iqr.net': 'https://json.iqnb.com/admin-foodorder-https.json',
  'po5.iqnb.com': 'https://json.iqnb.com/fi.city.json',
  'crm-po5.iqnb.com': 'https://json.iqnb.com/cms.fi.city.json',
  'admin-vehicle.iqnb.com': 'https://json.iqnb.com/admin-vehicle.json',
  'gpu-rental.iqnb.com': 'https://json.iqnb.com/gpu-rental.json',
  'gpu-rental-v2.iqnb.com': 'https://json.iqnb.com/gpu-rental-v2.json',
  'chat-free-gas.iqnb.com': 'https://json.iqnb.com/chat-free-gas.json',
  'dashboard-3d.iqnb.com': 'https://json.iqnb.com/dashboard-3d.json',
  'chat-admin.iqnb.com': 'https://json.iqnb.com/chat-admin.json',
  'chat-2.iqnb.com': 'https://json.iqnb.com/chat-2.json',
  'admin-agent.iqnb.com': 'https://json.iqnb.com/admin-agent-https.json',
  'admin-agent-v3.iqnb.com': 'https://json.iqnb.com/admin-agent-https-v3.json',
  'cloud-pc.iqnb.com': 'https://json.iqnb.com/cloud-pc.json',
} as const

console.warn('[File-Processor] MAP_DOMAIN_TO_JSON_URL', MAP_DOMAIN_TO_JSON_URL)

import type { ApplicationActionHandler } from '@metanodejs/fiai-sdk'
import { FileActions } from '@/core/actions'


/**
 * Handler kiểm tra frame còn sống
 */
export class PingHandler implements ApplicationActionHandler {
  readonly action = FileActions.PING
  handle() {
    return { pong: true, timestamp: Date.now() }
  }
}



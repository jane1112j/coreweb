import { eventLogService } from '#/event-logs/event-logs.service'
import { FiaiSDK } from '@metanodejs/fiai-sdk'
import {
  createWallet,
  getAllWallets,
  getSeed,
  createHash,
  connectWallet,
} from '@metanodejs/system-core'
import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'

export const Route = createFileRoute('/')({ component: FunctionComponent })

function FunctionComponent() {
  const [sdk, setSdk] = useState<FiaiSDK | null>(null)
  const [logs, setLogs] = useState<string[]>([])
  const [isLocked, _setIsLocked] = useState(true)
  const [windowWidth, setWindowWidth] = useState(1200) // Default for SSR

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth)
    handleResize() // Set initial client-side width
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    void handleInitSDK()
  }, [])

  const isMobile = windowWidth < 768
  const isTablet = windowWidth < 1024

  const addLog = (msg: string) => {
    setLogs((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev])
  }

  const handleInitSDK = async () => {
    try {
      addLog('🚀 Initializing Biometric-only SDK...')
      const instance = await FiaiSDK.init({})
      setSdk(instance)
      addLog('✅ SDK Initialized')
      // Lắng nghe sự kiện từ Blockchain Bridge
      eventLogService.eventLog.onEventLog((log: any) => {
        try {
          addLog(`🔔 New Event: ${JSON.stringify(log)}`)
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error: unknown) {
          addLog(`🔔 New Event (Decode failed): ${JSON.stringify(log)}`)
        }
      })
      instance.on('big-event-test', (log: any) => {
        console.warn('big-event-test: ', log)
      })
      instance.on('on-process-create-hash-file', (data: any) => {
        console.warn('on-process-create-hash-file data: ', data)
        addLog(
          `📦 [Hash Progress] ${data.fileName}: Sent chunk ${data.chunkIndex}/${data.totalChunks} (${data.progress}%)`,
        )
      })
    } catch (err: any) {
      addLog(`❌ Init failed: ${err.message}`)
    }
  }

  const handleRequest = async (action: string) => {
    if (!sdk) return
    try {
      addLog(`📡 Sending request: ${action}...`)
      const result = await sdk.request(action, { data: 'test payload' })
      addLog(`✔ Response: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Request failed: ${err.message}`)
    }
  }

  const handleSendBigMessage = async () => {
    if (!sdk) return

    try {
      const sizeMB = 500
      addLog(`📡 Generating ${sizeMB}MB dummy string data...`)
      const start = Date.now()

      // Tạo chuỗi 50MB
      const baseStr = 'A'.repeat(1024) // 1KB
      const largeString = baseStr.repeat(sizeMB * 1024)

      addLog(`🚀 Sending ${sizeMB}MB string via Chunking...`)
      const result = await sdk.request('processBigData', { content: largeString })

      const duration = (Date.now() - start) / 1000
      addLog(
        `✔ Success! Received response in ${duration}s: ${JSON.stringify(result).substring(
          0,
          100,
        )}...`,
      )
    } catch (err: any) {
      addLog(`❌ Big message failed: ${err.message}`)
    }
  }

  const handleCreateWallet = async () => {
    if (!sdk) return
    try {
      const data = await sdk.request('getPublicKey', {
        address: '0x0f4dfdc416bac0ec6572567bc16723f5fb56c3ef',
      })
      console.log('data: ', data)
      return
      addLog('🎨 Creating new wallet in Vault...')
      const { listSeed } = await getSeed()
      console.log('listSeed: ', listSeed)
      const result = await createWallet({
        name: `My Wallet ${Date.now()}`,
        seed: listSeed,
        backgroundImage: '',
      })
      addLog(`✅ Wallet Created: ${result.address}`)
    } catch (err: any) {
      addLog(`❌ Create Wallet failed: ${err.message}`)
    }
  }

  const handleConnectWallet = async () => {
    if (!sdk) return
    try {
      addLog('🔌 Connecting wallet...')
      const result = await connectWallet()
      addLog(`✅ Connected: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Connect Wallet failed: ${err.message}`)
    }
  }

  const handleGetAllWallet = async () => {
    if (!sdk) return
    try {
      addLog('📂 Retrieving all wallets...')
      const result = await getAllWallets()
      addLog(`✅ Wallets: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Get All Wallets failed: ${err.message}`)
    }
  }

  const handleSignTransaction = async () => {
    if (!sdk) return
    const address = prompt('Enter wallet address to sign:')
    if (!address) return
    const message = prompt('Enter message to sign:', 'Hello World')
    if (!message) return

    try {
      addLog(`✍ Signing message with ${address}...`)
      const result = await sdk.request('signWithWallet', {
        address,
        payload: message,
        algorithm: 'bls',
      })
      addLog(`✅ Signed: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Signing failed: ${err.message}`)
    }
  }

  const handleGetSeed = async () => {
    if (!sdk) return
    try {
      addLog('🔑 Retrieving seed for wallet...')
      const result = await sdk.request('getSeed')
      addLog(`✅ Seed Retrieved: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Get Seed failed: ${err.message}`)
    }
  }

  const handleCreateHash = async () => {
    if (!sdk) return
    const message = prompt('Enter message to hash:', 'Hello World')
    if (!message) return
    try {
      addLog(`🔢 Creating hash for: "${message}"...`)
      const result = await createHash(message, false)
      console.log('createHash result: ', result)
      addLog(`✅ Hash: ${result}`)
    } catch (err: any) {
      addLog(`❌ Create Hash failed: ${err.message}`)
    }
  }

  const handleCreateHashWithBuffer = () => {
    if (!sdk) return
    const input = document.createElement('input')
    input.type = 'file'
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0]
      if (!file) return

      try {
        const start = Date.now()
        addLog(
          `🚀 [SDK createFileWithBuffer] Sending file "${file.name}" to SDK for streaming hash...`,
        )
        const result = await sdk.request<{ hash: string }>('createHashFromFile', { file })

        const duration = ((Date.now() - start) / 1000).toFixed(2)
        addLog(`✅ Hash completed successfully by SDK in ${duration}s!`)
        addLog(`🔑 Keccak-256: ${result.hash}`)
      } catch (err: any) {
        addLog(`❌ [SDK createFileWithBuffer] Failed: ${err.message}`)
      }
    }
    input.click()
  }

  const handleTestBigRequest = () => {
    if (!sdk) return
    addLog('📦 Preparing big request (20MB)...')

    setTimeout(async () => {
      try {
        const bigData = 'A'.repeat(20 * 1024 * 1024)
        addLog('📡 Sending to Worker for encryption...')
        const result = await sdk.request('testBigRequest', {
          payload: bigData,
          timestamp: Date.now(),
        })
        addLog(`✅ Big Request Success: ${JSON.stringify(result)}`)
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : String(err)
        addLog(`❌ Big Request failed: ${message}`)
      }
    }, 0)
  }

  const handleSendTransaction = async (feeType: 'sc' | 'read') => {
    if (!sdk) return
    try {
      addLog(`⚡ Sending Transaction (${feeType})...`)
      const result = await sdk.request('sendTransaction', {
        feeType,
        from: '0x0f4dfdc416bac0ec6572567bc16723f5fb56c3ef',
        to: '0x572b1b7a1724a8e3402e7e3bc6c50bebd24861f4',
        functionName: 'getAgentFromDomain',
        abiData: [
          {
            inputs: [{ internalType: 'string', name: '_domain', type: 'string' }],
            name: 'getAgentFromDomain',
            outputs: [
              { internalType: 'address', name: 'agentAdd', type: 'address' },
              { internalType: 'uint256', name: 'branchId', type: 'uint256' },
            ],
            stateMutability: 'view',
            type: 'function',
          },
        ],
        inputArray: [
          {
            internalType: 'string',
            name: '_domain',
            type: 'string',
            value: 'thongtinduongduong101.metanode.co',
          },
        ],
      })
      console.log('handleSendTransaction result: ', result)
      addLog(`✅ Bridge Response: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Bridge Request failed: ${err.message}`)
    }
  }

  const handleReadContract = () => handleSendTransaction('read')

  const handleTestRevertError = async () => {
    if (!sdk) return
    try {
      addLog(`⚡ Testing Contract Error (Revert Reason via getBalance)...`)
      const result = await sdk.request('sendTransaction', {
        feeType: 'read',
        from: '0xba301928269d6ac026c0dd690e18dabf8fdfef28',
        to: '0x572b1b7a1724a8e3402e7e3bc6c50bebd24861f4',
        functionName: 'getBalance', // Hàm này không tồn tại trên contract này -> Sẽ gây Revert!
        abiData: [
          {
            inputs: [{ internalType: 'address', name: '_account', type: 'address' }],
            name: 'getBalance',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
          },
        ],
        inputArray: [
          {
            internalType: 'address',
            name: '_account',
            type: 'address',
            value: '0x0000000000000000000000000000000000000000',
          },
        ],
      })
      console.log('handleTestRevertError result: ', result)
      addLog(`✅ Bridge Response: ${JSON.stringify(result)}`)
    } catch (err: any) {
      console.error('handleTestRevertError error: ', err)
      addLog(`❌ Bridge Request failed (Expected Revert): ${err.message}`)
    }
  }

  const handleRegisterDevice = async () => {
    if (!sdk) return

    const deviceId = prompt(
      'Enter bytes32 deviceId:',
      '0x0000000000000000000000000000000000000000000000000000000000000001',
    )
    if (!deviceId) return

    const signer = prompt('Enter signer address:', '0x0000000000000000000000000000000000000000')
    if (!signer) return

    const metadataURI = prompt('Enter metadata URI:', 'ipfs://QmTestDeviceMetadata')
    if (!metadataURI) return

    try {
      addLog(`⚡ Calling registerDevice on 0x67044f2ddb50d18a93ef724b92abaec28b8fd3b2...`)
      const result = await sdk.request('sendTransaction', {
        feeType: 'sc',
        from: '0x43b766130aff7e71681fd4470ea7f40b1b4d89eb',
        to: '0x67044f2ddb50d18a93ef724b92abaec28b8fd3b2',
        functionName: 'registerDevice',
        abiData: [
          {
            type: 'function',
            name: 'registerDevice',
            inputs: [
              { name: 'deviceId', type: 'bytes32', internalType: 'bytes32' },
              { name: 'signer', type: 'address', internalType: 'address' },
              { name: 'metadataURI', type: 'string', internalType: 'string' },
            ],
            outputs: [],
            stateMutability: 'nonpayable',
          },
        ],
        inputArray: [
          {
            internalType: 'bytes32',
            name: 'deviceId',
            type: 'bytes32',
            value: deviceId,
          },
          {
            internalType: 'address',
            name: 'signer',
            type: 'address',
            value: signer,
          },
          {
            internalType: 'string',
            name: 'metadataURI',
            type: 'string',
            value: metadataURI,
          },
        ],
      })
      console.log('registerDevice result: ', result)
      addLog(`✅ registerDevice Response: ${JSON.stringify(result)}`)
    } catch (err: any) {
      console.error('registerDevice error: ', err)
      addLog(`❌ registerDevice failed: ${err.message}`)
    }
  }

  const handleRegisterUser = async () => {
    if (!sdk) return

    const randStr = () => Math.random().toString(36).substring(2, 8)
    const publicKey =
      '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')
    const userName = `user_${randStr()}`
    const firstName = `First_${randStr()}`
    const lastName = `Last_${randStr()}`
    const avatar = `ipfs://QmAvatar_${randStr()}`
    const bio = `Automatic bio registration test: ${randStr()}`

    try {
      addLog(`⚡ Calling registerUser on 0x6DF9F0C1AaF2393fB117E2011E4C1FE5cf47a87E...`)
      const result = await sdk.request('sendTransaction', {
        feeType: 'sc',
        from: '0xb128f7455328b2d94a731a64ce072b6ef2b86b29',
        to: '0x6DF9F0C1AaF2393fB117E2011E4C1FE5cf47a87E',
        functionName: 'registerUser',
        abiData: [
          {
            type: 'function',
            name: 'registerUser',
            inputs: [
              { name: 'publicKey', type: 'string', internalType: 'string' },
              { name: 'userName', type: 'string', internalType: 'string' },
              { name: 'firstName', type: 'string', internalType: 'string' },
              { name: 'lastName', type: 'string', internalType: 'string' },
              { name: 'avatar', type: 'string', internalType: 'string' },
              { name: 'bio', type: 'string', internalType: 'string' },
            ],
            outputs: [],
            stateMutability: 'nonpayable',
          },
        ],
        inputArray: [
          {
            internalType: 'string',
            name: 'publicKey',
            type: 'string',
            value: publicKey,
          },
          {
            internalType: 'string',
            name: 'userName',
            type: 'string',
            value: userName,
          },
          {
            internalType: 'string',
            name: 'firstName',
            type: 'string',
            value: firstName,
          },
          {
            internalType: 'string',
            name: 'lastName',
            type: 'string',
            value: lastName,
          },
          {
            internalType: 'string',
            name: 'avatar',
            type: 'string',
            value: avatar,
          },
          {
            internalType: 'string',
            name: 'bio',
            type: 'string',
            value: bio,
          },
        ],
      })
      console.log('registerUser result: ', result)
      addLog(`✅ registerUser Response: ${JSON.stringify(result)}`)
    } catch (err: any) {
      console.error('registerUser error: ', err)
      addLog(`❌ registerUser failed: ${err.message}`)
    }
  }

  const handleSubscribe = async () => {
    if (!sdk) return
    try {
      addLog('📡 Subscribing to Contract Events...')
      const result = await eventLogService.eventLog.registerEvent(
        '100b404b9fd69da8f1c61cdc3e22a34d1846e841',
        ['0x3e940950dea462274fa455fcc748d61710e82b16'],
      )
      addLog(`✅ Subscription OK: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Subscription failed: ${err.message}`)
    }
  }

  const handleGetBlockNumber = async () => {
    if (!sdk) return
    try {
      addLog('📡 Requesting current block number...')
      const result = await sdk.request('getBlockNumber')
      addLog(`✅ Block Number: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Get Block Number failed: ${err.message}`)
    }
  }

  const clearStorage = () => {
    localStorage.clear()
    window.location.reload()
  }

  const handleRequestBigResponse = async () => {
    if (!sdk) return
    try {
      addLog('📡 Requesting 100MB response from Frame...')
      const start = Date.now()
      const result = await sdk.request('getBigResponse', { sizeMB: 100 })
      console.log('handleRequestBigResponse result: ', result)
      const duration = (Date.now() - start) / 1000
      addLog(`✅ Received 100MB in ${duration}s. Type: ${typeof result}`)
    } catch (err: any) {
      addLog(`❌ Big Response failed: ${err.message}`)
    }
  }

  const handleTriggerBigEvent = async () => {
    if (!sdk) return
    try {
      addLog('📡 Triggering 50MB Event from Frame...')
      await sdk.request('triggerBigEvent', { sizeMB: 500 })
      addLog('⏳ Waiting for big event to arrive...')
    } catch (err: any) {
      addLog(`❌ Event trigger failed: ${err.message}`)
    }
  }

  return (
    <div style={containerStyle}>
      {/* Background Decorative Element */}
      <div style={bgGlowStyle}></div>

      {/* Header Area */}
      <header
        style={{
          ...headerStyle,
          flexDirection: isMobile ? 'column' : 'row',
          gap: isMobile ? '1.5rem' : '1rem',
          textAlign: isMobile ? 'center' : 'left',
          padding: isMobile ? '1.5rem' : '1.75rem 2rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: isMobile ? 'column' : 'row',
            alignItems: 'center',
            gap: isMobile ? '1rem' : '1.25rem',
          }}
        >
          <div style={logoIconStyle}>
            <span style={{ fontSize: '1.5rem' }}>🛡</span>
          </div>
          <div>
            <h1 style={{ ...titleStyle, fontSize: isMobile ? '1.5rem' : '1.75rem' }}>
              Metanode SDK Lab
            </h1>
            <p style={subtitleStyle}>Zero-Trust Biometric Security</p>
          </div>
        </div>
        <div
          style={{
            display: 'flex',
            gap: '1rem',
            alignItems: 'center',
            flexWrap: 'wrap',
            justifyContent: 'center',
          }}
        >
          <div
            style={{
              ...statusBadgeStyle,
              backgroundColor: sdk ? (isLocked ? '#f59e0b' : '#10b981') : '#475569',
              boxShadow: sdk
                ? `0 0 15px ${isLocked ? 'rgba(245,158,11,0.3)' : 'rgba(16,185,129,0.3)'}`
                : 'none',
            }}
          >
            <div
              style={{
                ...statusDotStyle,
                backgroundColor: sdk ? (isLocked ? '#fff' : '#fff') : '#94a3b8',
              }}
            />
            {sdk ? (isLocked ? 'Locked' : 'Active') : 'Disconnected'}
          </div>
          <button onClick={clearStorage} style={resetBtnStyle}>
            Reset Lab
          </button>
        </div>
      </header>

      <div
        style={{
          ...mainLayoutStyle,
          gridTemplateColumns: isTablet ? '1fr' : '1fr 2fr',
        }}
      >
        {/* Left Column: Actions */}
        <div style={actionsContainerStyle}>
          {/* Step 2: Vault */}
          <div style={{ ...cardStyle, opacity: sdk ? 1 : 0.4 }}>
            <div style={cardHeaderStyle}>
              <span style={stepBadgeStyle}>01</span>
              <h3 style={cardTitleStyle}>Cryptographic Operations</h3>
            </div>
            <div
              style={{
                ...btnGridStyle,
                gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
              }}
            >
              <button onClick={handleCreateWallet} style={actionBtnStyle} disabled={!sdk}>
                Create Wallet
              </button>
              <button onClick={handleGetAllWallet} style={actionBtnStyle} disabled={!sdk}>
                Get All Wallets
              </button>
              <button onClick={handleConnectWallet} style={actionBtnStyle} disabled={!sdk}>
                Connect Wallet
              </button>
              <button onClick={() => handleRequest('ping')} style={actionBtnStyle} disabled={!sdk}>
                Ping Bridge
              </button>
              <button onClick={handleReadContract} style={actionBtnStyle} disabled={!sdk}>
                Read Contract
              </button>
              <button
                onClick={handleTestRevertError}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(239, 68, 68, 0.1)',
                  color: '#f87171',
                  border: '1px solid rgba(239, 68, 68, 0.2)',
                }}
                disabled={!sdk}
              >
                Read Contract (Error)
              </button>
              <button
                onClick={handleRegisterDevice}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(168, 85, 247, 0.1)',
                  color: '#c084fc',
                  border: '1px solid rgba(168, 85, 247, 0.2)',
                }}
                disabled={!sdk}
              >
                Register Device (DeviceRegistry)
              </button>
              <button
                onClick={handleRegisterUser}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(16, 185, 129, 0.1)',
                  color: '#10b981',
                  border: '1px solid rgba(16, 185, 129, 0.2)',
                }}
                disabled={!sdk}
              >
                Register User (0x6DF9...)
              </button>
              <button
                onClick={handleSubscribe}
                style={{
                  ...actionBtnStyle,
                  gridColumn: isMobile ? 'auto' : 'span 2',
                  backgroundColor: 'rgba(99, 102, 241, 0.1)',
                }}
                disabled={!sdk}
              >
                Subscribe Events (WS)
              </button>
              <button onClick={handleGetSeed} style={actionBtnStyle} disabled={!sdk}>
                Retrieve Seed
              </button>
              <button onClick={handleSignTransaction} style={actionBtnStyle} disabled={!sdk}>
                Sign Transaction
              </button>
              <button onClick={handleCreateHash} style={actionBtnStyle} disabled={!sdk}>
                Create Hash
              </button>
              <button onClick={handleCreateHashWithBuffer} style={actionBtnStyle} disabled={!sdk}>
                Create Hash With Buffer
              </button>
              <button
                onClick={() => handleRequest('testCrossFrameCall')}
                style={{
                  ...actionBtnStyle,
                  gridColumn: isMobile ? 'auto' : 'span 2',
                }}
                disabled={!sdk}
              >
                Cross-Frame Call Security Test
              </button>
              <button
                onClick={handleTestBigRequest}
                style={{
                  ...actionBtnStyle,
                  gridColumn: isMobile ? 'auto' : 'span 2',
                  backgroundColor: '#6366f1',
                  color: 'white',
                  border: 'none',
                }}
                disabled={!sdk}
              >
                Big Data Transfer (20MB)
              </button>
            </div>
          </div>

          {/* Step 3: Blockchain Bridge */}
          <div style={{ ...cardStyle, opacity: sdk ? 1 : 0.4 }}>
            <div style={cardHeaderStyle}>
              <span style={stepBadgeStyle}>02</span>
              <h3 style={cardTitleStyle}>Blockchain Bridge Operations</h3>
            </div>
            <div
              style={{
                ...btnGridStyle,
                gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
              }}
            >
              <button
                onClick={() => handleSendTransaction('sc')}
                style={{ ...actionBtnStyle, backgroundColor: 'rgba(16, 185, 129, 0.1)' }}
                disabled={!sdk}
              >
                Send TX (SC)
              </button>
              <button
                onClick={handleGetBlockNumber}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(59, 130, 246, 0.1)',
                  color: '#60a5fa',
                  border: '1px solid rgba(59, 130, 246, 0.2)',
                }}
                disabled={!sdk}
              >
                Get Block Number
              </button>
              <button
                onClick={() => handleRequest('getDomainInfo')}
                className="flex-1 bg-white/5 hover:bg-white/10 border border-white/10 p-4 rounded-xl transition-all"
                disabled={!sdk}
              >
                Get Domain Info
              </button>
              <button
                onClick={handleSendBigMessage}
                className="flex-1 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/30 p-4 rounded-xl text-orange-400 transition-all font-bold"
                disabled={!sdk}
              >
                Upload & Process Big File
              </button>
            </div>
          </div>

          {/* New Section: Streaming & Stress Test */}
          <div
            style={{
              ...cardStyle,
              opacity: sdk ? 1 : 0.4,
              border: '1px solid rgba(249, 115, 22, 0.2)',
            }}
          >
            <div style={cardHeaderStyle}>
              <span style={{ ...stepBadgeStyle, backgroundColor: '#f97316' }}>03</span>
              <h3 style={{ ...cardTitleStyle, color: '#fb923c' }}>Streaming & Stress Test</h3>
            </div>
            <div
              style={{
                ...btnGridStyle,
                gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
              }}
            >
              <button
                onClick={handleSendBigMessage}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(249, 115, 22, 0.1)',
                  color: '#fb923c',
                }}
                disabled={!sdk}
              >
                🚀 500MB Request (Host-Frame)
              </button>
              <button
                onClick={handleRequestBigResponse}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(249, 115, 22, 0.1)',
                  color: '#fb923c',
                }}
                disabled={!sdk}
              >
                📥 Big Response (Frame-Host)
              </button>
              <button
                onClick={handleTriggerBigEvent}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: 'rgba(249, 115, 22, 0.1)',
                  color: '#fb923c',
                  gridColumn: isMobile ? 'auto' : 'span 2',
                }}
                disabled={!sdk}
              >
                🔔 Big Event 50MB (Frame-Host)
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Logs */}
        <div
          style={{
            ...terminalContainerStyle,
            height: isTablet ? '400px' : '680px',
          }}
        >
          <div style={terminalHeaderStyle}>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <div
                style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#ff5f56' }}
              />
              <div
                style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#ffbd2e' }}
              />
              <div
                style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#27c93f' }}
              />
            </div>
            <span style={{ fontWeight: 600 }}>SYSTEM EVENT STREAM</span>
            <button onClick={() => setLogs([])} style={clearLogBtnStyle}>
              Clear
            </button>
          </div>
          <div style={terminalBodyStyle}>
            {logs.length === 0 && <div style={emptyLogStyle}>&gt; Initializing system logs...</div>}
            {logs.map((log, i) => (
              <div key={i} style={logItemStyle}>
                <span style={{ color: '#6366f1', marginRight: '0.75rem' }}>$</span>
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// --- Premium Dark Theme Styles ---
const containerStyle: React.CSSProperties = {
  padding: '3rem 2rem',
  fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif",
  maxWidth: '100%',
  margin: '0 auto',
  minHeight: '100vh',
  backgroundColor: '#020617', // Deep Obsidian
  color: '#f8fafc',
  position: 'relative',
  overflow: 'hidden',
}

const bgGlowStyle: React.CSSProperties = {
  position: 'absolute',
  top: '-10%',
  right: '-5%',
  width: '500px',
  height: '500px',
  background: 'radial-gradient(circle, rgba(99, 102, 241, 0.1) 0%, transparent 70%)',
  pointerEvents: 'none',
  zIndex: 0,
}

const headerStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '3rem',
  padding: '1.75rem 2rem',
  backgroundColor: 'rgba(30, 41, 59, 0.5)',
  borderRadius: '24px',
  backdropFilter: 'blur(12px)',
  border: '1px solid rgba(255, 255, 255, 0.08)',
  position: 'relative',
  zIndex: 1,
}

const mainLayoutStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 2fr',
  gap: '2.5rem',
  alignItems: 'start',
  position: 'relative',
  zIndex: 1,
}

const actionsContainerStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: '1.75rem',
}

const cardStyle: React.CSSProperties = {
  backgroundColor: 'rgba(30, 41, 59, 0.4)',
  padding: '2rem',
  borderRadius: '24px',
  border: '1px solid rgba(255, 255, 255, 0.05)',
  boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
}

const cardHeaderStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: '1rem',
  marginBottom: '1.75rem',
}

const stepBadgeStyle: React.CSSProperties = {
  fontSize: '0.75rem',
  fontWeight: 800,
  backgroundColor: '#6366f1',
  color: 'white',
  padding: '0.25rem 0.6rem',
  borderRadius: '8px',
}

const cardTitleStyle: React.CSSProperties = {
  fontSize: '0.9rem',
  fontWeight: 700,
  textTransform: 'uppercase',
  letterSpacing: '0.075em',
  color: '#94a3b8',
  margin: 0,
}

const btnGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '1rem',
}

const titleStyle: React.CSSProperties = {
  fontSize: '1.75rem',
  fontWeight: 800,
  color: '#fff',
  margin: 0,
  letterSpacing: '-0.03em',
}

const subtitleStyle: React.CSSProperties = {
  color: '#94a3b8',
  margin: '0.25rem 0 0 0',
  fontSize: '0.9rem',
  fontWeight: 500,
}

const logoIconStyle: React.CSSProperties = {
  backgroundColor: 'rgba(99, 102, 241, 0.15)',
  width: '4rem',
  height: '4rem',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '18px',
  border: '1px solid rgba(99, 102, 241, 0.2)',
}

const statusBadgeStyle: React.CSSProperties = {
  padding: '0.5rem 1rem',
  borderRadius: '30px',
  fontSize: '0.75rem',
  fontWeight: 700,
  color: 'white',
  textTransform: 'uppercase',
  display: 'flex',
  alignItems: 'center',
  gap: '0.6rem',
  letterSpacing: '0.05em',
}

const statusDotStyle: React.CSSProperties = {
  width: '6px',
  height: '6px',
  borderRadius: '50%',
}

// --- Premium Button Styles ---
const baseBtnStyle: React.CSSProperties = {
  padding: '0.875rem 1.25rem',
  borderRadius: '14px',
  border: 'none',
  fontWeight: 700,
  cursor: 'pointer',
  fontSize: '0.875rem',
  transition: 'all 0.2s ease',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  letterSpacing: '0.025em',
}

const actionBtnStyle: React.CSSProperties = {
  ...baseBtnStyle,
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  color: '#e2e8f0',
  border: '1px solid rgba(255, 255, 255, 0.08)',
}

const resetBtnStyle: React.CSSProperties = {
  ...baseBtnStyle,
  backgroundColor: 'transparent',
  color: '#64748b',
  border: '1px solid rgba(255, 255, 255, 0.1)',
  fontSize: '0.8rem',
}

// --- Terminal Styles ---
const terminalContainerStyle: React.CSSProperties = {
  backgroundColor: '#0a0a0a',
  borderRadius: '24px',
  overflow: 'hidden',
  height: '680px',
  display: 'flex',
  flexDirection: 'column',
  border: '1px solid rgba(255, 255, 255, 0.05)',
  boxShadow: '0 20px 50px rgba(0, 0, 0, 0.3)',
}

const terminalHeaderStyle: React.CSSProperties = {
  padding: '1.25rem 1.75rem',
  backgroundColor: '#171717',
  color: '#737373',
  fontSize: '0.7rem',
  letterSpacing: '0.1em',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottom: '1px solid rgba(255, 255, 255, 0.03)',
}

const terminalBodyStyle: React.CSSProperties = {
  padding: '2rem',
  flex: 1,
  overflowY: 'auto',
  fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
}

const logItemStyle: React.CSSProperties = {
  marginBottom: '0.75rem',
  fontSize: '0.8125rem',
  lineHeight: 1.7,
  color: '#d1d5db',
  display: 'flex',
  alignItems: 'flex-start',
}

const clearLogBtnStyle: React.CSSProperties = {
  background: 'none',
  border: 'none',
  color: '#6366f1',
  cursor: 'pointer',
  fontSize: '0.7rem',
  fontWeight: 700,
  opacity: 0.8,
}

const emptyLogStyle: React.CSSProperties = {
  color: '#404040',
  fontSize: '0.875rem',
}

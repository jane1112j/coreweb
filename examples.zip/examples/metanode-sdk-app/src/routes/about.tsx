import { FiaiSDK } from '@metanodejs/fiai-sdk'
import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { getAllWallets } from '@metanodejs/system-core'

export const Route = createFileRoute('/about')({
  component: About,
})

function About() {
  const [sdk, setSdk] = useState<FiaiSDK | null>(null)
  const [logs, setLogs] = useState<string[]>([])
  const [windowWidth, setWindowWidth] = useState(1200)

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth)
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    void handleInitSDK()
  }, [])

  const isMobile = windowWidth < 768
  const isTablet = windowWidth < 1024

  const addLog = (msg: string) => {
    setLogs((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev])
  }

  const handleInitSDK = async () => {
    try {
      addLog('🚀 Initializing SDK...')
      const instance = await FiaiSDK.init({
        debug: true,
      })
      setSdk(instance)
      addLog('✅ SDK Initialized')
    } catch (err: any) {
      addLog(`❌ Init failed: ${err.message}`)
    }
  }

  const handleGetAllWallet = async () => {
    if (!sdk) return
    try {
      addLog('📂 Retrieving all wallets...')
      const result = await getAllWallets()
      addLog(`✅ Wallets: ${JSON.stringify(result)}`)
    } catch (err: any) {
      addLog(`❌ Get All Wallets failed: ${err.message}`)
    }
  }

  return (
    <div style={containerStyle}>
      {/* Background Decorative Element */}
      <div style={bgGlowStyle}></div>

      {/* Header Area */}
      <header
        style={{
          ...headerStyle,
          flexDirection: isMobile ? 'column' : 'row',
          gap: isMobile ? '1.5rem' : '1rem',
          textAlign: isMobile ? 'center' : 'left',
          padding: isMobile ? '1.5rem' : '1.75rem 2rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: isMobile ? 'column' : 'row',
            alignItems: 'center',
            gap: isMobile ? '1rem' : '1.25rem',
          }}
        >
          <div style={logoIconStyle}>
            <span style={{ fontSize: '1.5rem' }}>🛡</span>
          </div>
          <div>
            <h1 style={{ ...titleStyle, fontSize: isMobile ? '1.5rem' : '1.75rem' }}>About Lab</h1>
            <p style={subtitleStyle}>Simplified Wallet Operations</p>
          </div>
        </div>
      </header>

      <div
        style={{
          ...mainLayoutStyle,
          gridTemplateColumns: isTablet ? '1fr' : '1fr 2fr',
        }}
      >
        {/* Left Column: Actions */}
        <div style={actionsContainerStyle}>
          <div style={{ ...cardStyle, opacity: sdk ? 1 : 0.4 }}>
            <div style={cardHeaderStyle}>
              <span style={stepBadgeStyle}>01</span>
              <h3 style={cardTitleStyle}>Wallet Operations</h3>
            </div>
            <div
              style={{
                ...btnGridStyle,
                gridTemplateColumns: '1fr',
              }}
            >
              <button
                onClick={handleGetAllWallet}
                style={{
                  ...actionBtnStyle,
                  backgroundColor: '#6366f1',
                  color: 'white',
                  border: 'none',
                  padding: '1.25rem',
                }}
                disabled={!sdk}
              >
                Get All Wallets
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Logs */}
        <div
          style={{
            ...terminalContainerStyle,
            height: isTablet ? '400px' : '680px',
          }}
        >
          <div style={terminalHeaderStyle}>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <div
                style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#ff5f56' }}
              />
              <div
                style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#ffbd2e' }}
              />
              <div
                style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#27c93f' }}
              />
            </div>
            <span style={{ fontWeight: 600 }}>EVENT STREAM</span>
            <button onClick={() => setLogs([])} style={clearLogBtnStyle}>
              Clear
            </button>
          </div>
          <div style={terminalBodyStyle}>
            {logs.length === 0 && <div style={emptyLogStyle}>&gt; Initializing...</div>}
            {logs.map((log, i) => (
              <div key={i} style={logItemStyle}>
                <span style={{ color: '#6366f1', marginRight: '0.75rem' }}>$</span>
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// --- Premium Dark Theme Styles ---
const containerStyle: React.CSSProperties = {
  padding: '3rem 2rem',
  fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif",
  maxWidth: '100%',
  margin: '0 auto',
  minHeight: '100vh',
  backgroundColor: '#020617', // Deep Obsidian
  color: '#f8fafc',
  position: 'relative',
  overflow: 'hidden',
}

const bgGlowStyle: React.CSSProperties = {
  position: 'absolute',
  top: '-10%',
  right: '-5%',
  width: '500px',
  height: '500px',
  background: 'radial-gradient(circle, rgba(99, 102, 241, 0.1) 0%, transparent 70%)',
  pointerEvents: 'none',
  zIndex: 0,
}

const headerStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '3rem',
  padding: '1.75rem 2rem',
  backgroundColor: 'rgba(30, 41, 59, 0.5)',
  borderRadius: '24px',
  backdropFilter: 'blur(12px)',
  border: '1px solid rgba(255, 255, 255, 0.08)',
  position: 'relative',
  zIndex: 1,
}

const mainLayoutStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 2fr',
  gap: '2.5rem',
  alignItems: 'start',
  position: 'relative',
  zIndex: 1,
}

const actionsContainerStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: '1.75rem',
}

const cardStyle: React.CSSProperties = {
  backgroundColor: 'rgba(30, 41, 59, 0.4)',
  padding: '2rem',
  borderRadius: '24px',
  border: '1px solid rgba(255, 255, 255, 0.05)',
  boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
}

const cardHeaderStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: '1rem',
  marginBottom: '1.75rem',
}

const stepBadgeStyle: React.CSSProperties = {
  fontSize: '0.75rem',
  fontWeight: 800,
  backgroundColor: '#6366f1',
  color: 'white',
  padding: '0.25rem 0.6rem',
  borderRadius: '8px',
}

const cardTitleStyle: React.CSSProperties = {
  fontSize: '0.9rem',
  fontWeight: 700,
  textTransform: 'uppercase',
  letterSpacing: '0.075em',
  color: '#94a3b8',
  margin: 0,
}

const btnGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '1rem',
}

const titleStyle: React.CSSProperties = {
  fontSize: '1.75rem',
  fontWeight: 800,
  color: '#fff',
  margin: 0,
  letterSpacing: '-0.03em',
}

const subtitleStyle: React.CSSProperties = {
  color: '#94a3b8',
  margin: '0.25rem 0 0 0',
  fontSize: '0.9rem',
  fontWeight: 500,
}

const logoIconStyle: React.CSSProperties = {
  backgroundColor: 'rgba(99, 102, 241, 0.15)',
  width: '4rem',
  height: '4rem',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '18px',
  border: '1px solid rgba(99, 102, 241, 0.2)',
}

const baseBtnStyle: React.CSSProperties = {
  padding: '0.875rem 1.25rem',
  borderRadius: '14px',
  border: 'none',
  fontWeight: 700,
  cursor: 'pointer',
  fontSize: '0.875rem',
  transition: 'all 0.2s ease',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  letterSpacing: '0.025em',
}

const actionBtnStyle: React.CSSProperties = {
  ...baseBtnStyle,
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  color: '#e2e8f0',
  border: '1px solid rgba(255, 255, 255, 0.08)',
}

const terminalContainerStyle: React.CSSProperties = {
  backgroundColor: '#0a0a0a',
  borderRadius: '24px',
  overflow: 'hidden',
  height: '680px',
  display: 'flex',
  flexDirection: 'column',
  border: '1px solid rgba(255, 255, 255, 0.05)',
  boxShadow: '0 20px 50px rgba(0, 0, 0, 0.3)',
}

const terminalHeaderStyle: React.CSSProperties = {
  padding: '1.25rem 1.75rem',
  backgroundColor: '#171717',
  color: '#737373',
  fontSize: '0.7rem',
  letterSpacing: '0.1em',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottom: '1px solid rgba(255, 255, 255, 0.03)',
}

const terminalBodyStyle: React.CSSProperties = {
  padding: '2rem',
  flex: 1,
  overflowY: 'auto',
  fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
}

const logItemStyle: React.CSSProperties = {
  marginBottom: '0.75rem',
  fontSize: '0.8125rem',
  lineHeight: 1.7,
  color: '#d1d5db',
  display: 'flex',
  alignItems: 'flex-start',
}

const clearLogBtnStyle: React.CSSProperties = {
  background: 'none',
  border: 'none',
  color: '#6366f1',
  cursor: 'pointer',
  fontSize: '0.7rem',
  fontWeight: 700,
  opacity: 0.8,
}

const emptyLogStyle: React.CSSProperties = {
  color: '#404040',
  fontSize: '0.875rem',
}

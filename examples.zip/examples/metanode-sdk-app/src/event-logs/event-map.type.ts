export type EventMap = {
  MessageSent: {
    sender: string
    recipient: string
    messageId: string
    encryptedContent: string
    dataStoreAddress: string
    messageNonce: string | number | bigint
  }
}

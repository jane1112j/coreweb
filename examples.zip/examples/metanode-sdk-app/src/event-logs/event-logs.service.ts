import { DecodeAbi, EventLog } from '@metanodejs/event-log'
import type { EventMap } from './event-map.type'

class EventLogService {
  private static instance: EventLogService

  private readonly _decodeAbi: DecodeAbi
  private readonly _eventLog: EventLog<EventMap>

  private constructor() {
    this._decodeAbi = new DecodeAbi()
    void this._decodeAbi.registerAbi([
      {
        anonymous: false,
        inputs: [
          {
            indexed: false,
            internalType: 'address',
            name: 'sender',
            type: 'address',
          },
          {
            indexed: false,
            internalType: 'address',
            name: 'recipient',
            type: 'address',
          },
          {
            indexed: false,
            internalType: 'bytes32',
            name: 'messageId',
            type: 'bytes32',
          },
          {
            indexed: false,
            internalType: 'string',
            name: 'encryptedContent',
            type: 'string',
          },
          {
            indexed: false,
            internalType: 'address',
            name: 'dataStoreAddress',
            type: 'address',
          },
          {
            indexed: false,
            internalType: 'uint256',
            name: 'messageNonce',
            type: 'uint256',
          },
        ],
        name: 'MessageSent',
        type: 'event',
      },
    ])
    this._eventLog = new EventLog<EventMap>(this._decodeAbi)
  }

  public static getInstance(): EventLogService {
    if (!EventLogService.instance) {
      EventLogService.instance = new EventLogService()
    }
    return EventLogService.instance
  }

  get eventLog(): EventLog<EventMap> {
    return this._eventLog
  }

  get decodeAbi(): DecodeAbi {
    return this._decodeAbi
  }

  public async registerAbi() {
    await this._decodeAbi.registerAbi([
      {
        anonymous: false,
        inputs: [
          {
            indexed: false,
            internalType: 'address',
            name: 'sender',
            type: 'address',
          },
          {
            indexed: false,
            internalType: 'address',
            name: 'recipient',
            type: 'address',
          },
          {
            indexed: false,
            internalType: 'bytes32',
            name: 'messageId',
            type: 'bytes32',
          },
          {
            indexed: false,
            internalType: 'string',
            name: 'encryptedContent',
            type: 'string',
          },
          {
            indexed: false,
            internalType: 'address',
            name: 'dataStoreAddress',
            type: 'address',
          },
          {
            indexed: false,
            internalType: 'uint256',
            name: 'messageNonce',
            type: 'uint256',
          },
        ],
        name: 'MessageSent',
        type: 'event',
      },
    ])
  }
}

export const eventLogService = EventLogService.getInstance()

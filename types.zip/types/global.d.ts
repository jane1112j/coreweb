/**
 * Global Type Definitions for metanode-finsdk
 */
import type { FiaiSDK as FiaiSDKClass } from '../packages/fiai-sdk/src/host/FiaiSDK'

declare global {
  type FiaiSDK = FiaiSDKClass
  interface Window {
    /**
     * SDK instance attached to window for global access
     * Available after SDK initialization via MetanodeSDK.init()
     */
    fiaiSDK?: FiaiSDK
    /** Reference to the opened mini wallet popup window */
    miniWalletWindow?: Window | null
  }

  type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends (infer U)[]
      ? DeepPartial<U>[]
      : T[P] extends object
        ? DeepPartial<T[P]>
        : T[P]
  }
}

export {}
